package com.oneemu.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings

/** Ограничение батареи: пока оно включено, Android может остановить установку и ВМ в фоне. */
object Battery {
    private const val MUTE_KEY = "battery_hint_off"

    fun exempt(ctx: Context): Boolean =
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)

    /** Нужно ли напомнить пользователю выключить ограничение (не исключён из оптимизации и не отказался от подсказок). */
    fun needsHint(ctx: Context): Boolean =
        !exempt(ctx) && !ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).getBoolean(MUTE_KEY, false)

    fun muteHint(ctx: Context) {
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).edit().putBoolean(MUTE_KEY, true).apply()
    }

    fun requestIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Открывает системный запрос «Не ограничивать»; если его нет на этой прошивке — общий список настроек батареи. */
    fun open(ctx: Context) {
        runCatching { ctx.startActivity(requestIntent(ctx)) }.onFailure {
            runCatching {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}
