package com.oneemu.app

import android.content.Context
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

data class OsEntry(
    val id: String,
    val name: String,
    val subtitle: String,
    val c1: Long,
    val c2: Long,
    val image: String? = null,
    val ramMb: Int = 2048,
    val cores: Int = 2,
    val diskGb: Int = 16,
    val custom: Boolean = false,
    val downloadUrl: String? = null,
    val sizeMb: Int = 0,
    val siteUrl: String? = null,
    val howTo: String = "",
    val bundle: Boolean = false,
    /** Если задано — это система-надстройка (GSI): запускается поверх диска другой системы. */
    val baseId: String? = null,
    val vmWidth: Int = 720,
    val vmHeight: Int = 1600,
    val networkEnabled: Boolean = true,
    /** Архитектура гостевой ОС: arm64 (телефонные VM) или x86 (Android-x86 ISO; QEMU x86_64 запускает и 32-, и 64-битные гости). */
    val architecture: String = "arm64",
)

object Repo {
    // Каталог содержит только Android 7–14. У каждой версии отдельный профиль;
    // общая база LineageOS и фиктивные GSI-загрузки не используются.
    private val defaults = listOf(
        OsEntry("android_7", "Android 7.0 Nougat", "ARM64 · отдельная гостевая система", 0xFFB66D75, 0xFF48232A,
            ramMb = 2048, cores = 2, diskGb = 16,
            howTo = "Отдельный профиль Android 7. Для запуска нужен полный совместимый ARM64-комплект: boot/kernel, ramdisk, system и vendor. Проверенный комплект пока не включён."),
        OsEntry("android_8_1", "Android 8.1 Oreo", "ARM64 · отдельная гостевая система", 0xFF4D8E9B, 0xFF173A48,
            ramMb = 2048, cores = 2, diskGb = 16,
            howTo = "Отдельный профиль Android 8.1. Для запуска нужен полный совместимый ARM64-комплект: boot/kernel, ramdisk, system и vendor. Проверенный комплект пока не включён."),
        OsEntry("android_9", "Android 9.0 Pie", "ARM64 · отдельная гостевая система", 0xFF4E9C83, 0xFF173D32,
            ramMb = 3072, cores = 4, diskGb = 20,
            howTo = "Отдельный профиль Android 9. Для запуска нужен полный совместимый ARM64-комплект. Один GSI-раздел не является полной загрузочной системой."),
        OsEntry("android_10", "Android 10", "ARM64 · отдельная гостевая система", 0xFF6B82B5, 0xFF263454,
            ramMb = 3072, cores = 4, diskGb = 20,
            howTo = "Отдельный профиль Android 10. Для запуска нужен полный совместимый ARM64-комплект. Один GSI-раздел не является полной загрузочной системой."),
        OsEntry("android_11", "Android 11", "ARM64 · отдельная гостевая система", 0xFF9278B7, 0xFF38294F,
            ramMb = 3072, cores = 4, diskGb = 20,
            howTo = "Отдельный профиль Android 11. Для запуска нужен полный совместимый ARM64-комплект. Один GSI-раздел не является полной загрузочной системой."),
        OsEntry("android_12", "Android 12", "ARM64 · отдельная гостевая система", 0xFFB17C9B, 0xFF482B3D,
            ramMb = 4096, cores = 4, diskGb = 24,
            howTo = "Отдельный профиль Android 12. Для запуска нужен полный совместимый ARM64-комплект. Один GSI-раздел не является полной загрузочной системой."),
        OsEntry("android_13", "Android 13", "ARM64 · отдельная гостевая система", 0xFF6D9EAB, 0xFF1F414A,
            ramMb = 4096, cores = 4, diskGb = 24,
            howTo = "Отдельный профиль Android 13. Для запуска нужен полный совместимый ARM64-комплект. Один GSI-раздел не является полной загрузочной системой."),
        OsEntry("android_14", "Android 14", "ARM64 · отдельная гостевая система", 0xFF8B9C69, 0xFF344020,
            ramMb = 4096, cores = 4, diskGb = 24,
            howTo = "Отдельный профиль Android 14. Для запуска нужен полный совместимый ARM64-комплект. Один GSI-раздел не является полной загрузочной системой."),
    )

    private fun goodImage(p: String?, e: OsEntry): String? {
        if (p == null) return null
        val f = File(p)
        if (!f.exists()) return null
        // битая загрузка (вместо образа скачалась веб-страница) — сбрасываем
        if (e.downloadUrl != null && f.extension.lowercase() == "iso" && f.length() < 50L * 1048576) { f.delete(); return null }
        return p
    }

    fun load(ctx: Context): List<OsEntry> {
        val sp = ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE)
        val raw = sp.getString("items", null) ?: return defaults
        val arr = JSONArray(raw)
        val saved = (0 until arr.length()).map { arr.getJSONObject(it) }
        val byId = saved.associateBy { it.getString("id") }
        val base = defaults.map { d ->
            val o = byId[d.id] ?: return@map d
            d.copy(
                image = goodImage(if (o.isNull("image")) null else o.getString("image"), d),
                ramMb = o.getInt("ram"), cores = o.getInt("cores"), diskGb = o.getInt("disk"),
                vmWidth = o.optInt("width", d.vmWidth), vmHeight = o.optInt("height", d.vmHeight),
                networkEnabled = o.optBoolean("network", d.networkEnabled),
            )
        }
        val custom = saved.filter { it.getBoolean("custom") }.map { o ->
            OsEntry(
                o.getString("id"), o.getString("name"), o.getString("subtitle"),
                o.getLong("c1"), o.getLong("c2"),
                if (o.isNull("image")) null else o.getString("image"),
                o.getInt("ram"), o.getInt("cores"), o.getInt("disk"), true,
                vmWidth = o.optInt("width", 720), vmHeight = o.optInt("height", 1600),
                networkEnabled = o.optBoolean("network", true),
            )
        }
        return base + custom
    }

    /** Прописывает путь к скачанному образу (вызывается из сервиса, когда UI может быть закрыт). */
    @Synchronized
    fun setImage(ctx: Context, id: String, path: String) {
        save(ctx, load(ctx).map { if (it.id == id) it.copy(image = path) else it })
    }

    @Synchronized
    fun save(ctx: Context, list: List<OsEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("subtitle", it.subtitle)
                put("c1", it.c1); put("c2", it.c2); put("image", it.image ?: JSONObject.NULL)
                put("ram", it.ramMb); put("cores", it.cores); put("disk", it.diskGb); put("custom", it.custom)
                put("width", it.vmWidth); put("height", it.vmHeight); put("network", it.networkEnabled)
            })
        }
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }
}
