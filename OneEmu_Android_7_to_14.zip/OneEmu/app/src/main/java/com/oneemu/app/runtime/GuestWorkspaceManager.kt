package com.oneemu.app.runtime

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException

/** Owns independent guest workspaces and never falls back to another guest's files. */
object GuestWorkspaceManager {
    private val locks = mutableMapOf<String, Any>()

    private fun lockFor(id: String): Any = synchronized(locks) { locks.getOrPut(id) { Any() } }

    fun create(context: Context, name: String, androidVersion: Int): GuestProfile {
        val (profile, storage) = GuestProfileStore.create(context, name, androidVersion)
        synchronized(lockFor(profile.id)) {
            writeState(storage, "CREATED", "Guest storage prepared; boot runtime not yet available")
        }
        return profile
    }

    fun list(context: Context): List<GuestProfile> = GuestProfileStore.list(context)

    fun workspace(context: Context, profile: GuestProfile): GuestStorage =
        synchronized(lockFor(profile.id)) { GuestProfileStore.prepareStorage(context, profile) }

    fun setState(context: Context, profile: GuestProfile, state: String, detail: String) {
        require(state in setOf("CREATED", "IMAGE_READY", "STARTING", "RUNNING", "STOPPED", "FAILED"))
        synchronized(lockFor(profile.id)) {
            val storage = GuestProfileStore.prepareStorage(context, profile)
            writeState(storage, state, detail)
        }
    }

    /** Deletion is constrained to this guest's canonical directory. */
    @Throws(IOException::class)
    fun delete(context: Context, profile: GuestProfile) {
        synchronized(lockFor(profile.id)) {
            val base = GuestProfileStore.root(context).canonicalFile
            val guest = File(base, profile.id).canonicalFile
            if (guest.parentFile != base || guest == base) throw IOException("Invalid guest directory")
            deleteTree(guest)
        }
        synchronized(locks) { locks.remove(profile.id) }
    }

    private fun writeState(storage: GuestStorage, state: String, detail: String) {
        val target = File(storage.metadata, "state.json")
        val temp = File(storage.metadata, "state.json.tmp")
        temp.writeText(JSONObject().apply {
            put("state", state)
            put("detail", detail)
            put("updatedAtEpochMs", System.currentTimeMillis())
        }.toString(2))
        if (target.exists() && !target.delete()) throw IOException("Cannot replace guest state")
        if (!temp.renameTo(target)) throw IOException("Cannot commit guest state")
    }

    private fun deleteTree(file: File) {
        if (!file.exists()) return
        if (file.isDirectory) file.listFiles()?.forEach(::deleteTree)
        if (!file.delete()) throw IOException("Cannot delete guest data: ${file.name}")
    }
}
