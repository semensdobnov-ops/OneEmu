package com.oneemu.app

import android.content.Context
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile

/**
 * Мобильный (ARM64) образ приходит архивом-«бандлом» с несколькими дисками
 * (vda.qcow2, vdb.qcow2 …). Распаковываем их в images/<id>/ и возвращаем путь к первому диску.
 */
/** Понятная пользователю причина, почему образ не подошёл (без подсказок про интернет). */
class InstallError(msg: String) : Exception(msg)

/** Копирует поток блоками по 1 МБ, сообщает сколько байт уже скопировано и проверяет отмену. */
internal fun copyCounting(i: java.io.InputStream, o: java.io.OutputStream, cancel: AtomicBoolean?, onBytes: (Long) -> Unit): Long {
    val buf = ByteArray(4 shl 20)
    var n = 0L
    while (true) {
        if (cancel?.get() == true) throw InstallError("Установка отменена")
        val r = i.read(buf); if (r < 0) break
        o.write(buf, 0, r); n += r
        onBytes(n)
    }
    return n
}

object ImageInstaller {
    private val DISK = Regex("""(?i)(^|/)(vd[a-z])\.(qcow2|img|raw)$""")

    fun isBundle(zip: File): Boolean = runCatching {
        ZipFile(zip).use { z -> z.entries().asSequence().any { !it.isDirectory && DISK.containsMatchIn(it.name) } }
    }.getOrDefault(false)

    /**
     * Возвращает путь к основному диску (vda).
     * progress(этап, готово, всего) — байты по всем дискам вместе, чтобы считать проценты и оставшееся время.
     *
     * Диски (vda, vdb …) распаковываются ПАРАЛЛЕЛЬНО, каждый в своём потоке со своим ZipFile, буфер 4 МБ.
     * Прогресс отдаётся только из вызывающего потока (раз в ~200 мс), поэтому Reporter остаётся потокобезопасным.
     */
    fun unpack(
        ctx: Context, id: String, zip: File, cancel: AtomicBoolean? = null,
        progress: (String, Long, Long) -> Unit = { _, _, _ -> },
    ): String {
        val dir = File(ctx.filesDir, "images/$id").apply { deleteRecursively(); mkdirs() }
        val failure = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        val pool = java.util.concurrent.Executors.newFixedThreadPool(3)
        try {
            val names = ZipFile(zip).use { z ->
                z.entries().asSequence().filter { !it.isDirectory && DISK.containsMatchIn(it.name) }
                    .sortedBy { it.name.substringAfterLast('/').lowercase() }
                    .map { it.name to maxOf(it.size, 0L) }.toList()
            }
            if (names.isEmpty()) throw InstallError("В архиве нет дисков vda/vdb (.qcow2). Это не образ для мобильной версии.")
            val total = names.sumOf { it.second }.coerceAtLeast(1L)
            val done = java.util.concurrent.atomic.AtomicLong(0)
            val finished = java.util.concurrent.atomic.AtomicInteger(0)
            val abort = AtomicBoolean(false) // общий флаг: пользователь отменил или упал один из потоков
            val files = names.map { (n, _) -> File(dir, n.substringAfterLast('/').lowercase()) }
            names.forEachIndexed { idx, (entryName, _) ->
                pool.execute {
                    try {
                        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_FOREGROUND)
                        ZipFile(zip).use { z ->
                            val e = z.getEntry(entryName)
                            var last = 0L
                            z.getInputStream(e).use { i ->
                                java.io.BufferedOutputStream(files[idx].outputStream(), 1 shl 20).use { o ->
                                    copyCounting(i, o, abort) { n -> done.addAndGet(n - last); last = n }
                                }
                            }
                        }
                    } catch (t: Throwable) {
                        failure.compareAndSet(null, t)
                    } finally {
                        finished.incrementAndGet()
                    }
                }
            }
            while (finished.get() < names.size) {
                if (cancel?.get() == true || failure.get() != null) abort.set(true)
                progress(if (names.size > 1) "Распаковка дисков (${names.size})…" else "Распаковка ${files[0].name}…", minOf(done.get(), total), total)
                Thread.sleep(200)
            }
            failure.get()?.let { throw it }
            if (cancel?.get() == true) throw InstallError("Установка отменена")
            progress("Распаковка…", total, total)
            return files.first().absolutePath
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        } finally {
            pool.shutdownNow()
        }
    }

    /** Все диски рядом с основным: vda, vdb, vdc … */
    fun disksNear(main: File): List<File> =
        (main.parentFile?.listFiles() ?: emptyArray())
            .filter { DISK.containsMatchIn("/" + it.name) }
            .sortedBy { it.name.lowercase() }
}
