package com.oneemu.app.engine

import android.content.Context

/**
 * Boundary for a future Android-in-Android runtime.
 *
 * This is deliberately NOT backed by QEMU, UEFI, a PC firmware image, or a fake
 * executable. A runtime implementation may be registered only after its guest
 * process isolation, lifecycle, storage isolation and graphics path are verified.
 */
interface GuestAndroidRuntime {
    val id: String

    fun availability(context: Context): RuntimeAvailability

    /** Starts one isolated guest. A successful return means the runtime accepted the request,
     * not that Android has completed booting; boot completion must be reported separately. */
    suspend fun start(context: Context, guest: GuestAndroidSpec): RuntimeStartResult

    suspend fun stop(context: Context, guestId: String): RuntimeStopResult

    fun observeState(context: Context, guestId: String): GuestRuntimeState
}

data class GuestAndroidSpec(
    val id: String,
    val androidRelease: AndroidRelease,
    val architecture: GuestArchitecture = GuestArchitecture.ARM64,
    val memoryMb: Int = 2048,
    val storageBytes: Long,
    /** Directory owned exclusively by this guest; never shared with another guest. */
    val privateDataDirectory: String,
    /** Manifest describing the complete boot set, not a system-only GSI partition. */
    val imageManifestPath: String,
)

enum class AndroidRelease(val displayName: String) {
    ANDROID_7("Android 7"),
    ANDROID_8_1("Android 8.1"),
    ANDROID_9("Android 9"),
    ANDROID_10("Android 10"),
    ANDROID_11("Android 11"),
    ANDROID_12("Android 12"),
    ANDROID_13("Android 13"),
    ANDROID_14("Android 14"),
}

enum class GuestArchitecture { ARM64 }

enum class GuestRuntimeState {
    NOT_INSTALLED,
    STOPPED,
    PREPARING,
    BOOTING,
    RUNNING,
    PAUSED,
    STOPPING,
    FAILED,
}

sealed interface RuntimeAvailability {
    data class Available(val runtimeVersion: String) : RuntimeAvailability
    data class Unavailable(val reason: String) : RuntimeAvailability
}

sealed interface RuntimeStartResult {
    data object Started : RuntimeStartResult
    data class Rejected(val reason: String) : RuntimeStartResult
}

sealed interface RuntimeStopResult {
    data object Stopped : RuntimeStopResult
    data class Failed(val reason: String) : RuntimeStopResult
}
