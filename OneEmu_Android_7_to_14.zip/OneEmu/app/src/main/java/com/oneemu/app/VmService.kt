package com.oneemu.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.ServiceCompat

/**
 * Foreground-сервис, пока работает виртуальная система (QEMU). Благодаря ему ВМ продолжает работать,
 * когда приложение свёрнуто или экран погас: Android не замораживает и не убивает процесс.
 * Сервис сам останавливается, когда QEMU завершился.
 */
class VmService : Service() {
    private var wl: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val check = object : Runnable {
        override fun run() {
            if (!QemuRunner.alive()) finish() else handler.postDelayed(this, 3000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notif.ensureChannels(this)
        val name = intent?.getStringExtra("name") ?: "Виртуальная система"
        ServiceCompat.startForeground(
            this, Notif.VM_ID, Notif.vm(this, name),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
        if (wl == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OneEmu:vm").apply { acquire(12 * 60 * 60 * 1000L) }
        }
        handler.removeCallbacks(check)
        handler.postDelayed(check, 3000)
        return START_NOT_STICKY
    }

    private fun finish() {
        handler.removeCallbacks(check)
        runCatching { wl?.takeIf { it.isHeld }?.release() }
        wl = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(check)
        runCatching { wl?.takeIf { it.isHeld }?.release() }
        super.onDestroy()
    }
}
