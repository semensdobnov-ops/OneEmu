package com.oneemu.app.runtime

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

/**
 * Persistent, per-guest storage model for the future native Android guest runtime.
 * This class deliberately does not pretend that a guest can boot: no kernel,
 * init/zygote isolation layer, or Android-compatible execution backend is shipped yet.
 */
data class GuestProfile(
    val id: String,
    val displayName: String,
    val androidVersion: Int,
    val architecture: String = "arm64-v8a",
    val createdAtEpochMs: Long = System.currentTimeMillis(),
) {
    init {
        require(id.matches(Regex("[a-zA-Z0-9_-]{1,64}"))) { "Invalid guest id" }
        require(displayName.isNotBlank()) { "Guest name is required" }
        require(androidVersion >= 7) { "OneEmu guest versions start at Android 7" }
        require(architecture == "arm64-v8a") { "Only ARM64 guest profiles are supported" }
    }
}

/** Separate writable data roots prevent guest profiles from sharing app data. */
data class GuestStorage(
    val root: File,
    val system: File,
    val data: File,
    val cache: File,
    val metadata: File,
)

object GuestProfileStore {
    private const val PROFILE_FILE = "profile.json"

    fun root(context: Context): File = File(context.filesDir, "android-guests")

    @Synchronized
    @Throws(IOException::class)
    fun create(context: Context, displayName: String, androidVersion: Int): Pair<GuestProfile, GuestStorage> {
        val profile = GuestProfile(
            id = "guest_${UUID.randomUUID().toString().replace("-", "")}",
            displayName = displayName.trim(),
            androidVersion = androidVersion,
        )
        return profile to prepareStorage(context, profile)
    }

    @Synchronized
    @Throws(IOException::class)
    fun prepareStorage(context: Context, profile: GuestProfile): GuestStorage {
        val base = root(context).canonicalFile
        val guestRoot = File(base, profile.id).canonicalFile
        if (guestRoot.parentFile != base) throw IOException("Guest path escaped storage root")

        val system = File(guestRoot, "system")
        val data = File(guestRoot, "data")
        val cache = File(guestRoot, "cache")
        val metadata = File(guestRoot, "metadata")
        listOf(system, data, cache, metadata).forEach {
            if (!it.exists() && !it.mkdirs()) throw IOException("Cannot create guest directory: ${it.name}")
        }

        val profileFile = File(metadata, PROFILE_FILE)
        if (profileFile.exists()) {
            val saved = JSONObject(profileFile.readText())
            if (saved.optString("id") != profile.id) throw IOException("Guest metadata id mismatch")
        } else {
            val json = JSONObject().apply {
                put("id", profile.id)
                put("displayName", profile.displayName)
                put("androidVersion", profile.androidVersion)
                put("architecture", profile.architecture)
                put("createdAtEpochMs", profile.createdAtEpochMs)
                put("runtimeState", "storage_prepared_backend_missing")
            }
            val temp = File(metadata, "$PROFILE_FILE.tmp")
            temp.writeText(json.toString(2))
            if (!temp.renameTo(profileFile)) {
                temp.delete()
                throw IOException("Cannot commit guest metadata")
            }
        }
        return GuestStorage(guestRoot, system, data, cache, metadata)
    }

    fun list(context: Context): List<GuestProfile> {
        val base = root(context)
        val dirs = base.listFiles()?.filter { it.isDirectory }.orEmpty()
        return dirs.mapNotNull { dir ->
            runCatching {
                val json = JSONObject(File(dir, "metadata/$PROFILE_FILE").readText())
                GuestProfile(
                    id = json.getString("id"),
                    displayName = json.getString("displayName"),
                    androidVersion = json.getInt("androidVersion"),
                    architecture = json.optString("architecture", "arm64-v8a"),
                    createdAtEpochMs = json.optLong("createdAtEpochMs", 0L),
                )
            }.getOrNull()
        }.sortedBy { it.createdAtEpochMs }
    }
}

enum class GuestRuntimeState {
    NOT_AVAILABLE,
    STORAGE_PREPARED,
    STARTING,
    RUNNING,
    STOPPED,
    FAILED,
}

data class GuestRuntimeResult(
    val state: GuestRuntimeState,
    val message: String,
)

/** Contract for a future Android-native, rootless guest execution backend. */
interface AndroidGuestRuntime {
    fun probe(context: Context): GuestRuntimeResult
    fun start(context: Context, profile: GuestProfile): GuestRuntimeResult
    fun stop(context: Context, profile: GuestProfile): GuestRuntimeResult
}

/** Explicit placeholder: never reports a successful boot without a real backend. */
object NativeRuntimeNotInstalled : AndroidGuestRuntime {
    override fun probe(context: Context) = GuestRuntimeResult(
        GuestRuntimeState.NOT_AVAILABLE,
        "Native Android guest runtime is not installed. Guest storage can be prepared, but Android cannot boot yet.",
    )

    override fun start(context: Context, profile: GuestProfile) = GuestRuntimeResult(
        GuestRuntimeState.NOT_AVAILABLE,
        "Cannot start Android ${profile.androidVersion}: no compatible rootless ARM64 guest runtime is included.",
    )

    override fun stop(context: Context, profile: GuestProfile) = GuestRuntimeResult(
        GuestRuntimeState.STOPPED,
        "No guest process is running.",
    )
}
