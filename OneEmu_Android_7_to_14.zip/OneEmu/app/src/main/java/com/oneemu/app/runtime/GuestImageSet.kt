package com.oneemu.app.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.MessageDigest

/** A complete, independently bootable ARM64 Android image set. */
data class GuestImageFile(
    val role: String,
    val relativePath: String,
    val sha256: String,
    val sizeBytes: Long,
)

data class GuestImageManifest(
    val schemaVersion: Int,
    val androidVersion: Int,
    val architecture: String,
    val files: List<GuestImageFile>,
) {
    fun validate(): List<String> {
        val errors = mutableListOf<String>()
        if (schemaVersion != 1) errors += "Unsupported manifest schema: $schemaVersion"
        if (androidVersion < 7) errors += "Android versions below 7 are not supported"
        if (architecture != "arm64-v8a") errors += "Only ARM64 guest images are supported"
        val roles = files.map { it.role }
        listOf("boot", "system", "vendor").filterNot(roles.toSet()::contains).forEach {
            errors += "Missing required image role: $it"
        }
        if (roles.distinct().size != roles.size) errors += "Duplicate image roles are not allowed"
        files.forEach { file ->
            if (file.role !in setOf("boot", "system", "vendor", "product", "vbmeta", "dtbo")) {
                errors += "Unknown image role: ${file.role}"
            }
            val parts = file.relativePath.replace('\\', '/').split('/')
            if (file.relativePath.isBlank() || File(file.relativePath).isAbsolute ||
                parts.any { it == ".." || it.isBlank() }) errors += "Unsafe image path for role ${file.role}"
            if (!file.sha256.matches(Regex("[a-fA-F0-9]{64}"))) errors += "Invalid SHA-256 for role ${file.role}"
            if (file.sizeBytes <= 0) errors += "Invalid file size for role ${file.role}"
        }
        return errors
    }

    companion object {
        fun parse(file: File): GuestImageManifest {
            val json = JSONObject(file.readText())
            val array = json.getJSONArray("files")
            val files = (0 until array.length()).map { index ->
                val item = array.getJSONObject(index)
                GuestImageFile(item.getString("role"), item.getString("path"), item.getString("sha256"), item.getLong("sizeBytes"))
            }
            return GuestImageManifest(json.getInt("schemaVersion"), json.getInt("androidVersion"), json.getString("architecture"), files)
        }
    }
}

/** Imports verified files into a guest-private directory; no image is shared across guests. */
object GuestImageInstaller {
    @Synchronized
    @Throws(IOException::class)
    fun install(context: Context, profile: GuestProfile, sourceDirectory: File, manifestFile: File): File {
        val manifest = try { GuestImageManifest.parse(manifestFile) }
        catch (e: Exception) { throw IOException("Cannot read guest image manifest", e) }
        val errors = manifest.validate()
        if (errors.isNotEmpty()) throw IOException(errors.joinToString("; "))
        if (manifest.androidVersion != profile.androidVersion) throw IOException("Image Android version does not match guest profile")

        val sourceRoot = sourceDirectory.canonicalFile
        val storage = GuestProfileStore.prepareStorage(context, profile)
        val targetRoot = File(storage.root, "images").canonicalFile
        if (targetRoot.parentFile != storage.root.canonicalFile) throw IOException("Guest image path escaped profile directory")
        val staging = File(storage.root, "images.installing")
        deleteTree(staging)
        if (!staging.mkdirs()) throw IOException("Cannot create image staging directory")

        try {
            manifest.files.forEach { item ->
                val source = File(sourceRoot, item.relativePath).canonicalFile
                if (!source.path.startsWith(sourceRoot.path + File.separator)) throw IOException("Image path escaped source directory")
                if (!source.isFile || source.length() != item.sizeBytes) throw IOException("Missing or invalid image file: ${item.relativePath}")
                if (!sha256(source).equals(item.sha256, ignoreCase = true)) throw IOException("SHA-256 mismatch: ${item.relativePath}")
                val destination = File(staging, "${item.role}.img")
                source.inputStream().buffered().use { input -> destination.outputStream().buffered().use { output -> input.copyTo(output) } }
                if (destination.length() != item.sizeBytes) throw IOException("Image copy verification failed: ${item.role}")
            }
            val backup = File(storage.root, "images.previous")
            deleteTree(backup)
            if (targetRoot.exists() && !targetRoot.renameTo(backup)) throw IOException("Cannot stage previous guest images")
            if (!staging.renameTo(targetRoot)) {
                if (backup.exists()) backup.renameTo(targetRoot)
                throw IOException("Cannot commit guest images")
            }
            try {
                File(storage.metadata, "image-manifest.json").writeText(JSONObject().apply {
                    put("schemaVersion", manifest.schemaVersion)
                    put("androidVersion", manifest.androidVersion)
                    put("architecture", manifest.architecture)
                    put("roles", JSONArray(manifest.files.map { it.role }))
                    put("verified", true)
                }.toString(2))
                deleteTree(backup)
            } catch (e: Exception) {
                deleteTree(targetRoot)
                if (backup.exists()) backup.renameTo(targetRoot)
                throw e
            }
            return targetRoot
        } catch (e: Exception) {
            deleteTree(staging)
            if (e is IOException) throw e
            throw IOException("Guest image installation failed", e)
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun deleteTree(file: File) {
        if (!file.exists()) return
        if (file.isDirectory) file.listFiles()?.forEach(::deleteTree)
        if (!file.delete()) throw IOException("Cannot remove ${file.name}")
    }
}
