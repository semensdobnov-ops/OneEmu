package com.oneemu.app

import android.graphics.Bitmap
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import kotlin.concurrent.thread

/** Минимальный RFB/VNC-клиент: без пароля, Raw-кодирование, DesktopSize. */
class VncClient(private val port: Int, private val onUpdate: () -> Unit) {
    @Volatile var bmp: Bitmap? = null
    @Volatile var error: String? = null
    @Volatile private var running = true
    private var sock: Socket? = null
    private var out: DataOutputStream? = null

    fun start() = thread(isDaemon = true) {
        try { connect(); loop() } catch (e: Exception) { if (running) { error = e.message ?: "Соединение закрыто"; onUpdate() } }
    }

    fun close() { running = false; runCatching { sock?.close() } }

    private fun connect() {
        var s: Socket? = null
        repeat(120) {
            if (s == null && running) {
                if (!QemuRunner.alive()) throw Exception("QEMU завершился до запуска видеовыхода. Откройте диагностику запуска.")
                try { s = Socket("127.0.0.1", port) } catch (_: Exception) { Thread.sleep(1000) }
            }
        }
        if (!running) return
        val so = s ?: throw Exception("Не удалось подключиться к VNC на порту $port за 120 секунд. Проверьте qemu.log.")
        sock = so
        val inp = DataInputStream(so.getInputStream().buffered(1 shl 20))
        out = DataOutputStream(so.getOutputStream())
        inStream = inp
        val ver = ByteArray(12); inp.readFully(ver)
        send { it.write("RFB 003.008\n".toByteArray()) }
        val n = inp.readUnsignedByte()
        if (n == 0) throw Exception("VNC отклонил соединение")
        val types = ByteArray(n); inp.readFully(types)
        send { it.writeByte(1) }
        if (inp.readInt() != 0) throw Exception("Ошибка авторизации VNC")
        send { it.writeByte(1) }
        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
        inp.skipBytes(16)
        val nameLen = inp.readInt(); inp.skipBytes(nameLen)
        bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        send {
            it.writeByte(0); it.write(ByteArray(3))
            it.writeByte(32); it.writeByte(24); it.writeByte(0); it.writeByte(1)
            it.writeShort(255); it.writeShort(255); it.writeShort(255)
            it.writeByte(16); it.writeByte(8); it.writeByte(0); it.write(ByteArray(3))
        }
        send { it.writeByte(2); it.writeByte(0); it.writeShort(2); it.writeInt(0); it.writeInt(-223) }
        requestUpdate(false)
    }

    private var inStream: DataInputStream? = null

    private fun loop() {
        val inp = inStream!!
        var buf = ByteArray(0)
        var px = IntArray(0)
        while (running) {
            when (inp.readUnsignedByte()) {
                0 -> {
                    inp.skipBytes(1)
                    val rects = inp.readUnsignedShort()
                    repeat(rects) {
                        val x = inp.readUnsignedShort(); val y = inp.readUnsignedShort()
                        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
                        when (inp.readInt()) {
                            0 -> {
                                // Весь прямоугольник читаем одним куском и отдаём в Bitmap одним вызовом
                                // (раньше был вызов setPixels на каждую строку — ~1600 вызовов на кадр, из-за чего анимация шла рывками).
                                val n = w * h
                                if (buf.size < n * 4) { buf = ByteArray(n * 4); px = IntArray(n) }
                                inp.readFully(buf, 0, n * 4)
                                val b = bmp
                                if (b != null && x + w <= b.width && y + h <= b.height) {
                                    var o = 0
                                    for (i in 0 until n) {
                                        px[i] = (0xFF shl 24) or ((buf[o + 2].toInt() and 255) shl 16) or
                                            ((buf[o + 1].toInt() and 255) shl 8) or (buf[o].toInt() and 255)
                                        o += 4
                                    }
                                    b.setPixels(px, 0, w, x, y, w, h)
                                }
                            }
                            -223 -> bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        }
                    }
                    onUpdate()
                    requestUpdate(true)
                }
                1 -> { inp.skipBytes(1); inp.skipBytes(2); val c = inp.readUnsignedShort(); inp.skipBytes(c * 6) }
                3 -> { inp.skipBytes(3); val l = inp.readInt(); inp.skipBytes(l) }
            }
        }
    }

    private fun send(block: (DataOutputStream) -> Unit) {
        val o = out ?: return
        synchronized(o) { block(o); o.flush() }
    }

    private fun requestUpdate(incremental: Boolean) {
        val b = bmp ?: return
        send { it.writeByte(3); it.writeByte(if (incremental) 1 else 0); it.writeShort(0); it.writeShort(0); it.writeShort(b.width); it.writeShort(b.height) }
    }

    fun pointer(mask: Int, x: Int, y: Int) =
        runCatching { send { it.writeByte(5); it.writeByte(mask); it.writeShort(x); it.writeShort(y) } }

    // одна очередь — клавиши приходят в гость строго по порядку
    private val keys = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun keyEvent(down: Boolean, sym: Int) =
        send { it.writeByte(4); it.writeByte(if (down) 1 else 0); it.writeShort(0); it.writeInt(sym) }

    fun key(sym: Int) { keys.execute { runCatching { keyEvent(true, sym); keyEvent(false, sym) } } }

    /** Сочетание клавиш: зажать все по порядку, потом отпустить в обратном (например Super+Enter). */
    fun combo(vararg syms: Int) {
        keys.execute { runCatching { syms.forEach { keyEvent(true, it) }; syms.reversed().forEach { keyEvent(false, it) } } }
    }

    /** Один символ с клавиатуры телефона → клавиша в гостевой системе. */
    fun type(ch: Char) {
        val sym = when {
            ch == '\n' -> 0xFF0D
            ch == '\t' -> 0xFF09
            ch.code < 0x100 -> ch.code
            else -> 0x01000000 + ch.code
        }
        key(sym)
    }
}
