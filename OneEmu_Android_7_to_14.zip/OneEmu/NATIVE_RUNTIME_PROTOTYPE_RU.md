# OneEmu Native Runtime — архитектура и статус

## Цель

OneEmu должен создавать несколько независимых гостевых Android-систем ARM64, начиная с Android 7. Ни одна гостевая система не должна требовать предварительной установки LineageOS или другой гостевой ОС. Общим является только код менеджера/рантайма OneEmu; загрузочные образы, данные, настройки и состояние каждой гостевой системы принадлежат только ей.

## Слои

1. **UI** — существующий интерфейс OneEmu. Визуальный редизайн не является частью этой задачи.
2. **Guest Workspace Manager** — создаёт и обслуживает изолированные каталоги каждого гостя.
3. **Image Manager** — принимает только комплект загрузочных образов с manifest, проверяет SHA-256 и копирует их в приватный каталог конкретного гостя.
4. **Lifecycle Manager / Runtime API** — контракт запуска, остановки и наблюдения за состоянием гостя.
5. **Native Android Runtime** — будущий реальный backend: загрузка ядра/init, Android userspace, binder/service isolation, графика, ввод и сеть.

## Реализовано в этом исходном коде

- `GuestProfileStore`: отдельные `system`, `data`, `cache`, `metadata` каталоги на профиль.
- `GuestWorkspaceManager`: создание, перечисление, изменение состояния и безопасное удаление профиля.
- `GuestImageManifest`: формат manifest для полного ARM64-набора.
- `GuestImageInstaller`: проверка версии Android, ролей, путей, размеров и SHA-256; staged install и откат при ошибке.
- `GuestAndroidRuntime` / `AndroidGuestRuntime`: интерфейсы runtime и явная заглушка, которая не выдаёт подготовку дисков за загрузку Android.
- CI собирает APK штатной Android/Gradle-сборкой и не переименовывает Linux executable в Android `.so`.

## Формат manifest

Пример `guest-image.json`:

```json
{
  "schemaVersion": 1,
  "androidVersion": 14,
  "architecture": "arm64-v8a",
  "files": [
    {"role": "boot", "path": "images/boot.img", "sha256": "<64 hex chars>", "sizeBytes": 123456},
    {"role": "system", "path": "images/system.img", "sha256": "<64 hex chars>", "sizeBytes": 123456},
    {"role": "vendor", "path": "images/vendor.img", "sha256": "<64 hex chars>", "sizeBytes": 123456}
  ]
}
```

`boot`, `system` и `vendor` обязательны. GSI `system.img` в одиночку не является полной гостевой системой и не принимается как bootable image set. Значения в примере демонстрационные; это не ссылки на готовые образы.

## Принцип независимости

Для каждого гостя создаётся собственная директория:

```text
files/android-guests/<guest-id>/
  system/       # guest-specific system workspace
  data/         # guest-specific writable data
  cache/        # guest-specific cache
  metadata/     # profile, state and image manifest
  images/       # private verified boot/system/vendor images
```

Запрещено использовать данные другого гостя как fallback. Удаление гостя удаляет только его canonical directory. Образы не hard-link-ятся и не разделяются между профилями.

## Что пока НЕ реализовано

- Рабочий rootless backend, который действительно запускает Android.
- Изоляция binder, процессов, mount namespace и системных служб гостя.
- Загрузка ядра/init и совместимые образы Android 7–17.
- Графический вывод гостевого SurfaceFlinger и маршрутизация сенсорного ввода.
- Сетевой стек гостя и интеграция с Android host.

Поэтому этот ZIP — архитектурная/инфраструктурная версия, а не готовый аналог Virtual Master. Старый `QemuRunner` в приложении всё ещё существует и не является Native Runtime. Его нельзя считать целевой реализацией Android-in-Android.

## Ограничение rootless

Обычное Android-приложение без root не получает автоматически права `mount`, `chroot`, `unshare` или доступа к системному Binder. Для реального backend требуется доказанный механизм изоляции, совместимый с конкретными версиями Android и SELinux. Нельзя объявлять runtime доступным только потому, что созданы каталоги или скачаны GSI.
