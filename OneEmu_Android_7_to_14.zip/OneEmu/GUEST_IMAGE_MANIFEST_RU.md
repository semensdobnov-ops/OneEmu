# Manifest гостевой Android-системы

OneEmu принимает в новый профиль только полный комплект ARM64 образов. Минимальные роли:

- `boot` — загрузочный образ с ядром и ramdisk;
- `system` — системный раздел;
- `vendor` — vendor-раздел.

Дополнительные роли: `product`, `vbmeta`, `dtbo`.

Каждый файл описывается относительным путём, размером в байтах и SHA-256. Абсолютные пути и `..` запрещены. `androidVersion` должен совпадать с версией профиля. GSI без boot/vendor не является независимым образом и не подходит.

Формат JSON:

```json
{
  "schemaVersion": 1,
  "androidVersion": 14,
  "architecture": "arm64-v8a",
  "files": [
    {"role":"boot","path":"images/boot.img","sha256":"<64 hex chars>","sizeBytes":123456},
    {"role":"system","path":"images/system.img","sha256":"<64 hex chars>","sizeBytes":123456},
    {"role":"vendor","path":"images/vendor.img","sha256":"<64 hex chars>","sizeBytes":123456}
  ]
}
```

Это описание формата, не готовый образ и не источник загрузки.
