#!/bin/sh
# Собирает статический qemu-system-aarch64 под arm64 (Alpine/musl). Запускается в контейнере alpine:3.20.
# (Основная сборка идёт в .github/workflows/build.yml — этот файл для ручного запуска.)
set -e
apk add --no-cache build-base git python3 py3-setuptools ninja meson pkgconf bash flex bison perl curl xz \
  linux-headers glib-dev glib-static pixman-dev pixman-static zlib-dev zlib-static libslirp-dev \
  pcre2-dev pcre2-static libffi-dev gettext-dev gettext-static zstd-dev zstd-static
cd /tmp
curl -fLO https://download.qemu.org/qemu-9.0.2.tar.xz
tar xf qemu-9.0.2.tar.xz
cd qemu-9.0.2
./configure --static --target-list=aarch64-softmmu,x86_64-softmmu --disable-docs --disable-tools --disable-guest-agent \
  --disable-werror --disable-gtk --disable-sdl --disable-opengl --disable-curses --disable-kvm
make -j"$(nproc)" qemu-system-aarch64
mkdir -p /w/out/share
strip build/qemu-system-aarch64
cp build/qemu-system-aarch64 /w/out/libqemu.so
bzip2 -dk pc-bios/edk2-aarch64-code.fd.bz2
cp pc-bios/edk2-aarch64-code.fd /w/out/share/
cp pc-bios/efi-virtio.rom /w/out/share/ || true
cp -r build/pc-bios/keymaps /w/out/share/ 2>/dev/null || true
ls -la /w/out /w/out/share
