#!/bin/sh
# Собирает статический qemu-system-x86_64 под arm64 (Alpine/musl). Запускается в контейнере alpine:3.20.
set -e
apk add --no-cache build-base git python3 py3-setuptools ninja meson pkgconf bash flex bison perl curl xz \
  linux-headers glib-dev glib-static pixman-dev pixman-static zlib-dev zlib-static libslirp-dev \
  pcre2-dev pcre2-static libffi-dev gettext-dev gettext-static zstd-dev zstd-static
cd /tmp
curl -fLO https://download.qemu.org/qemu-9.0.2.tar.xz
tar xf qemu-9.0.2.tar.xz
cd qemu-9.0.2
./configure --static --target-list=x86_64-softmmu --disable-docs --disable-tools --disable-guest-agent \
  --disable-werror --disable-gtk --disable-sdl --disable-opengl --disable-curses --disable-kvm
make -j"$(nproc)"
mkdir -p /w/out/share
strip build/qemu-system-x86_64
cp build/qemu-system-x86_64 /w/out/libqemu.so
for f in bios-256k.bin vgabios-stdvga.bin kvmvapic.bin linuxboot_dma.bin efi-virtio.rom efi-e1000.rom; do
  cp pc-bios/$f /w/out/share/
done
ls -la /w/out /w/out/share
