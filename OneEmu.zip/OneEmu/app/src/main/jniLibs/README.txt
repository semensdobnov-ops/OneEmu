Положите сюда статически собранный qemu-system-aarch64, переименованный в libqemu.so:
  app/src/main/jniLibs/arm64-v8a/libqemu.so   (для большинства телефонов)
