Положите сюда статически собранный qemu-system-x86_64, переименованный в libqemu.so:
  app/src/main/jniLibs/arm64-v8a/libqemu.so   (для большинства телефонов)
  app/src/main/jniLibs/x86_64/libqemu.so      (для x86-устройств)
