Сюда CI кладёт BIOS-файлы QEMU
