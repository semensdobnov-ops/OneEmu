@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.oneemu.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

private val TAU = (2 * PI).toFloat()
private fun mix(a: Offset, b: Offset, k: Float) = Offset(a.x + (b.x - a.x) * k, a.y + (b.y - a.y) * k)
private fun mbText(b: Long) = "%.0f".format(b / 1048576.0)

@Composable
fun DownloadsScreen(
    list: List<DlState>,
    onCancel: (String) -> Unit,
    onRetry: (String) -> Unit,
    onDismiss: (String) -> Unit,
    onHome: () -> Unit,
) {
    val active = list.filter { it.status == DlStatus.ACTIVE }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF2A2F5C).copy(alpha = .7f), Color(0xFF0B0D14), Color(0xFF0B0D14))))
            .statusBarsPadding(),
    ) {
        Text("Загрузки", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(24.dp, 20.dp, 24.dp, 0.dp))
        Text(
            when {
                active.isNotEmpty() -> {
                    val dls = active.filter { it.phase == DlPhase.DOWNLOAD }
                    "Идёт: ${active.size}" + if (dls.isNotEmpty()) " · ${fmtSpeed(dls.sumOf { it.speed })}" else " · установка"
                }
                list.isNotEmpty() -> "Все загрузки завершены"
                else -> "Здесь появятся скачиваемые системы"
            },
            color = Color.White.copy(.6f), modifier = Modifier.padding(horizontal = 24.dp),
        )
        if (list.isEmpty()) {
            EmptyState(onHome)
        } else {
            LazyColumn(
                contentPadding = PaddingValues(20.dp, 20.dp, 20.dp, 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                items(list, key = { it.id }) { s ->
                    DlCard(s, Modifier.animateItemPlacement(), onCancel, onRetry, onDismiss, onHome)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(onHome: () -> Unit) {
    val t = rememberInfiniteTransition(label = "empty")
    val bob by t.animateFloat(-1f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "pulse")
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Canvas(Modifier.size(150.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            for (i in 0..1) {
                val k = (pulse + i * .5f) % 1f
                drawCircle(Color.White.copy(.25f * (1f - k)), size.minDimension * (.25f + .25f * k), c, style = Stroke(2.dp.toPx()))
            }
            drawCircle(Color.White.copy(.12f), size.minDimension * .28f, c)
            val r = size.minDimension * .14f
            val top = Offset(c.x, c.y - r + bob * 5.dp.toPx())
            val bot = Offset(c.x, c.y + r * .8f + bob * 5.dp.toPx())
            val w = 4.dp.toPx()
            drawLine(Color.White, top, bot, w, StrokeCap.Round)
            drawLine(Color.White, bot, Offset(bot.x - r * .6f, bot.y - r * .6f), w, StrokeCap.Round)
            drawLine(Color.White, bot, Offset(bot.x + r * .6f, bot.y - r * .6f), w, StrokeCap.Round)
            drawLine(Color.White.copy(.8f), Offset(c.x - r, c.y + r * 1.35f), Offset(c.x + r, c.y + r * 1.35f), w, StrokeCap.Round)
        }
        Spacer(Modifier.height(16.dp))
        Text("Загрузок пока нет", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Откройте «Системы» и нажмите «Скачать». Загрузка продолжится даже если приложение закрыто, а в конце придёт уведомление.",
            color = Color.White.copy(.6f), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp, bottom = 20.dp),
        )
        Button(onHome, shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text("К системам") }
    }
}

@Composable
private fun DlCard(
    s: DlState, mod: Modifier,
    onCancel: (String) -> Unit, onRetry: (String) -> Unit, onDismiss: (String) -> Unit, onHome: () -> Unit,
) {
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(500, easing = FastOutSlowInEasing)) }
    val p by animateFloatAsState(if (s.status == DlStatus.DONE) 1f else s.fraction, tween(500, easing = LinearOutSlowInEasing), label = "p")
    val t = rememberInfiniteTransition(label = "dl")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "phase")
    val shimmer by t.animateFloat(-.3f, 1.3f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "shimmer")
    val failed = s.status == DlStatus.FAILED
    val done = s.status == DlStatus.DONE

    Box(
        mod.fillMaxWidth()
            .graphicsLayer {
                alpha = appear.value
                translationY = (1f - appear.value) * 60.dp.toPx()
                val sc = .94f + .06f * appear.value; scaleX = sc; scaleY = sc
            }
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(s.c1), Color(s.c2))), RoundedCornerShape(26.dp)),
    ) {
        // «жидкая» заливка: цветная волна движется вслед за прогрессом
        Canvas(Modifier.matchParentSize()) {
            val w = size.width; val h = size.height
            val edge = w * p
            val amp = 8.dp.toPx() * minOf(1f, p * 10f) * minOf(1f, (1f - p) * 10f)
            val path = Path().apply {
                moveTo(0f, 0f); lineTo(edge, 0f)
                var y = 0f
                while (y <= h) { lineTo(edge + sin(y / h * TAU * 2f + phase * TAU) * amp, y); y += 8f }
                lineTo(0f, h); close()
            }
            drawPath(path, Color.White.copy(.13f))
        }
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ring(p, phase, s.status)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        when {
                            failed -> s.error ?: "Ошибка"
                            done && s.phase == DlPhase.INSTALL -> "Установлено"
                            done -> "Готово · ${mbText(s.total)} МБ"
                            s.phase == DlPhase.INSTALL -> "Установка · ${s.stage.ifBlank { "подготовка…" }}"
                            s.total == 0L -> "Подключение…"
                            else -> "Скачивание · ${mbText(s.done)} из ${mbText(s.total)} МБ · ${fmtSpeed(s.speed)}"
                        },
                        color = if (failed) Color(0xFFFFB4B4) else Color.White.copy(.85f), fontSize = 13.sp,
                        maxLines = if (failed) 12 else 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp),
                    )
                    if (!failed) Text(
                        when {
                            done -> "Вернитесь в «Системы» и нажмите «Запустить»"
                            s.etaSec != null -> "${(p * 100).toInt()}% · осталось ~ ${fmtEta(s.etaSec!!)}"
                            else -> "Расчёт времени…"
                        },
                        color = Color.White.copy(.65f), fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp),
                    )
                }
            }
            if (s.status == DlStatus.ACTIVE) {
                Spacer(Modifier.height(14.dp))
                Canvas(Modifier.fillMaxWidth().height(8.dp)) {
                    val r = CornerRadius(size.height / 2)
                    drawRoundRect(Color.White.copy(.2f), Offset.Zero, size, r)
                    val fw = size.width * p
                    if (fw > 0f) {
                        drawRoundRect(Color.White, Offset.Zero, Size(fw, size.height), r)
                        val cx = size.width * shimmer
                        drawRoundRect(
                            Brush.horizontalGradient(listOf(Color.Transparent, Color(0xFF9FB4FF).copy(.9f), Color.Transparent), startX = cx - 70f, endX = cx + 70f),
                            Offset.Zero, Size(fw, size.height), r,
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.End) {
                when (s.status) {
                    DlStatus.ACTIVE -> TextButton({ onCancel(s.id) }) { Text("Отмена", color = Color.White) }
                    DlStatus.DONE -> {
                        TextButton({ onDismiss(s.id) }) { Text("Убрать", color = Color.White.copy(.75f)) }
                        TextButton({ onHome() }) { Text("К системам", color = Color.White) }
                    }
                    DlStatus.FAILED -> {
                        TextButton({ onDismiss(s.id) }) { Text("Убрать", color = Color.White.copy(.75f)) }
                        TextButton({ onRetry(s.id) }) { Text("Повторить", color = Color.White) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Ring(p: Float, phase: Float, status: DlStatus) {
    val done = status == DlStatus.DONE
    val failed = status == DlStatus.FAILED
    val check by animateFloatAsState(if (done) 1f else 0f, tween(600, delayMillis = 200), label = "check")
    val pop by animateFloatAsState(if (done) 1f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "pop")
    Box(Modifier.size(76.dp).graphicsLayer { val sc = 1f + .08f * pop; scaleX = sc; scaleY = sc }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 7.dp.toPx(); val inset = stroke / 2 + 2.dp.toPx()
            val tl = Offset(inset, inset); val sz = Size(size.width - 2 * inset, size.height - 2 * inset)
            drawArc(Color.White.copy(.2f), 0f, 360f, false, tl, sz, style = Stroke(stroke))
            if (!done && !failed) drawArc(Color.White.copy(.35f), phase * 360f, 50f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            val col = when { failed -> Color(0xFFFF6B6B); done -> Color(0xFF7CF29A); else -> Color.White }
            drawArc(col, -90f, 360f * p, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (done) {
                val a = Offset(size.width * .30f, size.height * .52f)
                val b = Offset(size.width * .45f, size.height * .67f)
                val c = Offset(size.width * .72f, size.height * .36f)
                val k1 = (check / .4f).coerceIn(0f, 1f); val k2 = ((check - .4f) / .6f).coerceIn(0f, 1f)
                drawLine(Color.White, a, mix(a, b, k1), stroke, StrokeCap.Round)
                if (k2 > 0f) drawLine(Color.White, b, mix(b, c, k2), stroke, StrokeCap.Round)
            }
        }
        if (!done) Text(if (failed) "!" else "${(p * 100).toInt()}%", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

/** Нижняя панель вкладок «Системы» / «Загрузки» со значком количества активных загрузок. */
@Composable
fun BottomTabs(tab: Int, active: Int, onTab: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0B0D14)).navigationBarsPadding().padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        TabItem("Системы", tab == 0, 0, false) { onTab(0) }
        TabItem("Загрузки", tab == 1, active, true) { onTab(1) }
    }
}

@Composable
private fun TabItem(label: String, selected: Boolean, badge: Int, arrow: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Color.White.copy(.14f) else Color.Transparent, tween(300), label = "tabbg")
    val fg by animateColorAsState(if (selected) Color.White else Color.White.copy(.55f), tween(300), label = "tabfg")
    val t = rememberInfiniteTransition(label = "tab")
    val bob by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val badgeScale by animateFloatAsState(if (badge > 0) 1f else 0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "bs")
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 8.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box {
                Canvas(Modifier.size(24.dp)) {
                    val w = size.width
                    val sw = 2.2.dp.toPx()
                    if (arrow) {
                        val dy = if (badge > 0) bob * 3.dp.toPx() else 0f
                        val top = Offset(w / 2, w * .18f + dy); val bot = Offset(w / 2, w * .66f + dy)
                        drawLine(fg, top, bot, sw, StrokeCap.Round)
                        drawLine(fg, bot, Offset(bot.x - w * .2f, bot.y - w * .2f), sw, StrokeCap.Round)
                        drawLine(fg, bot, Offset(bot.x + w * .2f, bot.y - w * .2f), sw, StrokeCap.Round)
                        drawLine(fg, Offset(w * .2f, w * .88f), Offset(w * .8f, w * .88f), sw, StrokeCap.Round)
                    } else {
                        val s = w * .38f; val r = CornerRadius(w * .08f)
                        for (i in 0..1) for (j in 0..1)
                            drawRoundRect(fg, Offset(w * .1f + i * w * .44f, w * .1f + j * w * .44f), Size(s, s), r)
                    }
                }
                if (badgeScale > .01f) Box(
                    Modifier.align(Alignment.TopEnd).offset(10.dp, (-4).dp).size(16.dp)
                        .graphicsLayer { scaleX = badgeScale; scaleY = badgeScale }
                        .clip(CircleShape).background(Color(0xFFFF5C7A)),
                    contentAlignment = Alignment.Center,
                ) { Text("$badge", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold) }
            }
            Text(label, color = fg, fontSize = 12.sp)
        }
    }
}
