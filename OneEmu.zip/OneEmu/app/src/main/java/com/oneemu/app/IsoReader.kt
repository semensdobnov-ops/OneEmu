package com.oneemu.app

import java.io.File
import java.io.RandomAccessFile

/**
 * Минимальный читатель ISO9660: достаёт файлы из корня образа (kernel, initrd.img).
 * Нужен, чтобы запускать Android-x86 напрямую, с нашими параметрами ядра, не заходя в меню загрузчика.
 */
object IsoReader {
    private const val SECTOR = 2048

    private fun le32(b: ByteArray, o: Int): Long =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)

    /** Имя из ISO9660: "INITRD.IMG;1" → "initrd.img", "KERNEL." → "kernel". */
    private fun norm(n: String): String = n.substringBefore(';').trimEnd('.').lowercase()

    /** Копирует из корня образа файлы [want] (имя в образе → куда сохранить). Возвращает true, если нашлись все. */
    fun extractRoot(iso: File, want: Map<String, File>): Boolean = runCatching {
        RandomAccessFile(iso, "r").use { r ->
            val pvd = ByteArray(SECTOR)
            r.seek(16L * SECTOR); r.readFully(pvd)
            if (pvd[0].toInt() != 1 || String(pvd, 1, 5, Charsets.US_ASCII) != "CD001") return@use false
            // корневая запись каталога лежит в PVD со смещения 156
            val rootLba = le32(pvd, 156 + 2)
            val rootLen = le32(pvd, 156 + 10).toInt()
            val dir = ByteArray(rootLen)
            r.seek(rootLba * SECTOR); r.readFully(dir)
            val found = HashMap<String, Pair<Long, Long>>()
            var p = 0
            while (p < rootLen) {
                val len = dir[p].toInt() and 0xFF
                if (len == 0) { p = (p / SECTOR + 1) * SECTOR; continue }
                val nameLen = dir[p + 32].toInt() and 0xFF
                val name = norm(String(dir, p + 33, nameLen, Charsets.ISO_8859_1))
                if (name in want) found[name] = le32(dir, p + 2) to le32(dir, p + 10)
                p += len
            }
            if (!want.keys.all { it in found }) return@use false
            for ((name, dst) in want) {
                val (lba, size) = found.getValue(name)
                dst.parentFile?.mkdirs()
                r.seek(lba * SECTOR)
                dst.outputStream().use { o ->
                    val buf = ByteArray(1 shl 20)
                    var left = size
                    while (left > 0) {
                        val n = r.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n <= 0) return@use false
                        o.write(buf, 0, n); left -= n
                    }
                }
            }
            true
        }
    }.getOrDefault(false)
}
