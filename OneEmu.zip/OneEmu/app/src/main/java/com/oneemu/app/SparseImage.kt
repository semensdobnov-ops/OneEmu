package com.oneemu.app

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/** Android sparse image (как у GSI от Google) → обычный raw-образ, который понимает QEMU. */
object SparseImage {
    private const val MAGIC = 0xED26FF3A.toInt()

    fun isSparse(f: File): Boolean = runCatching {
        f.inputStream().use { i ->
            val b = ByteArray(4)
            i.read(b) == 4 && ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int == MAGIC
        }
    }.getOrDefault(false)

    fun toRaw(src: File, dst: File, cancel: AtomicBoolean? = null, onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        val srcLen = src.length().coerceAtLeast(1L)
        RandomAccessFile(src, "r").use { inp ->
            val h = ByteArray(28); inp.readFully(h)
            val hb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
            hb.int // magic
            hb.short; hb.short // версия
            val fileHdr = hb.short.toInt() and 0xFFFF
            val chunkHdr = hb.short.toInt() and 0xFFFF
            val blk = hb.int
            val totalBlks = hb.int
            val chunks = hb.int
            inp.seek(fileHdr.toLong())
            RandomAccessFile(dst, "rw").use { out ->
                out.setLength(totalBlks.toLong() * blk)
                var pos = 0L
                val buf = ByteArray(1 shl 20)
                repeat(chunks) {
                    if (cancel?.get() == true) throw InstallError("Установка отменена")
                    onProgress(inp.filePointer, srcLen)
                    val ch = ByteArray(12); inp.readFully(ch)
                    val cb = ByteBuffer.wrap(ch).order(ByteOrder.LITTLE_ENDIAN)
                    val type = cb.short.toInt() and 0xFFFF
                    cb.short
                    val n = cb.int.toLong() and 0xFFFFFFFFL
                    val totalSz = cb.int.toLong() and 0xFFFFFFFFL
                    val bytes = n * blk
                    if (chunkHdr > 12) inp.skipBytes(chunkHdr - 12)
                    when (type) {
                        0xCAC1 -> { // RAW
                            out.seek(pos)
                            var left = bytes
                            while (left > 0) {
                                val r = minOf(left, buf.size.toLong()).toInt()
                                inp.readFully(buf, 0, r); out.write(buf, 0, r); left -= r
                            }
                            pos += bytes
                        }
                        0xCAC2 -> { // FILL
                            val f = ByteArray(4); inp.readFully(f)
                            if (f.any { it != 0.toByte() }) {
                                out.seek(pos)
                                val pat = ByteArray(blk) { f[it % 4] }
                                for (k in 0 until n) out.write(pat)
                            }
                            pos += bytes
                        }
                        0xCAC3 -> pos += bytes            // DONT_CARE (нули)
                        0xCAC4 -> inp.skipBytes(4)        // CRC32
                        else -> inp.skipBytes((totalSz - chunkHdr).toInt())
                    }
                }
            }
        }
    }
}
