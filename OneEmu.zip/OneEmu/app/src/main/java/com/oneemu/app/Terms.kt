package com.oneemu.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Меняйте номер версии, когда обновляете текст — приложение снова спросит согласие. */
private const val TERMS_VERSION = 1

object TermsStore {
    fun accepted(ctx: Context) =
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).getInt("terms_ok", 0) >= TERMS_VERSION

    fun accept(ctx: Context) =
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).edit().putInt("terms_ok", TERMS_VERSION).apply()
}

private val SECTIONS = listOf(
    "1. Что такое OneEmu" to
        "OneEmu — бесплатное приложение-эмулятор. Оно запускает образы операционных систем в виртуальной машине (QEMU) на вашем телефоне. Приложение предоставляется «как есть», без каких-либо гарантий.",
    "2. Ограничение ответственности" to
        "Вы используете приложение на свой страх и риск. Разработчик не несёт ответственности за любой ущерб, который может возникнуть при его установке или использовании, в том числе за:\n" +
        "• поломку, зависание, бесконечную перезагрузку или потерю работоспособности телефона;\n" +
        "• перегрев, износ и быстрый разряд батареи;\n" +
        "• потерю или повреждение данных, фото, контактов, файлов и приложений;\n" +
        "• нехватку памяти на устройстве;\n" +
        "• расходы на мобильный интернет (образы весят от сотен мегабайт до нескольких гигабайт);\n" +
        "• потерю гарантии на устройство;\n" +
        "• любые прямые и косвенные убытки.\n\n" +
        "Эмуляция сильно нагружает процессор и память. Заранее сделайте резервную копию важных данных и не запускайте эмуляцию при низком заряде.",
    "3. Образы систем" to
        "Образы систем (LineageOS, Android и др.) создаются третьими лицами и распространяются по их собственным лицензиям. Приложение скачивает их с сайтов третьих лиц (например, GitHub). Разработчик не контролирует эти файлы и не отвечает за их содержимое, безопасность и работу. Вы сами отвечаете за право использовать выбранный образ.",
    "4. Ваши обязанности" to
        "Используйте приложение только законно. Не вводите внутри эмулируемой системы пароли и данные от важных аккаунтов, если не доверяете образу.",
    "5. Конфиденциальность" to
        "Приложение не требует регистрации и не отправляет ваши личные данные разработчику. Сайты, с которых скачиваются образы, видят ваш IP-адрес по своим правилам.",
    "6. Изменения" to
        "Разработчик может изменять соглашение и приложение. Продолжая пользоваться приложением, вы принимаете новую версию.",
)

@Composable
fun TermsScreen(onAccept: () -> Unit, onDecline: () -> Unit) {
    var checked by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0D14)).statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
        Text("Пользовательское соглашение", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(4.dp))
        Text("Прочитайте перед использованием OneEmu", fontSize = 13.sp, color = Color.White.copy(.6f))
        Spacer(Modifier.height(14.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            SECTIONS.forEach { (title, body) ->
                Text(title, fontWeight = FontWeight.SemiBold, color = Color.White, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(body, color = Color.White.copy(.8f), fontSize = 14.sp, lineHeight = 20.sp)
                Spacer(Modifier.height(14.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(checked, { checked = it })
            Text(
                "Я прочитал(а) соглашение и понимаю, что разработчик не отвечает за возможные проблемы с моим телефоном",
                color = Color.White, fontSize = 13.sp, lineHeight = 17.sp,
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onAccept, enabled = checked, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Принимаю") }
        TextButton(onClick = onDecline, modifier = Modifier.fillMaxWidth()) { Text("Не принимаю, выйти") }
    }
}
