package com.oneemu.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.net.ConnectivityManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

internal fun fmtEta(sec: Long): String = when {
    sec < 60 -> "$sec с"
    sec < 3600 -> "${sec / 60} мин ${sec % 60} с"
    else -> "${sec / 3600} ч ${(sec % 3600) / 60} мин"
}

internal fun fmtSpeed(bps: Double): String =
    if (bps >= 1048576) "%.1f МБ/с".format(bps / 1048576) else "%.0f КБ/с".format(bps / 1024)

object Notif {
    const val CH_PROGRESS = "dl_progress_v2"
    const val CH_START = "install_start"
    const val START_ID = 4002
    const val CH_DONE = "dl_done"
    const val FG_ID = 4001

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Загрузка и установка систем", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Система готова", NotificationManager.IMPORTANCE_HIGH))
        // Короткое всплывающее «Система устанавливается, подождите» в начале установки (без звука).
        nm.createNotificationChannel(NotificationChannel(CH_START, "Начало установки", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false)
        })
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun progress(
        ctx: Context, text: String, percent: Int, indeterminate: Boolean,
        title: String = "OneEmu — загрузка", sub: String? = null,
    ): Notification {
        val cancel = PendingIntent.getService(
            ctx, 1, Intent(ctx, DownloadService::class.java).setAction("cancel"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (sub.isNullOrBlank()) text else "$text\n$sub"))
            .setSubText(if (indeterminate) null else "$percent%")
            .setProgress(100, percent, indeterminate)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp(ctx))
            .addAction(0, "Отменить", cancel)
            .build()
    }

    /** Обновляет общее уведомление по всем активным загрузкам и установкам: проценты и оставшееся время. */
    @SuppressLint("MissingPermission")
    fun updateProgress(ctx: Context) {
        val act = Downloads.active()
        if (act.isEmpty()) return
        val pct = (act.map { it.fraction }.average() * 100).toInt().coerceIn(0, 100)
        val eta = act.mapNotNull { it.etaSec }.maxOrNull()
        val title = when {
            act.all { it.phase == DlPhase.INSTALL } -> "OneEmu — установка"
            act.all { it.phase == DlPhase.DOWNLOAD } -> "OneEmu — загрузка"
            else -> "OneEmu — загрузка и установка"
        }
        val head = when {
            act.size > 1 -> "Систем в работе: ${act.size} · $pct%"
            act[0].phase == DlPhase.INSTALL -> "${act[0].name} устанавливается, подождите · $pct%"
            else -> "${act[0].name}: $pct%"
        }
        val text = head + " · " + (eta?.let { "осталось ${fmtEta(it)}" } ?: "считаю время…")
        val stage = if (act.size == 1) act[0].stage.takeIf { it.isNotBlank() } else null
        val indeterminate = act.all { it.total == 0L }
        runCatching { NotificationManagerCompat.from(ctx).notify(FG_ID, progress(ctx, text, pct, indeterminate, title, stage)) }
    }

    /** Всплывающее уведомление в момент начала установки (исчезает само через несколько секунд). */
    @SuppressLint("MissingPermission")
    fun installStarted(ctx: Context, name: String) {
        val text = "$name: подождите, установка займёт несколько минут. Можно свернуть приложение — вы получите уведомление, когда всё будет готово."
        val n = NotificationCompat.Builder(ctx, CH_START)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Система устанавливается")
            .setContentText("$name: подождите, это займёт несколько минут")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setTimeoutAfter(10_000).setAutoCancel(true).setContentIntent(openApp(ctx))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(START_ID, n) }
    }

    @SuppressLint("MissingPermission")
    fun done(ctx: Context, id: String, name: String) {
        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Система установлена")
            .setContentText("$name установлена — откройте OneEmu и нажмите «Запустить»")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$name установлена — откройте OneEmu и нажмите «Запустить»"))
            .setAutoCancel(true).setContentIntent(openApp(ctx))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(("done_$id").hashCode(), n) }
    }

    @SuppressLint("MissingPermission")
    fun failed(ctx: Context, id: String, name: String, msg: String) {
        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Не удалось установить $name")
            .setContentText(msg)
            .setAutoCancel(true).setContentIntent(openApp(ctx))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(("fail_$id").hashCode(), n) }
    }
}

/** Foreground-сервис: загрузка идёт, даже если приложение свёрнуто или закрыто смахиванием. */
class DownloadService : Service() {
    private val pool = Executors.newCachedThreadPool()
    private val running = AtomicInteger(0)
    private val lock = Any()
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Use Android's current default network. This deliberately does not bind downloads to Wi‑Fi:
        // when Wi‑Fi is off, Android routes these sockets over the active cellular network.
        runCatching {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager)
                .bindProcessToNetwork(null)
        }
        Notif.ensureChannels(this)
        ServiceCompat.startForeground(
            this, Notif.FG_ID,
            if (intent?.action == "import") Notif.progress(this, "Подготовка установки…", 0, true, "OneEmu — установка")
            else Notif.progress(this, "Подготовка загрузки…", 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
        if (intent?.action == "cancel") {
            Downloads.cancelAll()
            synchronized(lock) { if (running.get() == 0) finish() }
            return START_NOT_STICKY
        }
        val id = intent?.getStringExtra("id")
        val url = intent?.getStringExtra("url")
        val importUri = if (intent?.action == "import") intent?.data else null
        if (id == null || (url == null && importUri == null)) {
            synchronized(lock) { if (running.get() == 0) finish() }
            return START_NOT_STICKY
        }
        val name = intent?.getStringExtra("name") ?: id
        Downloads.ensure(this, id, name, importUri != null) // нужно, если сервис перезапущен системой в новом процессе
        val mb = intent?.getIntExtra("mb", 0) ?: 0
        val bundle = intent?.getBooleanExtra("bundle", false) ?: false
        synchronized(lock) {
            if (wl == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OneEmu:download").apply { acquire(3 * 60 * 60 * 1000L) }
            }
            running.incrementAndGet()
        }
        val gsi = intent?.getBooleanExtra("gsi", false) ?: false
        pool.execute {
            try {
                if (importUri != null) workImport(id, name, importUri, gsi) else work(id, name, url!!, mb, bundle)
            } finally {
                synchronized(lock) { if (running.decrementAndGet() == 0) finish() }
            }
        }
        // Если система убьёт процесс (экономия батареи у Samsung и др.), установка перезапустится сама.
        return START_REDELIVER_INTENT
    }

    private fun finish() {
        runCatching { wl?.takeIf { it.isHeld }?.release() }
        wl = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Считает сглаженную скорость и раз в секунду обновляет уведомление, раз в 250 мс — экран «Загрузки». */
    private inner class Reporter(private val id: String, private val name: String) {
        private var phase = DlPhase.DOWNLOAD
        private var lastT = System.nanoTime(); private var lastB = 0L; private var sp = 0.0
        private var lastUi = 0L; private var lastNotif = 0L

        private fun speed(done: Long): Double {
            val now = System.nanoTime()
            val dt = (now - lastT) / 1e9
            if (dt >= 0.5) {
                val inst = (done - lastB) / dt
                sp = if (sp == 0.0) inst else sp * 0.75 + inst * 0.25
                lastT = now; lastB = done
            }
            return sp
        }

        fun emit(p: DlPhase, stage: String, done: Long, total: Long) {
            var force = false
            if (p != phase) { // переход «скачивание → установка»: скорость считаем заново
                phase = p; sp = 0.0; lastT = System.nanoTime(); lastB = done; force = true
                if (p == DlPhase.INSTALL) Notif.installStarted(this@DownloadService, name)
            }
            val speed = speed(done)
            val ms = System.currentTimeMillis()
            if (!force && ms - lastUi < 250 && done < total) return
            lastUi = ms
            Downloads.update(id) { it.copy(done = done, total = total, speed = speed, phase = p, stage = stage) }
            if (force || ms - lastNotif >= 1000) { lastNotif = ms; Notif.updateProgress(this@DownloadService) }
        }
    }

    private fun finishOk(id: String, name: String, image: String, phase: DlPhase) {
        // сначала сохраняем путь к образу, потом сообщаем интерфейсу
        Repo.setImage(this, id, image)
        Downloads.update(id) {
            val t = maxOf(it.total, it.done)
            it.copy(done = t, total = t, speed = 0.0, status = DlStatus.DONE, phase = phase, stage = "")
        }
        Notif.done(this, id, name)
    }

    private fun finishFail(id: String, name: String, flag: java.util.concurrent.atomic.AtomicBoolean, e: Exception, hint: String) {
        if (flag.get()) { Downloads.remove(id); return }
        val base = e.message ?: "Неизвестная ошибка"
        val msg = if (e is InstallError) base else "$base\n$hint"
        Downloads.update(id) { it.copy(status = DlStatus.FAILED, error = msg, speed = 0.0, stage = "") }
        Notif.failed(this, id, name, base.lineSequence().first())
    }

    private fun work(id: String, name: String, url: String, mb: Int, bundle: Boolean) {
        val flag = Downloads.flag(id)
        val rep = Reporter(id, name)
        try {
            val f = Downloader.download(
                this, id, url, mb, flag, bundle,
                onInstall = { stage, done, total -> rep.emit(DlPhase.INSTALL, stage, done, total) },
            ) { done, total -> rep.emit(DlPhase.DOWNLOAD, "", done, total) }
            finishOk(id, name, f.absolutePath, if (bundle) DlPhase.INSTALL else DlPhase.DOWNLOAD)
        } catch (e: Exception) {
            finishFail(id, name, flag, e, "Проверьте интернет и свободное место на телефоне (нужно в 2–3 раза больше размера образа).")
        }
    }

    /** Установка из файла, выбранного пользователем: копирование, распаковка и т.д. идут в фоне. */
    private fun workImport(id: String, name: String, uri: android.net.Uri, gsi: Boolean) {
        val flag = Downloads.flag(id)
        val rep = Reporter(id, name)
        try {
            val progress: InstallProgress = { stage, done, total -> rep.emit(DlPhase.INSTALL, stage, done, total) }
            val path = if (gsi) importGsi(this, uri, id, flag, progress) else importImage(this, uri, id, flag, progress)
            finishOk(id, name, path, DlPhase.INSTALL)
        } catch (e: Exception) {
            finishFail(id, name, flag, e, "Не удалось прочитать или распаковать файл (возможно, не хватает места на телефоне).")
        }
    }

    override fun onDestroy() {
        runCatching { wl?.takeIf { it.isHeld }?.release() }
        pool.shutdown()
        super.onDestroy()
    }
}
