package com.oneemu.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

internal fun fmtEta(sec: Long): String = when {
    sec < 60 -> "$sec с"
    sec < 3600 -> "${sec / 60} мин ${sec % 60} с"
    else -> "${sec / 3600} ч ${(sec % 3600) / 60} мин"
}

internal fun fmtSpeed(bps: Double): String =
    if (bps >= 1048576) "%.1f МБ/с".format(bps / 1048576) else "%.0f КБ/с".format(bps / 1024)

object Notif {
    const val CH_PROGRESS = "dl_progress"
    const val CH_DONE = "dl_done"
    const val FG_ID = 4001

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Загрузка систем", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Система скачана", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun progress(ctx: Context, text: String, percent: Int, indeterminate: Boolean): Notification {
        val cancel = PendingIntent.getService(
            ctx, 1, Intent(ctx, DownloadService::class.java).setAction("cancel"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("OneEmu — загрузка")
            .setContentText(text)
            .setProgress(100, percent, indeterminate)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .addAction(0, "Отменить", cancel)
            .build()
    }

    /** Обновляет общее уведомление по всем активным загрузкам. */
    @SuppressLint("MissingPermission")
    fun updateProgress(ctx: Context) {
        val act = Downloads.active()
        if (act.isEmpty()) return
        val done = act.sumOf { it.done }; val total = act.sumOf { it.total }
        val pct = if (total > 0) (done * 100 / total).toInt() else 0
        val eta = act.mapNotNull { it.etaSec }.maxOrNull()
        val text = (if (act.size == 1) "${act[0].name}: $pct%" else "Скачивается систем: ${act.size} · $pct%") +
            (eta?.let { " · осталось ${fmtEta(it)}" } ?: "")
        runCatching { NotificationManagerCompat.from(ctx).notify(FG_ID, progress(ctx, text, pct, total == 0L)) }
    }

    @SuppressLint("MissingPermission")
    fun done(ctx: Context, id: String, name: String) {
        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Система скачана")
            .setContentText("$name готова — откройте OneEmu и нажмите «Запустить»")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$name готова — откройте OneEmu и нажмите «Запустить»"))
            .setAutoCancel(true).setContentIntent(openApp(ctx))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(("done_$id").hashCode(), n) }
    }

    @SuppressLint("MissingPermission")
    fun failed(ctx: Context, id: String, name: String, msg: String) {
        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("Не удалось скачать $name")
            .setContentText(msg)
            .setAutoCancel(true).setContentIntent(openApp(ctx))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(("fail_$id").hashCode(), n) }
    }
}

/** Foreground-сервис: загрузка идёт, даже если приложение свёрнуто или закрыто смахиванием. */
class DownloadService : Service() {
    private val pool = Executors.newCachedThreadPool()
    private val running = AtomicInteger(0)
    private val lock = Any()
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notif.ensureChannels(this)
        ServiceCompat.startForeground(
            this, Notif.FG_ID, Notif.progress(this, "Подготовка загрузки…", 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
        if (intent?.action == "cancel") {
            Downloads.cancelAll()
            synchronized(lock) { if (running.get() == 0) finish() }
            return START_NOT_STICKY
        }
        val id = intent?.getStringExtra("id")
        val url = intent?.getStringExtra("url")
        if (id == null || url == null) {
            synchronized(lock) { if (running.get() == 0) finish() }
            return START_NOT_STICKY
        }
        val name = intent?.getStringExtra("name") ?: id
        val mb = intent?.getIntExtra("mb", 0) ?: 0
        synchronized(lock) {
            if (wl == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "OneEmu:download").apply { acquire(3 * 60 * 60 * 1000L) }
            }
            running.incrementAndGet()
        }
        pool.execute {
            try { work(id, name, url, mb) } finally {
                synchronized(lock) { if (running.decrementAndGet() == 0) finish() }
            }
        }
        return START_NOT_STICKY
    }

    private fun finish() {
        runCatching { wl?.takeIf { it.isHeld }?.release() }
        wl = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun work(id: String, name: String, url: String, mb: Int) {
        val flag = Downloads.flag(id)
        var lastT = System.nanoTime(); var lastB = 0L; var sp = 0.0; var lastNotif = 0L
        try {
            val f = Downloader.download(this, id, url, mb, flag) { done, total ->
                val now = System.nanoTime()
                val dt = (now - lastT) / 1e9
                if (dt >= 0.5) {
                    val inst = (done - lastB) / dt
                    sp = if (sp == 0.0) inst else sp * 0.75 + inst * 0.25
                    lastT = now; lastB = done
                }
                val speed = sp
                Downloads.update(id) { it.copy(done = done, total = total, speed = speed) }
                val ms = System.currentTimeMillis()
                if (ms - lastNotif >= 1000) { lastNotif = ms; Notif.updateProgress(this) }
            }
            // сначала сохраняем путь к образу, потом сообщаем интерфейсу
            Repo.setImage(this, id, f.absolutePath)
            Downloads.update(id) { it.copy(done = maxOf(it.total, it.done), total = maxOf(it.total, it.done), speed = 0.0, status = DlStatus.DONE) }
            Notif.done(this, id, name)
        } catch (e: Exception) {
            if (flag.get()) {
                Downloads.remove(id)
            } else {
                val msg = (e.message ?: "Неизвестная ошибка") + "\nПроверьте интернет и свободное место (нужно около ${mb * 2} МБ)."
                Downloads.update(id) { it.copy(status = DlStatus.FAILED, error = msg, speed = 0.0) }
                Notif.failed(this, id, name, e.message ?: "Неизвестная ошибка")
            }
        }
    }

    override fun onDestroy() {
        runCatching { wl?.takeIf { it.isHeld }?.release() }
        pool.shutdown()
        super.onDestroy()
    }
}
