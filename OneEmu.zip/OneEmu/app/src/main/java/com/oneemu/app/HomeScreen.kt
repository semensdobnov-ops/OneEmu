package com.oneemu.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import kotlin.math.absoluteValue

@Composable
fun HomeScreen(
    items: List<OsEntry>,
    onPick: (OsEntry) -> Unit,
    onRun: (OsEntry) -> Unit,
    onSetup: (OsEntry) -> Unit,
    onAdd: () -> Unit,
) {
    val pager = rememberPagerState(pageCount = { items.size + 1 })
    val cur = items.getOrNull(pager.currentPage)
    val top by animateColorAsState(Color(cur?.c1 ?: 0xFF444B66), label = "bg")
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(top.copy(alpha = .55f), Color(0xFF0B0D14), Color(0xFF0B0D14))))
            .statusBarsPadding().navigationBarsPadding(),
    ) {
        Text("OneEmu", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(24.dp, 20.dp, 24.dp, 0.dp))
        Text("Листайте и выбирайте систему", color = Color.White.copy(.6f), modifier = Modifier.padding(horizontal = 24.dp))
        HorizontalPager(
            state = pager,
            contentPadding = PaddingValues(horizontal = 44.dp),
            pageSpacing = 14.dp,
            modifier = Modifier.weight(1f).padding(vertical = 20.dp),
        ) { page ->
            val off = ((pager.currentPage - page) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
            val mod = Modifier.fillMaxSize().graphicsLayer {
                val s = lerp(.88f, 1f, 1f - off); scaleX = s; scaleY = s; alpha = lerp(.5f, 1f, 1f - off)
            }
            val e = items.getOrNull(page)
            if (e == null) AddCard(mod, onAdd) else OsCard(e, mod, onPick, onRun, onSetup)
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), horizontalArrangement = Arrangement.Center) {
            repeat(items.size + 1) {
                val sel = it == pager.currentPage
                Box(Modifier.padding(4.dp).size(if (sel) 22.dp else 8.dp, 8.dp).clip(CircleShape).background(Color.White.copy(if (sel) .95f else .3f)))
            }
        }
    }
}

@Composable
private fun OsCard(e: OsEntry, mod: Modifier, onPick: (OsEntry) -> Unit, onRun: (OsEntry) -> Unit, onSetup: (OsEntry) -> Unit) {
    Column(
        mod.clip(RoundedCornerShape(32.dp))
            .background(Brush.linearGradient(listOf(Color(e.c1), Color(e.c2))))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(110.dp).clip(CircleShape).background(Color.White.copy(.16f)), contentAlignment = Alignment.Center) {
            Text(e.name.take(1).uppercase(), fontSize = 52.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Spacer(Modifier.height(24.dp))
        Text(e.name, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
        Text(e.subtitle, color = Color.White.copy(.75f), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(16.dp))
        Text("${e.ramMb / 1024.0} ГБ RAM · ${e.cores} ядра · ${e.diskGb} ГБ", color = Color.White.copy(.8f), fontSize = 13.sp)
        Text(
            if (e.image == null) "Образ не выбран" else "Образ: " + e.image.substringAfterLast('/'),
            color = Color.White.copy(.6f), fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp),
        )
        Spacer(Modifier.weight(1f))
        Button(
            onClick = { if (e.image == null) onPick(e) else onRun(e) },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
            shape = RoundedCornerShape(18.dp),
        ) { Text(if (e.image == null) "Выбрать образ" else "Запустить", fontWeight = FontWeight.SemiBold) }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton({ onSetup(e) }) { Text("Настроить", color = Color.White) }
            if (e.image != null) TextButton({ onPick(e) }) { Text("Сменить образ", color = Color.White) }
        }
    }
}

@Composable
private fun AddCard(mod: Modifier, onAdd: () -> Unit) {
    Column(
        mod.clip(RoundedCornerShape(32.dp)).background(Color.White.copy(.07f)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Text("+", fontSize = 80.sp, color = Color.White.copy(.9f))
        Text("Добавить свою систему", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
        Text("Образ .img, .iso или .qcow2", color = Color.White.copy(.6f), modifier = Modifier.padding(top = 6.dp, bottom = 24.dp))
        Button(onClick = onAdd, shape = RoundedCornerShape(18.dp)) { Text("Добавить") }
    }
}
