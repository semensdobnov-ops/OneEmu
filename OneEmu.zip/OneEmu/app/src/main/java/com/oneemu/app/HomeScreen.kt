@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.oneemu.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import kotlin.math.PI
import kotlin.math.absoluteValue
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HomeScreen(
    items: List<OsEntry>,
    onPick: (OsEntry) -> Unit,
    onDownload: (OsEntry) -> Unit,
    onSite: (OsEntry) -> Unit,
    onRun: (OsEntry) -> Unit,
    onSetup: (OsEntry) -> Unit,
    onAdd: () -> Unit,
    dlActive: Map<String, DlState> = emptyMap(),
    onOpenDownloads: () -> Unit = {},
) {
    var selectedId by androidx.compose.runtime.remember(items) {
        androidx.compose.runtime.mutableStateOf(items.firstOrNull()?.id ?: "")
    }
    var menuOpen by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val selected = items.firstOrNull { it.id == selectedId } ?: items.firstOrNull()
    val top by animateColorAsState(Color(selected?.c1 ?: 0xFF444B66), tween(500), label = "bg")
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(top.copy(alpha = .6f), Color(0xFF0B0D14), Color(0xFF0B0D14))))
            .statusBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Text("OneEmu", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(top = 20.dp))
        Text("Все версии Android в одном каталоге", color = Color.White.copy(.6f), modifier = Modifier.padding(bottom = 14.dp))
        Box {
            OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Text(selected?.name ?: "Выбрать Android", color = Color.White)
                Spacer(Modifier.weight(1f))
                Text("⌄", color = Color.White)
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }, modifier = Modifier.heightIn(max = 440.dp)) {
                items.forEach { entry ->
                    DropdownMenuItem(
                        text = { Text(entry.name) },
                        onClick = { selectedId = entry.id; menuOpen = false },
                        leadingIcon = { Text(if (entry.image != null) "✓" else "○") },
                    )
                }
                DropdownMenuItem(text = { Text("Добавить свою систему") }, onClick = { menuOpen = false; onAdd() })
            }
        }
        if (selected != null) {
            Spacer(Modifier.height(14.dp))
            OsCard(
                selected,
                Modifier.fillMaxWidth().weight(1f),
                0f,
                dlActive[selected.id],
                onOpenDownloads, onPick, onDownload, onSite, onRun, onSetup,
            )
        } else {
            AddCard(Modifier.fillMaxWidth().weight(1f), 0f, onAdd)
        }
        Text("Выберите версию Android из списка выше", color = Color.White.copy(.45f), fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 14.dp))
    }
}

@Composable
private fun OsCard(e: OsEntry, mod: Modifier, parallax: Float, dl: DlState?, onOpenDownloads: () -> Unit, onPick: (OsEntry) -> Unit, onDownload: (OsEntry) -> Unit, onSite: (OsEntry) -> Unit, onRun: (OsEntry) -> Unit, onSetup: (OsEntry) -> Unit) {
    Box(
        mod.clip(RoundedCornerShape(32.dp))
            .background(Brush.linearGradient(listOf(Color(e.c1), Color(e.c2))))
            .pointerInput(e.id) {
                // свайп вверх по карточке -> настройки системы
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragCancel = { total = 0f },
                    onDragEnd = { if (total < -90f) onSetup(e) },
                ) { _, dy -> total += dy }
            },
    ) {
        OsArt(e.id, parallax, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Text(e.name, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
            Text(e.subtitle, color = Color.White.copy(.75f), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(14.dp))
            Text("${e.ramMb / 1024.0} ГБ RAM · ${e.cores} ядра · ${e.diskGb} ГБ", color = Color.White.copy(.8f), fontSize = 13.sp)
            Text(
                if (e.image == null) "Образ не выбран" else "Образ: " + e.image.substringAfterLast('/'),
                color = Color.White.copy(.6f), fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp),
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { if (dl != null) onOpenDownloads() else if (e.image != null) onRun(e) else if (e.downloadUrl != null) onDownload(e) else if (e.siteUrl != null) onSite(e) else onPick(e) },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                shape = RoundedCornerShape(18.dp),
            ) {
                val label = when {
                    dl != null && dl.phase == DlPhase.INSTALL -> "Установка в фоне… ${(dl.fraction * 100).toInt()}%"
                    dl != null -> "Скачивается… ${(dl.fraction * 100).toInt()}%"
                    e.image != null -> "Запустить"
                    e.downloadUrl != null -> if (e.sizeMb > 0) "Скачать (${e.sizeMb} МБ)" else "Скачать мобильную версию"
                    e.siteUrl != null -> "Скачать с сайта"
                    else -> "Выбрать образ"
                }
                Text(label, fontWeight = FontWeight.SemiBold)
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({ onSetup(e) }) { Text("Настроить", color = Color.White, fontSize = 13.sp) }
                if (e.image == null && e.siteUrl != null && e.downloadUrl != null) TextButton({ onSite(e) }) { Text("С сайта", color = Color.White, fontSize = 13.sp) }
                if (e.image == null) TextButton({ onPick(e) }) { Text("Свой файл", color = Color.White, fontSize = 13.sp) }
                else TextButton({ onPick(e) }) { Text("Сменить", color = Color.White, fontSize = 13.sp) }
            }
            Text("⌃  Свайп вверх — настройки", color = Color.White.copy(.45f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun AddCard(mod: Modifier, parallax: Float, onAdd: () -> Unit) {
    Box(mod.clip(RoundedCornerShape(32.dp)).background(Brush.linearGradient(listOf(Color(0xFF2B2F45), Color(0xFF12141F))))) {
        OsArt("custom", parallax, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Text("Добавить свою систему", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
            Text("Образ .img, .iso или .qcow2", color = Color.White.copy(.6f), modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
            Button(onClick = onAdd, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("Добавить") }
        }
    }
}

/** Рисованная картинка карточки: анимированные волны, параллакс, «парящий» логотип. */
@Composable
private fun OsArt(id: String, parallax: Float, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "art")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "phase")
    val bob by t.animateFloat(-1f, 1f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val tau = (2 * PI).toFloat()
        // большие полупрозрачные круги (медленнее логотипа — эффект глубины)
        drawCircle(Color.White.copy(.07f), w * .55f, Offset(w * .15f + parallax * .25f, h * .12f))
        drawCircle(Color.White.copy(.05f), w * .4f, Offset(w * .95f + parallax * .4f, h * .42f))
        // волны
        for (i in 0..2) {
            val base = h * (.58f + .1f * i)
            val path = Path().apply {
                moveTo(0f, h); lineTo(0f, base)
                var x = 0f
                while (x <= w) { lineTo(x, base + sin(x / w * tau * (i + 1) + phase * tau * (i + 1) + parallax * .01f) * 14f); x += 10f }
                lineTo(w, h); close()
            }
            drawPath(path, Color.White.copy(.05f + .03f * i))
        }
        // логотип
        val c = Offset(w / 2f + parallax * .6f, h * .27f + bob * 8.dp.toPx())
        drawCircle(Color.White.copy(.14f), w * .24f, c)
        logo(id, c, w * .15f)
    }
}

private fun DrawScope.logo(id: String, c: Offset, r: Float) {
    val white = Color.White
    val tau = (2 * PI).toFloat()
    when (id) {
        "aosp", "gsi_aosp" -> {
            drawArc(white, 180f, 180f, true, Offset(c.x - r, c.y - r * .9f), Size(2 * r, 2 * r))
            drawRoundRect(white, Offset(c.x - r, c.y + r * .2f), Size(2 * r, r * .85f), CornerRadius(r * .18f))
            drawCircle(Color(0xFF0B3D2E), r * .09f, Offset(c.x - r * .4f, c.y - r * .35f))
            drawCircle(Color(0xFF0B3D2E), r * .09f, Offset(c.x + r * .4f, c.y - r * .35f))
            drawLine(white, Offset(c.x - r * .55f, c.y - r * .75f), Offset(c.x - r * .8f, c.y - r * 1.15f), r * .07f, StrokeCap.Round)
            drawLine(white, Offset(c.x + r * .55f, c.y - r * .75f), Offset(c.x + r * .8f, c.y - r * 1.15f), r * .07f, StrokeCap.Round)
        }
        "lineage" -> {
            fun hex(rad: Float) = Path().apply {
                for (i in 0..5) {
                    val a = tau / 6f * i + tau / 12f
                    val x = c.x + cos(a) * rad; val y = c.y + sin(a) * rad
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                close()
            }
            drawPath(hex(r), white, style = Stroke(r * .14f, join = StrokeJoin.Round))
            drawPath(hex(r * .5f), white)
        }
        "x86" -> {
            drawRoundRect(white, Offset(c.x - r, c.y - r), Size(r * 1.4f, r * 1.4f), CornerRadius(r * .25f), style = Stroke(r * .13f))
            drawRoundRect(white.copy(.9f), Offset(c.x - r * .4f, c.y - r * .4f), Size(r * 1.4f, r * 1.4f), CornerRadius(r * .25f))
        }
        "bliss", "zenith", "gsi_treble" -> {
            for (i in 0..3) {
                val a = tau / 4f * i
                drawCircle(white.copy(.85f), r * .5f, Offset(c.x + cos(a) * r * .5f, c.y + sin(a) * r * .5f))
            }
            drawCircle(Color(0xFF2A1458), r * .2f, c)
        }
        "prime" -> {
            fun tri(k: Float) = Path().apply {
                moveTo(c.x, c.y - r * k); lineTo(c.x + r * k, c.y + r * .7f * k); lineTo(c.x - r * k, c.y + r * .7f * k); close()
            }
            drawPath(tri(1f), white, style = Stroke(r * .13f, join = StrokeJoin.Round))
            drawPath(tri(.5f), white)
        }
        else -> {
            drawCircle(white, r, c, style = Stroke(r * .12f))
            drawLine(white, Offset(c.x - r * .5f, c.y), Offset(c.x + r * .5f, c.y), r * .14f, StrokeCap.Round)
            drawLine(white, Offset(c.x, c.y - r * .5f), Offset(c.x, c.y + r * .5f), r * .14f, StrokeCap.Round)
        }
    }
}
