package com.oneemu.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile

/** Колбэк прогресса установки: (что делаем сейчас, готово, всего). */
internal typealias InstallProgress = (String, Long, Long) -> Unit

private const val SCALE = 10_000L

/**
 * Общий прогресс установки из нескольких этапов (копирование → распаковка → преобразование).
 * Каждому этапу отдаётся своя доля шкалы, снаружи видно один плавный процент от 0 до 100.
 */
private class Staged(private val out: InstallProgress) {
    fun range(from: Double, to: Double): InstallProgress = { stage, d, t ->
        val f = if (t > 0) (d.toDouble() / t).coerceIn(0.0, 1.0) else 0.0
        out(stage, ((from + (to - from) * f) * SCALE).toLong(), SCALE)
    }
}

private fun displayName(ctx: Context, uri: Uri): String {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) c.getString(i)?.let { return it }
        }
    }
    return "image.img"
}

private fun sizeOf(ctx: Context, uri: Uri): Long {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.SIZE)
            if (i >= 0 && !c.isNull(i)) return c.getLong(i)
        }
    }
    return -1L
}

private fun extOf(name: String) = name.substringAfterLast('.', "").lowercase()

/** Копирует выбранный файл во внутреннюю память с прогрессом. */
private fun copyUri(ctx: Context, uri: Uri, dst: File, stage: String, cancel: AtomicBoolean, p: InstallProgress) {
    val total = sizeOf(ctx, uri).coerceAtLeast(1L)
    p(stage, 0, total)
    ctx.contentResolver.openInputStream(uri)!!.use { i ->
        dst.outputStream().use { o -> copyCounting(i, o, cancel) { n -> p(stage, minOf(n, total), total) } }
    }
}

/** Копирует образ в память приложения. ZIP автоматически распаковывается. Возвращает путь к образу. */
internal fun importImage(ctx: Context, uri: Uri, id: String, cancel: AtomicBoolean, report: InstallProgress): String {
    val st = Staged(report)
    val rawName = displayName(ctx, uri)
    val lowerName = rawName.lowercase()
    if ("x86_64" in lowerName || "amd64" in lowerName || "x86-64" in lowerName || "pc" in lowerName) {
        throw InstallError("Выбран образ для ПК (x86_64). OneEmu эмулирует мобильный процессор ARM64 — выберите образ с пометкой arm64 / aarch64.")
    }
    val ext = extOf(rawName).ifEmpty { "img" }
    val dir = File(ctx.filesDir, "images").apply { mkdirs() }
    dir.listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }

    if (ext == "xz") {
        val tmp = File(ctx.cacheDir, "import.xz")
        val f = File(dir, "$id.img")
        try {
            copyUri(ctx, uri, tmp, "Копирование архива…", cancel, st.range(0.0, 0.25))
            val stage = "Распаковка .xz…"
            val total = tmp.length().coerceAtLeast(1L)
            val sub = st.range(0.25, 1.0)
            val counter = object : java.io.FilterInputStream(tmp.inputStream().buffered(1 shl 20)) {
                var consumed = 0L
                override fun read(): Int = super.read().also { if (it >= 0) consumed++ }
                override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also { if (it > 0) consumed += it }
            }
            org.tukaani.xz.XZInputStream(counter).use { i ->
                f.outputStream().use { o -> copyCounting(i, o, cancel) { sub(stage, minOf(counter.consumed, total), total) } }
            }
            return f.absolutePath
        } catch (t: Throwable) {
            f.delete(); throw t
        } finally {
            tmp.delete()
        }
    }

    if (ext != "zip") {
        val f = File(dir, "$id.$ext")
        try { copyUri(ctx, uri, f, "Копирование образа…", cancel, st.range(0.0, 1.0)) } catch (t: Throwable) { f.delete(); throw t }
        return f.absolutePath
    }

    val tmp = File(ctx.cacheDir, "import.zip")
    try {
        copyUri(ctx, uri, tmp, "Копирование архива…", cancel, st.range(0.0, 0.25))
        if (ImageInstaller.isBundle(tmp)) {
            return ImageInstaller.unpack(ctx, id, tmp, cancel, st.range(0.25, 1.0))
        }
        ZipFile(tmp).use { z ->
            val all = z.entries().asSequence().filter { !it.isDirectory }.toList()
            val skip = setOf("boot.img", "recovery.img", "vendor_boot.img", "dtbo.img", "vbmeta.img", "init_boot.img", "vbmeta_system.img", "super_empty.img")
            fun rank(n: String) = when (extOf(n)) { "iso" -> 3; "qcow2" -> 2; "img" -> 1; else -> 0 }
            val best = all
                .filter { rank(it.name) > 0 && it.name.substringAfterLast('/').lowercase() !in skip }
                .maxWithOrNull(compareBy({ rank(it.name) }, { it.size }))
            if (best == null) {
                val ota = all.any { it.name.endsWith("payload.bin") || it.name.contains("system.new.dat") }
                val list = all.take(8).joinToString("\n") { "• " + it.name.substringAfterLast('/') }
                throw InstallError(
                    (if (ota) "Это OTA-прошивка для конкретного телефона (payload.bin / system.new.dat). Она не загрузится в виртуальной машине.\n\n" else "В архиве нет образа системы (.iso / .img / .qcow2).\n\n") +
                        "Содержимое:\n$list\n\nНужен мобильный образ ARM64 для виртуальной машины: файл UTM-VM-lineage-…-virtio_arm64only.zip (внутри диски vda.qcow2, vdb.qcow2).",
                )
            }
            val stage = "Распаковка ${best.name.substringAfterLast('/')}…"
            val f = File(dir, "$id.${extOf(best.name)}")
            val total = best.size.coerceAtLeast(1L)
            val sub = st.range(0.25, 1.0)
            try {
                z.getInputStream(best).use { i ->
                    f.outputStream().use { o -> copyCounting(i, o, cancel) { n -> sub(stage, minOf(n, total), total) } }
                }
            } catch (t: Throwable) { f.delete(); throw t }
            return f.absolutePath
        }
    } finally {
        tmp.delete()
    }
}

/** Образ-надстройка (GSI): zip / .img.xz / sparse или raw .img → один raw-диск vdc.img. */
internal fun importGsi(ctx: Context, uri: Uri, id: String, cancel: AtomicBoolean, report: InstallProgress): String {
    val st = Staged(report)
    val name = displayName(ctx, uri).lowercase()
    val dir = File(ctx.filesDir, "images/$id").apply { deleteRecursively(); mkdirs() }
    val tmp = File(ctx.cacheDir, "gsi.in")
    val raw = File(ctx.cacheDir, "gsi.raw")
    val out = File(dir, "vdc.img")
    try {
        copyUri(ctx, uri, tmp, "Копирование образа…", cancel, st.range(0.0, 0.15))
        val ex = st.range(0.15, 0.60)
        when {
            name.endsWith(".zip") -> ZipFile(tmp).use { z ->
                val e = z.entries().asSequence()
                    .filter { !it.isDirectory && it.name.lowercase().endsWith(".img") && "vbmeta" !in it.name.lowercase() }
                    .maxByOrNull { it.size }
                    ?: throw InstallError("В архиве нет system.img. Нужен образ GSI для ARM64.")
                val stage = "Распаковка ${e.name.substringAfterLast('/')}…"
                val total = e.size.coerceAtLeast(1L)
                z.getInputStream(e).use { i ->
                    raw.outputStream().use { o -> copyCounting(i, o, cancel) { n -> ex(stage, minOf(n, total), total) } }
                }
            }
            name.endsWith(".xz") -> {
                // прогресс считаем по прочитанным сжатым байтам — размер распакованного заранее неизвестен
                val stage = "Распаковка .xz (может занять несколько минут)…"
                val total = tmp.length().coerceAtLeast(1L)
                val counter = object : java.io.FilterInputStream(tmp.inputStream().buffered(1 shl 20)) {
                    var consumed = 0L
                    override fun read(): Int = super.read().also { if (it >= 0) consumed++ }
                    override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also { if (it > 0) consumed += it }
                }
                org.tukaani.xz.XZInputStream(counter).use { i ->
                    raw.outputStream().use { o -> copyCounting(i, o, cancel) { ex(stage, minOf(counter.consumed, total), total) } }
                }
            }
            else -> tmp.copyTo(raw, overwrite = true)
        }
        tmp.delete()
        val last = st.range(0.60, 1.0)
        if (SparseImage.isSparse(raw)) {
            SparseImage.toRaw(raw, out, cancel) { d, t -> last("Преобразование образа…", d, t) }
        } else {
            val total = raw.length().coerceAtLeast(1L)
            raw.inputStream().use { i ->
                out.outputStream().use { o -> copyCounting(i, o, cancel) { n -> last("Сохранение образа…", minOf(n, total), total) } }
            }
        }
        return out.absolutePath
    } catch (t: Throwable) {
        dir.deleteRecursively()
        throw t
    } finally {
        tmp.delete(); raw.delete()
    }
}
