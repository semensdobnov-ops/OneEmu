package com.oneemu.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

enum class DlStatus { ACTIVE, DONE, FAILED }

/** Этап работы: скачивание файла или установка (копирование / распаковка / преобразование). */
enum class DlPhase { DOWNLOAD, INSTALL }

data class DlState(
    val id: String,
    val name: String,
    val c1: Long,
    val c2: Long,
    val done: Long = 0,
    val total: Long = 0,
    val speed: Double = 0.0,
    val status: DlStatus = DlStatus.ACTIVE,
    val error: String? = null,
    val phase: DlPhase = DlPhase.DOWNLOAD,
    /** Что делается прямо сейчас на этапе установки, например «Распаковка vda.qcow2…». */
    val stage: String = "",
) {
    val fraction: Float get() = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
    /** Оставшееся время в секундах или null, если скорость ещё не известна. */
    val etaSec: Long? get() {
        if (status != DlStatus.ACTIVE || total <= done) return null
        // при скачивании скорость в байтах/с, при установке — в условных единицах прогресса/с
        val min = if (phase == DlPhase.DOWNLOAD) 1024.0 else 0.0
        return if (speed > min) ((total - done) / speed).toLong() else null
    }
}

/** Общее состояние всех загрузок. Его показывает вкладка «Загрузки», обновляет DownloadService. */
object Downloads {
    private val _state = MutableStateFlow<List<DlState>>(emptyList())
    val state: StateFlow<List<DlState>> = _state.asStateFlow()
    private val flags = ConcurrentHashMap<String, AtomicBoolean>()

    fun flag(id: String): AtomicBoolean = flags.getOrPut(id) { AtomicBoolean(false) }

    fun enqueue(ctx: Context, e: OsEntry) {
        val url = e.downloadUrl ?: return
        if (_state.value.any { it.id == e.id && it.status == DlStatus.ACTIVE }) return
        flags[e.id] = AtomicBoolean(false)
        _state.update { list -> listOf(DlState(e.id, e.name, e.c1, e.c2)) + list.filter { it.id != e.id } }
        val i = Intent(ctx, DownloadService::class.java)
            .putExtra("id", e.id).putExtra("name", e.name).putExtra("url", url).putExtra("mb", e.sizeMb).putExtra("bundle", e.bundle)
        ContextCompat.startForegroundService(ctx, i)
    }

    /** Установка из выбранного пользователем файла (zip / img / xz) — тоже в фоне, с уведомлением. */
    fun enqueueImport(ctx: Context, e: OsEntry, uri: Uri) {
        if (_state.value.any { it.id == e.id && it.status == DlStatus.ACTIVE }) return
        flags[e.id] = AtomicBoolean(false)
        _state.update { list ->
            listOf(DlState(e.id, e.name, e.c1, e.c2, phase = DlPhase.INSTALL, stage = "Подготовка…")) + list.filter { it.id != e.id }
        }
        val i = Intent(ctx, DownloadService::class.java).setAction("import").setData(uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .putExtra("id", e.id).putExtra("name", e.name).putExtra("gsi", e.baseId != null)
        ContextCompat.startForegroundService(ctx, i)
    }

    fun update(id: String, f: (DlState) -> DlState) {
        _state.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    fun remove(id: String) { _state.update { list -> list.filter { it.id != id } } }

    fun cancel(id: String) { flags[id]?.set(true) }

    fun cancelAll() { flags.values.forEach { it.set(true) } }

    fun active(): List<DlState> = _state.value.filter { it.status == DlStatus.ACTIVE }
}
