package com.oneemu.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.core.content.ContextCompat
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipFile

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var ok by remember { mutableStateOf(TermsStore.accepted(this@MainActivity)) }
                if (ok) App() else TermsScreen(
                    onAccept = { TermsStore.accept(this@MainActivity); ok = true },
                    onDecline = { finish() },
                )
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(Repo.load(ctx)) }
    var running by remember { mutableStateOf<OsEntry?>(null) }
    var pendingId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var setupFor by remember { mutableStateOf<OsEntry?>(null) }
    var addDialog by remember { mutableStateOf(false) }
    var siteFor by remember { mutableStateOf<OsEntry?>(null) }
    var versionFor by remember { mutableStateOf<OsEntry?>(null) }
    var versions by remember { mutableStateOf<List<Downloader.Ver>?>(null) }
    var versionErr by remember { mutableStateOf<String?>(null) }
    val uri = LocalUriHandler.current
    var shuttingDown by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val dl by Downloads.state.collectAsState()
    val activeCount = dl.count { it.status == DlStatus.ACTIVE }
    val pct = dl.filter { it.status == DlStatus.ACTIVE }.associate { it.id to (it.fraction * 100).toInt() }
    // когда загрузка закончилась (в том числе в фоне) — подтягиваем путь к образу
    LaunchedEffect(dl.count { it.status == DlStatus.DONE }) { items = Repo.load(ctx) }
    BackHandler(enabled = running == null && tab == 1) { tab = 0 }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun startDownload(e: OsEntry) {
        askNotifPermission()
        Downloads.enqueue(ctx, e)
        Toast.makeText(ctx, "Добавлено во вкладку «Загрузки»", Toast.LENGTH_SHORT).show()
    }

    LaunchedEffect(versionFor) {
        val e = versionFor ?: return@LaunchedEffect
        versions = null; versionErr = null
        runCatching { withContext(Dispatchers.IO) { Downloader.listReleases(e.downloadUrl!!) } }
            .onSuccess { versions = it; if (it.isEmpty()) versionErr = "Версии не найдены. Проверьте интернет или нажмите «С сайта»." }
            .onFailure { versionErr = "Не удалось получить список версий: ${it.message}" }
    }

    fun update(list: List<OsEntry>) { items = list; Repo.save(ctx, list) }

    // Установка идёт в фоновом сервисе: можно свернуть приложение, а проценты и оставшееся время видны в уведомлении
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = pendingId
        val entry = items.firstOrNull { it.id == id }
        if (uri != null && entry != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            askNotifPermission()
            Downloads.enqueueImport(ctx, entry, uri)
            Toast.makeText(ctx, "Установка идёт в фоне — прогресс во вкладке «Загрузки» и в уведомлении", Toast.LENGTH_LONG).show()
            tab = 1
        }
    }
    fun pick(id: String) { pendingId = id; picker.launch(arrayOf("*/*")) }

    Box(Modifier.fillMaxSize()) {
        Crossfade(targetState = running, animationSpec = tween(700), label = "screen") { r ->
            if (r == null) {
            Column(Modifier.fillMaxSize().background(Color(0xFF0B0D14))) {
                Box(Modifier.weight(1f)) {
                    Crossfade(targetState = tab, animationSpec = tween(350), label = "tab") { t ->
                        if (t == 0) {
                            HomeScreen(
                                items, onPick = { pick(it.id) }, onSite = { siteFor = it },
                                onDownload = { if (it.downloadUrl?.startsWith("github:") == true) versionFor = it else startDownload(it) },
                                onRun = { running = it }, onSetup = { setupFor = it }, onAdd = { addDialog = true },
                                dlPercent = pct, onOpenDownloads = { tab = 1 },
                            )
                        } else {
                            DownloadsScreen(
                                dl,
                                onCancel = { Downloads.cancel(it) },
                                onRetry = { id -> items.firstOrNull { it.id == id }?.let { if (it.downloadUrl != null) startDownload(it) else pick(it.id) } },
                                onDismiss = { Downloads.remove(it) },
                                onHome = { tab = 0 },
                            )
                        }
                    }
                }
                BottomTabs(tab, activeCount) { tab = it }
            }
            } else {
                RunScreen(r, onExit = {
                    if (!shuttingDown) {
                        shuttingDown = true
                        scope.launch {
                            delay(1600)
                            withContext(Dispatchers.IO) { QemuRunner.stop() }
                            running = null
                            delay(700)
                            shuttingDown = false
                        }
                    }
                })
            }
        }
        ShutdownOverlay(shuttingDown)
    }

    versionFor?.let { e ->
        AlertDialog(
            onDismissRequest = { versionFor = null },
            title = { Text("Выберите версию") },
            text = {
                val err = versionErr
                val list = versions
                when {
                    err != null -> Text(err)
                    list == null -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text("Ищу версии…")
                    }
                    else -> Column(Modifier.verticalScroll(rememberScrollState())) {
                        list.forEachIndexed { i, v ->
                            TextButton(
                                onClick = { startDownload(e.copy(downloadUrl = v.url, sizeMb = v.sizeMb)); versionFor = null },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text((if (i == 0) "★ " else "") + v.label + (if (v.sizeMb > 0) " · ${v.sizeMb} МБ" else "")) }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ versionFor = null }) { Text("Отмена") } },
        )
    }
    siteFor?.takeIf { message == null }?.let { e ->
        AlertDialog(
            onDismissRequest = { siteFor = null },
            title = { Text("Где скачать: ${e.name}") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(e.howTo) } },
            confirmButton = { TextButton({ uri.openUri(e.siteUrl!!); siteFor = null }) { Text("Открыть сайт") } },
            dismissButton = { TextButton({ siteFor = null; pick(e.id) }) { Text("У меня уже есть файл") } },
        )
    }
    message?.let {
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("Образ не подошёл") },
            text = { Text(it) },
            confirmButton = { TextButton({ message = null }) { Text("Понятно") } },
        )
    }
    setupFor?.let { e ->
        SetupSheet(e, onDismiss = { setupFor = null }, onSave = { n -> update(items.map { if (it.id == n.id) n else it }); setupFor = null })
    }
    if (addDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addDialog = false },
            title = { Text("Своя система") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val id = UUID.randomUUID().toString()
                    val n = if (name.isBlank()) "Моя система" else name.trim()
                    update(items + OsEntry(id, n, "Свой образ (.iso / .img / .zip)", 0xFFD6336C, 0xFF45102B, custom = true))
                    addDialog = false
                    pick(id)
                }) { Text("Выбрать образ") }
            },
            dismissButton = { TextButton({ addDialog = false }) { Text("Отмена") } },
        )
    }
}

/** Настройки системы выезжают снизу (открываются свайпом вверх по карточке). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupSheet(e: OsEntry, onDismiss: () -> Unit, onSave: (OsEntry) -> Unit) {
    var ram by remember { mutableFloatStateOf(e.ramMb / 512f) }
    var cores by remember { mutableFloatStateOf(e.cores.toFloat()) }
    var disk by remember { mutableFloatStateOf(e.diskGb.toFloat()) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp).navigationBarsPadding()) {
            Text("Настройки: ${e.name}", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(e.image?.substringAfterLast('/')?.let { "Образ: $it" } ?: "Образ не выбран", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            Text("RAM: ${(ram * 512).toInt()} МБ"); Slider(ram, { ram = it }, valueRange = 2f..16f, steps = 13)
            Text("Ядра CPU: ${cores.toInt()}"); Slider(cores, { cores = it }, valueRange = 1f..8f, steps = 6)
            Text("Диск (для ISO): ${disk.toInt()} ГБ"); Slider(disk, { disk = it }, valueRange = 8f..64f, steps = 6)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { onSave(e.copy(ramMb = (ram * 512).toInt(), cores = cores.toInt(), diskGb = disk.toInt())) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Сохранить") }
        }
    }
}

/** Плавное затемнение с пульсирующим кольцом при выключении системы. */
@Composable
fun ShutdownOverlay(visible: Boolean) {
    val dim by animateFloatAsState(if (visible) 1f else 0f, tween(600), label = "dim")
    if (dim <= 0.01f) return
    val t = rememberInfiniteTransition(label = "pulse")
    val k by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "k")
    Box(Modifier.fillMaxSize().alpha(dim).background(Color(0xFF05060A).copy(alpha = .94f)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(120.dp)) {
                val c = Offset(size.width / 2, size.height / 2)
                val base = size.minDimension * .22f
                drawCircle(Color.White.copy(.9f), base * (1f - .15f * k), c)
                drawCircle(Color.White.copy(.5f * (1f - k)), base + size.minDimension * .3f * k, c, style = Stroke(3.dp.toPx()))
            }
            Spacer(Modifier.height(20.dp))
            Text("Выключение…", color = Color.White, fontSize = 18.sp)
        }
    }
}
