package com.oneemu.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipFile

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

private class ImportResult(val path: String?, val error: String?)

private fun displayName(ctx: Context, uri: Uri): String {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) c.getString(i)?.let { return it }
        }
    }
    return "image.img"
}

private fun extOf(name: String) = name.substringAfterLast('.', "").lowercase()

/** Копирует образ в память приложения. ZIP автоматически распаковывается. */
private fun importImage(ctx: Context, uri: Uri, id: String, stage: (String) -> Unit): ImportResult {
    val ext = extOf(displayName(ctx, uri)).ifEmpty { "img" }
    val dir = File(ctx.filesDir, "images").apply { mkdirs() }
    dir.listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }

    if (ext != "zip") {
        stage("Копирование образа…")
        val f = File(dir, "$id.$ext")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
        return ImportResult(f.absolutePath, null)
    }

    stage("Копирование архива…")
    val tmp = File(ctx.cacheDir, "import.zip")
    ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
    try {
        ZipFile(tmp).use { z ->
            val all = z.entries().asSequence().filter { !it.isDirectory }.toList()
            val skip = setOf("boot.img", "recovery.img", "vendor_boot.img", "dtbo.img", "vbmeta.img", "init_boot.img", "vbmeta_system.img", "super_empty.img")
            fun rank(n: String) = when (extOf(n)) { "iso" -> 3; "qcow2" -> 2; "img" -> 1; else -> 0 }
            val best = all
                .filter { rank(it.name) > 0 && it.name.substringAfterLast('/').lowercase() !in skip }
                .maxWithOrNull(compareBy({ rank(it.name) }, { it.size }))
            if (best == null) {
                val ota = all.any { it.name.endsWith("payload.bin") || it.name.contains("system.new.dat") }
                val list = all.take(8).joinToString("\n") { "• " + it.name.substringAfterLast('/') }
                val msg = (if (ota) "Это OTA-прошивка для конкретного телефона (payload.bin / system.new.dat). Она не загрузится в эмуляторе x86_64.\n\n" else "В архиве нет образа системы (.iso / .img / .qcow2).\n\n") +
                    "Содержимое:\n$list\n\nНужен образ x86_64: Android-x86, Bliss OS, PrimeOS или сборка LineageOS для x86 (внутри должен быть .iso или .img)."
                return ImportResult(null, msg)
            }
            stage("Распаковка ${best.name.substringAfterLast('/')}…")
            val f = File(dir, "$id.${extOf(best.name)}")
            z.getInputStream(best).use { i -> f.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
            return ImportResult(f.absolutePath, null)
        }
    } finally {
        tmp.delete()
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(Repo.load(ctx)) }
    var running by remember { mutableStateOf<OsEntry?>(null) }
    var pendingId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var setupFor by remember { mutableStateOf<OsEntry?>(null) }
    var addDialog by remember { mutableStateOf(false) }

    fun update(list: List<OsEntry>) { items = list; Repo.save(ctx, list) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = pendingId
        if (uri != null && id != null) scope.launch {
            busy = "Импорт…"
            val r = runCatching { withContext(Dispatchers.IO) { importImage(ctx, uri, id) { busy = it } } }
                .getOrElse { ImportResult(null, "Ошибка импорта: ${it.message}\n(возможно, не хватает места)") }
            r.path?.let { p -> update(items.map { if (it.id == id) it.copy(image = p) else it }) }
            message = r.error
            busy = null
        }
    }
    fun pick(id: String) { pendingId = id; picker.launch(arrayOf("*/*")) }

    Box(Modifier.fillMaxSize()) {
        val r = running
        if (r == null) {
            HomeScreen(items, onPick = { pick(it.id) }, onDownload = { e ->
                scope.launch {
                    busy = "Скачивание ${e.name}…"
                    val r = runCatching {
                        withContext(Dispatchers.IO) { Downloader.download(ctx, e.id, e.downloadUrl!!) { d, t -> busy = "Скачивание ${e.name}: $d МБ" + (if (t > 0) " из $t" else "") } }
                    }
                    r.getOrNull()?.let { f -> update(items.map { if (it.id == e.id) it.copy(image = f.absolutePath) else it }) }
                    r.exceptionOrNull()?.let { message = "Не удалось скачать: ${it.message}\nПроверьте интернет и свободное место (нужно около ${e.sizeMb * 2} МБ)." }
                    busy = null
                }
            }, onRun = { running = it }, onSetup = { setupFor = it }, onAdd = { addDialog = true })
        } else {
            RunScreen(r, onExit = { QemuRunner.stop(); running = null })
        }
        busy?.let {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Surface(shape = MaterialTheme.shapes.large, tonalElevation = 8.dp) {
                    Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(16.dp)); Text(it)
                    }
                }
            }
        }
    }

    message?.let {
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("Образ не подошёл") },
            text = { Text(it) },
            confirmButton = { TextButton({ message = null }) { Text("Понятно") } },
        )
    }
    setupFor?.let { e ->
        SetupSheet(e, onDismiss = { setupFor = null }, onSave = { n -> update(items.map { if (it.id == n.id) n else it }); setupFor = null })
    }
    if (addDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addDialog = false },
            title = { Text("Своя система") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val id = UUID.randomUUID().toString()
                    val n = if (name.isBlank()) "Моя система" else name.trim()
                    update(items + OsEntry(id, n, "Свой образ (.iso / .img / .zip)", 0xFFD6336C, 0xFF45102B, custom = true))
                    addDialog = false
                    pick(id)
                }) { Text("Выбрать образ") }
            },
            dismissButton = { TextButton({ addDialog = false }) { Text("Отмена") } },
        )
    }
}

/** Настройки системы выезжают снизу (открываются свайпом вверх по карточке). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupSheet(e: OsEntry, onDismiss: () -> Unit, onSave: (OsEntry) -> Unit) {
    var ram by remember { mutableFloatStateOf(e.ramMb / 512f) }
    var cores by remember { mutableFloatStateOf(e.cores.toFloat()) }
    var disk by remember { mutableFloatStateOf(e.diskGb.toFloat()) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp).navigationBarsPadding()) {
            Text("Настройки: ${e.name}", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(e.image?.substringAfterLast('/')?.let { "Образ: $it" } ?: "Образ не выбран", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            Text("RAM: ${(ram * 512).toInt()} МБ"); Slider(ram, { ram = it }, valueRange = 2f..16f, steps = 13)
            Text("Ядра CPU: ${cores.toInt()}"); Slider(cores, { cores = it }, valueRange = 1f..8f, steps = 6)
            Text("Диск (для ISO): ${disk.toInt()} ГБ"); Slider(disk, { disk = it }, valueRange = 8f..64f, steps = 6)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { onSave(e.copy(ramMb = (ram * 512).toInt(), cores = cores.toInt(), diskGb = disk.toInt())) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Сохранить") }
        }
    }
}
