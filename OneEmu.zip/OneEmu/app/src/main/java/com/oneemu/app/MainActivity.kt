package com.oneemu.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.core.content.ContextCompat
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import rikka.shizuku.Shizuku
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlinx.coroutines.delay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipFile

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var ok by remember { mutableStateOf(TermsStore.accepted(this@MainActivity)) }
                if (ok) App() else TermsScreen(
                    onAccept = { TermsStore.accept(this@MainActivity); ok = true },
                    onDecline = { finish() },
                )
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(Repo.load(ctx)) }
    var running by remember { mutableStateOf<OsEntry?>(items.firstOrNull { it.id == QemuRunner.runningId && QemuRunner.alive() }) }
    var pendingId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var setupFor by remember { mutableStateOf<OsEntry?>(null) }
    var activationDialog by remember { mutableStateOf(false) }
    var shizukuGranted by remember { mutableStateOf(false) }
    var shizukuRunning by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var siteFor by remember { mutableStateOf<OsEntry?>(null) }
    var versionFor by remember { mutableStateOf<OsEntry?>(null) }
    var versions by remember { mutableStateOf<List<Downloader.Ver>?>(null) }
    var versionErr by remember { mutableStateOf<String?>(null) }
    val uri = LocalUriHandler.current
    var shuttingDown by remember { mutableStateOf(false) }
    var shutdownText by remember { mutableStateOf("Выключение…") }
    var tab by remember { mutableIntStateOf(0) }
    val dl by Downloads.state.collectAsState()
    val activeCount = dl.count { it.status == DlStatus.ACTIVE }
    val activeMap = dl.filter { it.status == DlStatus.ACTIVE }.associateBy { it.id }
    // когда загрузка закончилась (в том числе в фоне) — подтягиваем путь к образу
    LaunchedEffect(dl.count { it.status == DlStatus.DONE }) { items = Repo.load(ctx) }
    BackHandler(enabled = running == null && tab == 1) { tab = 0 }
    var notifDialog by remember { mutableStateOf(false) }
    var installRequested by remember { mutableStateOf(false) }
    var batteryDialog by remember { mutableStateOf(false) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok && installRequested) notifDialog = true
    }
    fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else if (installRequested && !androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
            notifDialog = true
        }
    }
    fun refreshShizuku() {
        shizukuRunning = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        shizukuGranted = shizukuRunning && runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
    }
    LaunchedEffect(Unit) { askNotifPermission(); refreshShizuku() }
    fun openWirelessDebugging() {
        val intent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        runCatching { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { Toast.makeText(ctx, "Откройте Настройки → Для разработчиков → Беспроводная отладка", Toast.LENGTH_LONG).show() }
    }
    fun openShizuku() {
        val launch = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (launch != null) ctx.startActivity(launch)
        else runCatching { uri.openUri("https://shizuku.rikka.app/download/") }
    }
    fun startShizukuPermissionRequest() {
        refreshShizuku()
        if (!shizukuRunning) {
            Toast.makeText(ctx, "Сначала запустите Shizuku через беспроводную отладку", Toast.LENGTH_LONG).show()
        } else if (!shizukuGranted) {
            runCatching { Shizuku.requestPermission(2401) }
                .onFailure { Toast.makeText(ctx, "Не удалось запросить доступ Shizuku: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    fun startDownload(e: OsEntry) {
        installRequested = true
        askNotifPermission()
        Downloads.enqueue(ctx, e)
        if (Battery.needsHint(ctx)) batteryDialog = true
        Toast.makeText(ctx, "Добавлено во вкладку «Загрузки»", Toast.LENGTH_SHORT).show()
    }

    LaunchedEffect(versionFor) {
        val e = versionFor ?: return@LaunchedEffect
        versions = null; versionErr = null
        runCatching { withContext(Dispatchers.IO) { Downloader.listReleases(e.downloadUrl!!) } }
            .onSuccess { versions = it; if (it.isEmpty()) versionErr = "Версии не найдены. Проверьте интернет или нажмите «С сайта»." }
            .onFailure { versionErr = "Не удалось получить список версий: ${it.message}" }
    }

    fun update(list: List<OsEntry>) { items = list; Repo.save(ctx, list) }

    // Установка идёт в фоновом сервисе: можно свернуть приложение, а проценты и оставшееся время видны в уведомлении
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = pendingId
        val entry = items.firstOrNull { it.id == id }
        if (uri != null && entry != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            installRequested = true
            askNotifPermission()
            Downloads.enqueueImport(ctx, entry, uri)
            if (Battery.needsHint(ctx)) batteryDialog = true
            Toast.makeText(ctx, "Система устанавливается в фоне. Можно свернуть приложение — придет уведомление.", Toast.LENGTH_LONG).show()
        }
    }
    fun pick(id: String) { pendingId = id; picker.launch(arrayOf("*/*")) }

    Box(Modifier.fillMaxSize()) {
        Crossfade(targetState = running, animationSpec = tween(700), label = "screen") { r ->
            if (r == null) {
            Column(Modifier.fillMaxSize().background(Color(0xFF0B0D14))) {
                Box(Modifier.weight(1f)) {
                    Crossfade(targetState = tab, animationSpec = tween(350), label = "tab") { t ->
                        if (t == 0) {
                            HomeScreen(
                                items, onPick = { pick(it.id) }, onSite = { siteFor = it },
                                onDownload = { if (it.downloadUrl?.startsWith("github:") == true) versionFor = it else startDownload(it) },
                                onRun = { entry -> if (running == null && setupFor == null) running = entry },
                                onSetup = { entry -> if (running == null && setupFor == null) setupFor = entry },
                                onAdd = { addDialog = true },
                                dlActive = activeMap, onOpenDownloads = { tab = 1 },
                                adbActive = shizukuGranted,
                                onActivation = { refreshShizuku(); activationDialog = true },
                            )
                        } else {
                            DownloadsScreen(
                                dl,
                                onCancel = { Downloads.cancel(it) },
                                onRetry = { id -> items.firstOrNull { it.id == id }?.let { if (it.downloadUrl != null) startDownload(it) else pick(it.id) } },
                                onDismiss = { Downloads.remove(it) },
                                onHome = { tab = 0 },
                            )
                        }
                    }
                }
                BottomTabs(tab, activeCount) { tab = it }
            }
            } else {
                RunScreen(r, onExit = { save ->
                    if (!shuttingDown) {
                        shuttingDown = true
                        shutdownText = if (save) "Сохранение состояния…" else "Выключение…"
                        scope.launch {
                            delay(600)
                            withContext(Dispatchers.IO) {
                                if (save) QemuRunner.saveAndStop(ctx, r)
                                else { QemuRunner.stop(); QemuRunner.discardState(ctx, r.id) }
                            }
                            running = null
                            delay(700)
                            shuttingDown = false
                        }
                    }
                })
            }
        }
        ShutdownOverlay(shuttingDown, shutdownText)
    }

    if (batteryDialog) {
        AlertDialog(
            onDismissRequest = { batteryDialog = false },
            title = { Text("Выключите ограничение батареи") },
            text = {
                Column {
                    Text("Чтобы система устанавливалась в фоне, когда приложение свёрнуто или экран погас, выключите ограничение батареи для OneEmu: выберите «Без ограничений» (или «Разрешить» в системном окне). Иначе Android может остановить установку.")
                    TextButton({
                        Battery.muteHint(ctx)
                        batteryDialog = false
                    }) { Text("Больше не показывать") }
                }
            },
            confirmButton = {
                TextButton({
                    batteryDialog = false
                    Battery.open(ctx)
                }) { Text("Выключить") }
            },
            dismissButton = { TextButton({ batteryDialog = false }) { Text("Позже") } },
        )
    }

    if (notifDialog) {
        AlertDialog(
            onDismissRequest = { notifDialog = false },
            title = { Text("Уведомления выключены") },
            text = { Text("Установка идёт в фоне, но без уведомлений вы не увидите, что система устанавливается, и не узнаете, когда она готова. Включите уведомления для OneEmu.") },
            confirmButton = {
                TextButton({
                    notifDialog = false
                    runCatching {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }) { Text("Открыть настройки") }
            },
            dismissButton = { TextButton({ notifDialog = false }) { Text("Позже") } },
        )
    }

    if (activationDialog) {
        AlertDialog(
            onDismissRequest = { activationDialog = false },
            title = { Text("ADB Wi-Fi и Shizuku — инструкция", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (shizukuGranted) Color(0xFF143524) else Color(0xFF1D263B)
                        ),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text(
                                text = when {
                                    shizukuGranted -> "● Статус: ADB Wi-Fi / Shizuku подключён"
                                    shizukuRunning -> "● Статус: Shizuku запущен, нужен доступ"
                                    else -> "● Статус: не подключено"
                                },
                                fontWeight = FontWeight.SemiBold,
                                color = if (shizukuGranted) Color(0xFF86EFAC) else Color(0xFF93C5FD),
                            )
                            Text(
                                text = "Служба Shizuku: ${if (shizukuRunning) "активна" else "не запущена"} · Доступ OneEmu: ${if (shizukuGranted) "выдан" else "нет"}",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f),
                            )
                        }
                    }

                    Text("Пошаговая инструкция (без ПК):", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("1. Подключите телефон к любой сети Wi-Fi.", fontSize = 13.sp)
                    Text("2. Установите и откройте приложение Shizuku (кнопка ниже).", fontSize = 13.sp)
                    Text("3. Откройте Настройки → О телефоне → Сведения о ПО и нажмите 7 раз на «Номер сборки».", fontSize = 13.sp)
                    Text("4. Зайдите в Параметры разработчика → включите «Отладка по USB» и «Беспроводная отладка».", fontSize = 13.sp)
                    Text("5. Нажмите на сам пункт «Беспроводная отладка» → «Подключить устройство с помощью кода сопряжения» и введите 6-значный код в уведомлении Shizuku.", fontSize = 13.sp)
                    Text("6. Нажмите «Запустить (Start)» в Shizuku, вернитесь сюда и нажмите «Запросить доступ / проверить».", fontSize = 13.sp)
                    Text(
                        "Примечание: после перезагрузки смартфона службу Shizuku нужно запустить повторно.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(onClick = { openShizuku() }) { Text("1. Открыть / скачать Shizuku") }
                    TextButton(onClick = { openWirelessDebugging() }) { Text("2. Параметры разработчика") }
                    TextButton(onClick = { startShizukuPermissionRequest(); refreshShizuku() }) { Text("3. Запросить доступ / проверить") }
                }
            },
            dismissButton = { TextButton(onClick = { activationDialog = false }) { Text("Закрыть") } },
        )
    }
    versionFor?.let { e ->
        AlertDialog(
            onDismissRequest = { versionFor = null },
            title = { Text("Выберите версию") },
            text = {
                val err = versionErr
                val list = versions
                when {
                    err != null -> Text(err)
                    list == null -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text("Ищу версии…")
                    }
                    else -> Column(Modifier.verticalScroll(rememberScrollState())) {
                        list.forEachIndexed { i, v ->
                            TextButton(
                                onClick = { startDownload(e.copy(downloadUrl = v.url, sizeMb = v.sizeMb)); versionFor = null },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text((if (i == 0) "★ " else "") + v.label + (if (v.sizeMb > 0) " · ${v.sizeMb} МБ" else "")) }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ versionFor = null }) { Text("Отмена") } },
        )
    }
    siteFor?.takeIf { message == null }?.let { e ->
        AlertDialog(
            onDismissRequest = { siteFor = null },
            title = { Text("Где скачать: ${e.name}") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(e.howTo) } },
            confirmButton = { TextButton({ uri.openUri(e.siteUrl!!); siteFor = null }) { Text("Открыть сайт") } },
            dismissButton = { TextButton({ siteFor = null; pick(e.id) }) { Text("У меня уже есть файл") } },
        )
    }
    message?.let {
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("Образ не подошёл") },
            text = { Text(it) },
            confirmButton = { TextButton({ message = null }) { Text("Понятно") } },
        )
    }
    setupFor?.let { e ->
        SetupSheet(e, onDismiss = { setupFor = null }, onSave = { n -> update(items.map { if (it.id == n.id) n else it }); setupFor = null })
    }
    if (addDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addDialog = false },
            title = { Text("Своя система") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val id = UUID.randomUUID().toString()
                    val n = if (name.isBlank()) "Моя система" else name.trim()
                    update(items + OsEntry(id, n, "Свой образ (.iso / .img / .zip)", 0xFFD6336C, 0xFF45102B, custom = true))
                    addDialog = false
                    pick(id)
                }) { Text("Выбрать образ") }
            },
            dismissButton = { TextButton({ addDialog = false }) { Text("Отмена") } },
        )
    }
}

/** Настройки системы выезжают снизу (открываются свайпом вверх по карточке). */
private val SCREEN_PRESETS = listOf("Лёгкий" to (540 to 1200), "Телефон" to (720 to 1600), "Планшет" to (900 to 1600), "HD" to (1080 to 1920))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupSheet(e: OsEntry, onDismiss: () -> Unit, onSave: (OsEntry) -> Unit) {
    var ram by remember(e.id) { mutableFloatStateOf(e.ramMb / 512f) }
    var cores by remember(e.id) { mutableFloatStateOf(e.cores.toFloat()) }
    var disk by remember(e.id) { mutableFloatStateOf(e.diskGb.toFloat()) }
    var resolution by remember(e.id) { mutableStateOf(SCREEN_PRESETS.firstOrNull { it.second.first == e.vmWidth }?.first ?: if (e.vmWidth >= 1000) "HD" else if (e.vmWidth >= 800) "Планшет" else "Телефон") }
    var network by remember(e.id) { mutableStateOf(e.networkEnabled) }
    val presets = SCREEN_PRESETS
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF111522),
        contentColor = Color.White,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp).padding(bottom = 30.dp).navigationBarsPadding(),
        ) {
            Text("Параметры виртуальной машины", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(e.name, color = Color(0xFF9BA6BD), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2232)), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("ПРОИЗВОДИТЕЛЬНОСТЬ", color = Color(0xFF8FA7CE), style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Оперативная память", fontWeight = FontWeight.SemiBold)
                        Text("${(ram * 512 / 1024).let { String.format("%.1f", it) }} ГБ", color = Color(0xFF8FE3C0))
                    }
                    Slider(ram, { ram = it }, valueRange = 2f..16f, steps = 13)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ядра процессора", fontWeight = FontWeight.SemiBold)
                        Text("${cores.toInt()}", color = Color(0xFF8FE3C0))
                    }
                    Slider(cores, { cores = it }, valueRange = 1f..8f, steps = 6)
                    Text("Для скорости лучше 4 ядра и 3–4 ГБ памяти: больше ядер и памяти эмуляцию не ускоряют, а нагрузка и нагрев растут.", color = Color(0xFF8A93A8), style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Размер диска", fontWeight = FontWeight.SemiBold)
                        Text("${disk.toInt()} ГБ", color = Color(0xFF8FE3C0))
                    }
                    Slider(disk, { disk = it }, valueRange = 8f..128f, steps = 14)
                    Text("Размер диска применяется к новым виртуальным дискам ISO.", color = Color(0xFF8A93A8), style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2232)), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("ЭКРАН", color = Color(0xFF8FA7CE), style = MaterialTheme.typography.labelMedium)
                    Text("Разрешение виртуального устройства", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp, bottom = 12.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        presets.forEach { (label, _) ->
                            FilterChip(
                                selected = resolution == label,
                                onClick = { resolution = label },
                                label = { Text(label) },
                            )
                        }
                    }
                    val selected = presets.first { it.first == resolution }.second
                    Text("${selected.first} × ${selected.second}", color = Color(0xFF8FE3C0), style = MaterialTheme.typography.bodySmall)
                    Text("Чем меньше разрешение, тем быстрее идёт анимация и загрузка: картинку рисует эмулируемый процессор. «Лёгкий» — самый быстрый.", color = Color(0xFF8A93A8), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2232)), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Сетевое подключение", fontWeight = FontWeight.SemiBold)
                        Text("Доступ в интернет внутри виртуальной машины", color = Color(0xFF8A93A8), style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = network, onCheckedChange = { network = it })
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val selected = presets.first { it.first == resolution }.second
                    onSave(e.copy(
                        ramMb = (ram * 512).toInt(), cores = cores.toInt(), diskGb = disk.toInt(),
                        vmWidth = selected.first, vmHeight = selected.second, networkEnabled = network,
                    ))
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(17.dp),
            ) { Text("Сохранить настройки", fontWeight = FontWeight.SemiBold) }
            Text("Изменения сохраняются на устройстве и применяются при следующем запуске.", color = Color(0xFF8A93A8), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

/** Плавное затемнение с пульсирующим кольцом при выключении системы. */
@Composable
fun ShutdownOverlay(visible: Boolean, text: String = "Выключение…") {
    val dim by animateFloatAsState(if (visible) 1f else 0f, tween(600), label = "dim")
    if (dim <= 0.01f) return
    val t = rememberInfiniteTransition(label = "pulse")
    val k by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "k")
    Box(Modifier.fillMaxSize().alpha(dim).background(Color(0xFF05060A).copy(alpha = .94f)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(120.dp)) {
                val c = Offset(size.width / 2, size.height / 2)
                val base = size.minDimension * .22f
                drawCircle(Color.White.copy(.9f), base * (1f - .15f * k), c)
                drawCircle(Color.White.copy(.5f * (1f - k)), base + size.minDimension * .3f * k, c, style = Stroke(3.dp.toPx()))
            }
            Spacer(Modifier.height(20.dp))
            Text(text, color = Color.White, fontSize = 18.sp)
        }
    }
}
