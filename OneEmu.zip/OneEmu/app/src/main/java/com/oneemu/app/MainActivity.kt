package com.oneemu.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

private fun copyImage(ctx: Context, uri: Uri, id: String): String {
    var ext = "img"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) c.getString(i)?.substringAfterLast('.', "img")?.let { ext = it.lowercase() }
        }
    }
    val f = File(ctx.filesDir, "images/$id.$ext")
    f.parentFile?.mkdirs()
    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
    return f.absolutePath
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(Repo.load(ctx)) }
    var running by remember { mutableStateOf<OsEntry?>(null) }
    var pendingId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var setupFor by remember { mutableStateOf<OsEntry?>(null) }
    var addDialog by remember { mutableStateOf(false) }

    fun update(list: List<OsEntry>) { items = list; Repo.save(ctx, list) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = pendingId
        if (uri != null && id != null) scope.launch {
            busy = true
            val path = runCatching { withContext(Dispatchers.IO) { copyImage(ctx, uri, id) } }.getOrNull()
            if (path != null) update(items.map { if (it.id == id) it.copy(image = path) else it })
            busy = false
        }
    }
    fun pick(id: String) { pendingId = id; picker.launch(arrayOf("*/*")) }

    Box(Modifier.fillMaxSize()) {
        val r = running
        if (r == null) {
            HomeScreen(items, onPick = { pick(it.id) }, onRun = { running = it }, onSetup = { setupFor = it }, onAdd = { addDialog = true })
        } else {
            RunScreen(r, onExit = { QemuRunner.stop(); running = null })
        }
        if (busy) Box(Modifier.fillMaxSize().then(Modifier), contentAlignment = Alignment.Center) {
            Surface(shape = MaterialTheme.shapes.large, tonalElevation = 8.dp) {
                Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(16.dp)); Text("Копирование образа…")
                }
            }
        }
    }

    setupFor?.let { e ->
        SetupDialog(e, onDismiss = { setupFor = null }, onSave = { n -> update(items.map { if (it.id == n.id) n else it }); setupFor = null })
    }
    if (addDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { addDialog = false },
            title = { Text("Своя система") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val id = UUID.randomUUID().toString()
                    val n = if (name.isBlank()) "Моя система" else name.trim()
                    update(items + OsEntry(id, n, "Свой образ", 0xFFD6336C, 0xFF45102B, custom = true))
                    addDialog = false
                    pick(id)
                }) { Text("Выбрать образ") }
            },
            dismissButton = { TextButton({ addDialog = false }) { Text("Отмена") } },
        )
    }
}

@Composable
fun SetupDialog(e: OsEntry, onDismiss: () -> Unit, onSave: (OsEntry) -> Unit) {
    var ram by remember { mutableFloatStateOf(e.ramMb / 512f) }
    var cores by remember { mutableFloatStateOf(e.cores.toFloat()) }
    var disk by remember { mutableFloatStateOf(e.diskGb.toFloat()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Настройка: ${e.name}") },
        text = {
            Column {
                Text("RAM: ${(ram * 512).toInt()} МБ"); Slider(ram, { ram = it }, valueRange = 2f..16f, steps = 13)
                Text("Ядра CPU: ${cores.toInt()}"); Slider(cores, { cores = it }, valueRange = 1f..8f, steps = 6)
                Text("Диск (для ISO): ${disk.toInt()} ГБ"); Slider(disk, { disk = it }, valueRange = 8f..64f, steps = 6)
            }
        },
        confirmButton = { TextButton({ onSave(e.copy(ramMb = (ram * 512).toInt(), cores = cores.toInt(), diskGb = disk.toInt())) }) { Text("Сохранить") } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } },
    )
}
