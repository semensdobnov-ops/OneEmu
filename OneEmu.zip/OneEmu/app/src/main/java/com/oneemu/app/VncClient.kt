package com.oneemu.app

import android.graphics.Bitmap
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import kotlin.concurrent.thread

/** Минимальный RFB/VNC-клиент: без пароля, Raw-кодирование, DesktopSize. */
class VncClient(private val port: Int, private val onUpdate: () -> Unit) {
    @Volatile var bmp: Bitmap? = null
    @Volatile var error: String? = null
    @Volatile private var running = true
    private var sock: Socket? = null
    private var out: DataOutputStream? = null

    fun start() = thread(isDaemon = true) {
        try { connect(); loop() } catch (e: Exception) { if (running) { error = e.message ?: "Соединение закрыто"; onUpdate() } }
    }

    fun close() { running = false; runCatching { sock?.close() } }

    private fun connect() {
        var s: Socket? = null
        repeat(120) {
            if (s == null && running) {
                try { s = Socket("127.0.0.1", port) } catch (_: Exception) { Thread.sleep(1000) }
            }
        }
        val so = s ?: throw Exception("QEMU не отвечает (проверьте лог)")
        sock = so
        val inp = DataInputStream(so.getInputStream().buffered(1 shl 16))
        out = DataOutputStream(so.getOutputStream())
        inStream = inp
        val ver = ByteArray(12); inp.readFully(ver)
        send { it.write("RFB 003.008\n".toByteArray()) }
        val n = inp.readUnsignedByte()
        if (n == 0) throw Exception("VNC отклонил соединение")
        val types = ByteArray(n); inp.readFully(types)
        send { it.writeByte(1) }
        if (inp.readInt() != 0) throw Exception("Ошибка авторизации VNC")
        send { it.writeByte(1) }
        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
        inp.skipBytes(16)
        val nameLen = inp.readInt(); inp.skipBytes(nameLen)
        bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        send {
            it.writeByte(0); it.write(ByteArray(3))
            it.writeByte(32); it.writeByte(24); it.writeByte(0); it.writeByte(1)
            it.writeShort(255); it.writeShort(255); it.writeShort(255)
            it.writeByte(16); it.writeByte(8); it.writeByte(0); it.write(ByteArray(3))
        }
        send { it.writeByte(2); it.writeByte(0); it.writeShort(2); it.writeInt(0); it.writeInt(-223) }
        requestUpdate(false)
    }

    private var inStream: DataInputStream? = null

    private fun loop() {
        val inp = inStream!!
        var row = ByteArray(0)
        var px = IntArray(0)
        while (running) {
            when (inp.readUnsignedByte()) {
                0 -> {
                    inp.skipBytes(1)
                    val rects = inp.readUnsignedShort()
                    repeat(rects) {
                        val x = inp.readUnsignedShort(); val y = inp.readUnsignedShort()
                        val w = inp.readUnsignedShort(); val h = inp.readUnsignedShort()
                        when (inp.readInt()) {
                            0 -> {
                                val b = bmp ?: return@repeat
                                if (row.size < w * 4) { row = ByteArray(w * 4); px = IntArray(w) }
                                for (r in 0 until h) {
                                    inp.readFully(row, 0, w * 4)
                                    for (i in 0 until w) {
                                        val o = i * 4
                                        px[i] = (0xFF shl 24) or ((row[o + 2].toInt() and 255) shl 16) or
                                            ((row[o + 1].toInt() and 255) shl 8) or (row[o].toInt() and 255)
                                    }
                                    if (x + w <= b.width && y + r < b.height) b.setPixels(px, 0, w, x, y + r, w, 1)
                                }
                            }
                            -223 -> bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        }
                    }
                    onUpdate()
                    requestUpdate(true)
                }
                1 -> { inp.skipBytes(1); inp.skipBytes(2); val c = inp.readUnsignedShort(); inp.skipBytes(c * 6) }
                3 -> { inp.skipBytes(3); val l = inp.readInt(); inp.skipBytes(l) }
            }
        }
    }

    private fun send(block: (DataOutputStream) -> Unit) {
        val o = out ?: return
        synchronized(o) { block(o); o.flush() }
    }

    private fun requestUpdate(incremental: Boolean) {
        val b = bmp ?: return
        send { it.writeByte(3); it.writeByte(if (incremental) 1 else 0); it.writeShort(0); it.writeShort(0); it.writeShort(b.width); it.writeShort(b.height) }
    }

    fun pointer(mask: Int, x: Int, y: Int) =
        runCatching { send { it.writeByte(5); it.writeByte(mask); it.writeShort(x); it.writeShort(y) } }

    fun key(sym: Int) = thread {
        runCatching {
            send { it.writeByte(4); it.writeByte(1); it.writeShort(0); it.writeInt(sym) }
            send { it.writeByte(4); it.writeByte(0); it.writeShort(0); it.writeInt(sym) }
        }
    }
}
