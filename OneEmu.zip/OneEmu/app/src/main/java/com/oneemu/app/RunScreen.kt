package com.oneemu.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.withContext

@Composable
fun RunScreen(entry: OsEntry, onExit: () -> Unit) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("Запуск QEMU…") }
    var tick by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf("") }
    var client by remember { mutableStateOf<VncClient?>(null) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var kbd by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val ime = LocalSoftwareKeyboardController.current
    val sentinel = "  "
    var tf by remember { mutableStateOf(TextFieldValue(sentinel, TextRange(sentinel.length))) }
    BackHandler { if (kbd) kbd = false else confirmExit = true }
    LaunchedEffect(kbd) {
        if (kbd) { delay(100); runCatching { focus.requestFocus() }; ime?.show() } else ime?.hide()
    }

    LaunchedEffect(entry.id) {
        val err = withContext(Dispatchers.IO) { QemuRunner.start(ctx, entry) }
        if (err != null) { status = err; return@LaunchedEffect }
        status = "Загрузка системы… (на TCG это может занять несколько минут)"
        val c = VncClient(QemuRunner.VNC_PORT) { tick++ }
        client = c; c.start()
        var secs = 0
        while (true) {
            delay(2000)
            secs += 2
            hint = "Работает %d:%02d · %s".format(secs / 60, secs % 60, QemuRunner.serialLast(ctx))
            if (!QemuRunner.alive()) { status = "QEMU завершился:\n" + QemuRunner.log(ctx); break }
            c.error?.let { status = it }
        }
    }
    DisposableEffect(Unit) { onDispose { client?.close() } }

    fun layout(b: android.graphics.Bitmap): Triple<Float, Float, Float> {
        val s = minOf(size.width / b.width.toFloat(), size.height / b.height.toFloat())
        return Triple(s, (size.width - b.width * s) / 2f, (size.height - b.height * s) / 2f)
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        Box(
            Modifier.weight(1f).fillMaxWidth()
                .onSizeChanged { size = it }
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull() ?: continue
                            val b = client?.bmp ?: continue
                            val (s, ox, oy) = layout(b)
                            val x = ((ch.position.x - ox) / s).toInt().coerceIn(0, b.width - 1)
                            val y = ((ch.position.y - oy) / s).toInt().coerceIn(0, b.height - 1)
                            client?.pointer(if (ch.pressed) 1 else 0, x, y)
                            ch.consume()
                        }
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                tick.let { }
                val b = client?.bmp ?: return@Canvas
                val (s, ox, oy) = layout(b)
                drawIntoCanvas {
                    it.nativeCanvas.drawBitmap(b, null, android.graphics.RectF(ox, oy, ox + b.width * s, oy + b.height * s), null)
                }
            }
            val noFrame = tick.let { client?.bmp == null }
            if (noFrame) {
                Column(Modifier.align(Alignment.Center).padding(24.dp).verticalScroll(rememberScrollState())) {
                    Text(status, color = Color.White)
                }
            }
        }
        if (hint.isNotEmpty()) {
            Text(
                hint, color = Color.White.copy(.6f), fontSize = 11.sp, maxLines = 2,
                modifier = Modifier.fillMaxWidth().background(Color(0xFF14161F)).padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
        // невидимое поле: через него работает клавиатура телефона
        if (kbd) {
            BasicTextField(
                value = tf,
                onValueChange = { nv ->
                    val t = nv.text
                    if (t.length < sentinel.length) client?.key(0xFF08)             // Backspace
                    else if (t.length > sentinel.length) t.substring(sentinel.length).forEach { client?.type(it) }
                    tf = TextFieldValue(sentinel, TextRange(sentinel.length))
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(autoCorrect = false, keyboardType = KeyboardType.Text, imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { client?.key(0xFF0D) }),     // Enter
                modifier = Modifier.size(1.dp).alpha(0f).focusRequester(focus),
            )
        }
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF14161F)).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            CtlButton("Назад", Icon.BACK) { client?.key(0xFF1B) }                         // Esc = «Назад» в Android
            CtlButton("Домой", Icon.HOME) { client?.combo(0xFFEB, 0xFF0D) }               // Meta+Enter = «Домой»
            CtlButton("Недавние", Icon.RECENTS) { client?.combo(0xFFE9, 0xFF09) }         // Alt+Tab
            CtlButton("Клавиатура", Icon.KEYBOARD, active = kbd) { kbd = !kbd }
            CtlButton("Выключить", Icon.POWER, tint = Color(0xFFFF6B6B)) { confirmExit = true }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Выключить систему?") },
            text = { Text("Виртуальный телефон будет остановлен. Несохранённые данные внутри него пропадут.") },
            confirmButton = { TextButton({ confirmExit = false; onExit() }) { Text("Выключить") } },
            dismissButton = { TextButton({ confirmExit = false }) { Text("Отмена") } },
        )
    }
}

private enum class Icon { BACK, HOME, RECENTS, KEYBOARD, POWER }

@Composable
private fun RowScope.CtlButton(label: String, icon: Icon, tint: Color = Color.White, active: Boolean = false, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
            .background(if (active) Color.White.copy(.16f) else Color.Transparent)
            .clickable { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Canvas(Modifier.size(26.dp)) { drawIcon(icon, tint) }
        Spacer(Modifier.height(2.dp))
        Text(label, color = tint.copy(.85f), fontSize = 10.sp, maxLines = 1)
    }
}

private fun DrawScope.drawIcon(icon: Icon, c: Color) {
    val w = size.width; val h = size.height
    val st = Stroke(w * .09f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
    when (icon) {
        Icon.BACK -> drawPath(Path().apply { moveTo(w * .72f, h * .15f); lineTo(w * .25f, h * .5f); lineTo(w * .72f, h * .85f); close() }, c, style = st)
        Icon.HOME -> drawCircle(c, w * .36f, center, style = st)
        Icon.RECENTS -> drawRoundRect(c, Offset(w * .17f, w * .17f), Size(w * .66f, w * .66f), CornerRadius(w * .14f), style = st)
        Icon.KEYBOARD -> {
            drawRoundRect(c, Offset(w * .05f, h * .22f), Size(w * .9f, h * .56f), CornerRadius(w * .1f), style = st)
            for (i in 0..2) for (j in 0..1) drawCircle(c, w * .04f, Offset(w * (.27f + .23f * i), h * (.4f + .0f) + j * h * .12f))
            drawLine(c, Offset(w * .3f, h * .66f), Offset(w * .7f, h * .66f), w * .07f, StrokeCap.Round)
        }
        Icon.POWER -> {
            drawArc(c, -55f, 290f, false, Offset(w * .17f, h * .2f), Size(w * .66f, h * .66f), style = st)
            drawLine(c, Offset(w * .5f, h * .08f), Offset(w * .5f, h * .5f), w * .09f, StrokeCap.Round)
        }
    }
}
