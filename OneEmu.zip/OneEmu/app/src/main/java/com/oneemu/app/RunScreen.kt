package com.oneemu.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun RunScreen(entry: OsEntry, onExit: () -> Unit) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("Запуск QEMU…") }
    var tick by remember { mutableIntStateOf(0) }
    var client by remember { mutableStateOf<VncClient?>(null) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    BackHandler { onExit() }

    LaunchedEffect(entry.id) {
        val err = withContext(Dispatchers.IO) { QemuRunner.start(ctx, entry) }
        if (err != null) { status = err; return@LaunchedEffect }
        status = "Загрузка системы… (на TCG это может занять несколько минут)"
        val c = VncClient(QemuRunner.VNC_PORT) { tick++ }
        client = c; c.start()
        while (true) {
            delay(2000)
            if (!QemuRunner.alive()) { status = "QEMU завершился:\n" + QemuRunner.log(ctx); break }
            c.error?.let { status = it }
        }
    }
    DisposableEffect(Unit) { onDispose { client?.close() } }

    fun layout(b: android.graphics.Bitmap): Triple<Float, Float, Float> {
        val s = minOf(size.width / b.width.toFloat(), size.height / b.height.toFloat())
        return Triple(s, (size.width - b.width * s) / 2f, (size.height - b.height * s) / 2f)
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        Box(
            Modifier.weight(1f).fillMaxWidth()
                .onSizeChanged { size = it }
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull() ?: continue
                            val b = client?.bmp ?: continue
                            val (s, ox, oy) = layout(b)
                            val x = ((ch.position.x - ox) / s).toInt().coerceIn(0, b.width - 1)
                            val y = ((ch.position.y - oy) / s).toInt().coerceIn(0, b.height - 1)
                            client?.pointer(if (ch.pressed) 1 else 0, x, y)
                            ch.consume()
                        }
                    }
                },
        ) {
            Canvas(Modifier.fillMaxSize()) {
                tick.let { }
                val b = client?.bmp ?: return@Canvas
                val (s, ox, oy) = layout(b)
                drawIntoCanvas {
                    it.nativeCanvas.drawBitmap(b, null, android.graphics.RectF(ox, oy, ox + b.width * s, oy + b.height * s), null)
                }
            }
            if (client?.bmp == null) {
                Column(Modifier.align(Alignment.Center).padding(24.dp).verticalScroll(rememberScrollState())) {
                    Text(status, color = Color.White)
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF14161F)), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton({ client?.key(0xFF1B) }) { Text("Назад", color = Color.White) }
            TextButton({ client?.key(0xFF50) }) { Text("Домой", color = Color.White) }
            TextButton({ onExit() }) { Text("Выключить", color = Color(0xFFFF6B6B)) }
        }
    }
}
