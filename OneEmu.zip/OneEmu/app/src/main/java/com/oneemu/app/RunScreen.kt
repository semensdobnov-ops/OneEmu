package com.oneemu.app

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

@Composable
fun RunScreen(entry: OsEntry, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    var errorText by remember { mutableStateOf<String?>(null) }
    var stage by remember { mutableStateOf(VmBootStage.PREPARING) }
    var tick by remember { mutableIntStateOf(0) }
    var client by remember { mutableStateOf<VncClient?>(null) }
    var viewportSize by remember { mutableStateOf(IntSize.Zero) }
    var kbd by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var showLogDialog by remember { mutableStateOf(false) }
    var elapsedSec by remember { mutableIntStateOf(0) }

    var bubbleX by remember { mutableFloatStateOf(0f) }
    var bubbleY by remember { mutableFloatStateOf(0f) }
    var bubbleInitialized by remember { mutableStateOf(false) }

    val focus = remember { FocusRequester() }
    val ime = LocalSoftwareKeyboardController.current
    val sentinel = "  "
    var tf by remember { mutableStateOf(TextFieldValue(sentinel, TextRange(sentinel.length))) }

    val importFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val sharedDir = File(ctx.filesDir, "shared/${entry.id}").apply { mkdirs() }
                val outFile = File(sharedDir, "imported_${System.currentTimeMillis()}")
                ctx.contentResolver.openInputStream(uri)?.use { inp ->
                    outFile.outputStream().use { out -> inp.copyTo(out) }
                }
                Toast.makeText(ctx, "Файл импортирован в папку обмена ВМ", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(ctx, "Ошибка импорта: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    BackHandler {
        when {
            menuOpen -> menuOpen = false
            kbd -> kbd = false
            else -> client?.key(0xFF1B)
        }
    }

    LaunchedEffect(kbd) {
        if (kbd) {
            delay(100)
            runCatching { focus.requestFocus() }
            ime?.show()
        } else {
            ime?.hide()
        }
    }

    LaunchedEffect(entry.id) {
        errorText = null
        elapsedSec = 0
        val err = withContext(Dispatchers.IO) { QemuRunner.start(ctx, entry) }
        if (err != null) {
            errorText = err
            return@LaunchedEffect
        }
        val c = VncClient(QemuRunner.VNC_PORT) { tick++ }
        client = c
        c.start()

        while (true) {
            delay(1000)
            elapsedSec += 1
            val hasFrame = c.bmp != null
            stage = QemuRunner.detectStage(ctx, elapsedSec, hasFrame)
            if (!QemuRunner.alive()) {
                errorText = "Виртуальная система остановлена:\n" + QemuRunner.log(ctx)
                break
            }
            c.error?.let {
                errorText = "$it\n\nДиагностика:\n" + QemuRunner.log(ctx)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose { client?.close() }
    }

    fun layout(b: android.graphics.Bitmap): Triple<Float, Float, Float> {
        val s = minOf(viewportSize.width / b.width.toFloat(), viewportSize.height / b.height.toFloat())
        return Triple(s, (viewportSize.width - b.width * s) / 2f, (viewportSize.height - b.height * s) / 2f)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding()
            .onSizeChanged { sz ->
                viewportSize = sz
                if (!bubbleInitialized && sz.width > 0 && sz.height > 0) {
                    val margin = with(density) { 16.dp.toPx() }
                    val bubblePx = with(density) { 46.dp.toPx() }
                    bubbleX = sz.width - bubblePx - margin
                    bubbleY = sz.height * 0.42f
                    bubbleInitialized = true
                }
            }
    ) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val ev = awaitPointerEvent()
                                val ch = ev.changes.firstOrNull() ?: continue
                                val b = client?.bmp ?: continue
                                val (s, ox, oy) = layout(b)
                                val x = ((ch.position.x - ox) / s).toInt().coerceIn(0, b.width - 1)
                                val y = ((ch.position.y - oy) / s).toInt().coerceIn(0, b.height - 1)
                                client?.pointer(if (ch.pressed) 1 else 0, x, y)
                                ch.consume()
                            }
                        }
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    tick.let { }
                    val b = client?.bmp ?: return@Canvas
                    val (s, ox, oy) = layout(b)
                    drawIntoCanvas {
                        it.nativeCanvas.drawBitmap(
                            b,
                            null,
                            android.graphics.RectF(ox, oy, ox + b.width * s, oy + b.height * s),
                            null,
                        )
                    }
                }

                if (kbd) {
                    BasicTextField(
                        value = tf,
                        onValueChange = { nv ->
                            val t = nv.text
                            if (t.length < sentinel.length) client?.key(0xFF08)
                            else if (t.length > sentinel.length) t.substring(sentinel.length).forEach { client?.type(it) }
                            tf = TextFieldValue(sentinel, TextRange(sentinel.length))
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            autoCorrect = false,
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Send,
                        ),
                        keyboardActions = KeyboardActions(onSend = { client?.key(0xFF0D) }),
                        modifier = Modifier.size(1.dp).alpha(0f).focusRequester(focus),
                    )
                }

                val hasFrame = tick.let { client?.bmp != null }
                AnimatedVisibility(
                    visible = !hasFrame || errorText != null,
                    enter = fadeIn(tween(250)),
                    exit = fadeOut(tween(400)),
                ) {
                    VmBootSplash(
                        entry = entry,
                        stage = stage,
                        elapsedSec = elapsedSec,
                        errorText = errorText,
                        onExit = onExit,
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .background(Color(0xFF0A0A0D)),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NavIconButton(VmIcon.BACK) { client?.key(0xFF1B) }
                NavIconButton(VmIcon.HOME) { client?.combo(0xFFEB, 0xFF0D) }
                NavIconButton(VmIcon.RECENTS) { client?.combo(0xFFE9, 0xFF09) }
            }
        }

        if (bubbleInitialized) {
            val bubbleSize = 46.dp
            val bubblePx = with(density) { bubbleSize.toPx() }
            Box(
                Modifier
                    .offset { IntOffset(bubbleX.roundToInt(), bubbleY.roundToInt()) }
                    .size(bubbleSize)
                    .shadow(10.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF0D9488))))
                    .border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                    .pointerInput(viewportSize) {
                        detectDragGestures(
                            onDragEnd = {
                                val maxX = (viewportSize.width - bubblePx).coerceAtLeast(0f)
                                bubbleX = if (bubbleX < maxX / 2f) 16f else (maxX - 16f).coerceAtLeast(0f)
                            }
                        ) { change, dragAmount ->
                            change.consume()
                            val maxX = (viewportSize.width - bubblePx).coerceAtLeast(0f)
                            val maxY = (viewportSize.height - bubblePx).coerceAtLeast(0f)
                            bubbleX = (bubbleX + dragAmount.x).coerceIn(0f, maxX)
                            bubbleY = (bubbleY + dragAmount.y).coerceIn(0f, maxY)
                        }
                    }
                    .clickable { menuOpen = !menuOpen },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.size(22.dp)) {
                    val w = size.width
                    val h = size.height
                    val p = Path().apply {
                        moveTo(w * 0.18f, h * 0.25f)
                        lineTo(w * 0.50f, h * 0.75f)
                        lineTo(w * 0.82f, h * 0.25f)
                    }
                    drawPath(p, Color.White, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                }
            }
        }

        if (menuOpen) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable { menuOpen = false },
                contentAlignment = Alignment.Center,
            ) {
                Card(
                    modifier = Modifier
                        .width(300.dp)
                        .clickable(enabled = false) {},
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171B26)),
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(entry.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            "Быстрое управление виртуальным телефоном",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 12.sp,
                        )
                        Spacer(Modifier.height(4.dp))

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            QuickTile("Домой", Modifier.weight(1f)) {
                                menuOpen = false; client?.combo(0xFFEB, 0xFF0D)
                            }
                            QuickTile("Назад", Modifier.weight(1f)) {
                                menuOpen = false; client?.key(0xFF1B)
                            }
                            QuickTile("Недавние", Modifier.weight(1f)) {
                                menuOpen = false; client?.combo(0xFFE9, 0xFF09)
                            }
                        }

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            QuickTile(if (kbd) "Скрыть клав." else "Клавиатура", Modifier.weight(1f)) {
                                menuOpen = false; kbd = !kbd
                            }
                            QuickTile("Импорт APK", Modifier.weight(1f)) {
                                menuOpen = false; importFileLauncher.launch(arrayOf("*/*"))
                            }
                        }

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            QuickTile("Диагностика", Modifier.weight(1f)) {
                                menuOpen = false; showLogDialog = true
                            }
                            QuickTile("Выключить", Modifier.weight(1f), danger = true) {
                                menuOpen = false; confirmExit = true
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLogDialog) {
        AlertDialog(
            onDismissRequest = { showLogDialog = false },
            title = { Text("Состояние виртуальной системы") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        QemuRunner.log(ctx).ifBlank { "Система работает штатно, ошибок нет." },
                        fontSize = 12.sp,
                    )
                }
            },
            confirmButton = { TextButton({ showLogDialog = false }) { Text("Закрыть") } },
        )
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Выключить виртуальный телефон?") },
            text = { Text("Текущая сессия ${entry.name} будет завершена.") },
            confirmButton = {
                TextButton({
                    confirmExit = false
                    onExit()
                }) { Text("Выключить", color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton({ confirmExit = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun VmBootSplash(
    entry: OsEntry,
    stage: VmBootStage,
    elapsedSec: Int,
    errorText: String?,
    onExit: () -> Unit,
) {
    val animatedProgress by animateFloatAsState(
        targetValue = stage.progress,
        animationSpec = tween(500),
        label = "bootProgress",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(entry.c1), Color(0xFF0B0D14)))),
        contentAlignment = Alignment.Center,
    ) {
        if (errorText != null) {
            Column(
                Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Ошибка запуска", color = Color(0xFFFF8A8A), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text(errorText, color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onExit) { Text("Вернуться в меню") }
            }
        } else {
            Column(
                Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .size(84.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        entry.name.take(2).uppercase(),
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.height(22.dp))
                Text(entry.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(stage.title, color = Color.White.copy(alpha = 0.78f), fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .width(220.dp)
                        .height(6.dp)
                        .clip(CircleShape),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.2f),
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Загрузка виртуального рабочего стола · ${elapsedSec}с",
                    color = Color.White.copy(alpha = 0.55f),
                    fontSize = 12.sp,
                )
            }
        }
    }
}

@Composable
private fun QuickTile(title: String, modifier: Modifier = Modifier, danger: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (danger) Color(0xFF3B1820) else Color(0xFF23293A))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            title,
            color = if (danger) Color(0xFFFF8A8A) else Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
        )
    }
}

private enum class VmIcon { BACK, HOME, RECENTS }

@Composable
private fun NavIconButton(icon: VmIcon, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp, 36.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(18.dp)) { drawNavIcon(icon, Color.White.copy(alpha = 0.85f)) }
    }
}

private fun DrawScope.drawNavIcon(icon: VmIcon, c: Color) {
    val w = size.width
    val h = size.height
    val st = Stroke(w * 0.11f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round)
    when (icon) {
        VmIcon.BACK -> drawPath(
            Path().apply {
                moveTo(w * 0.74f, h * 0.14f)
                lineTo(w * 0.24f, h * 0.50f)
                lineTo(w * 0.74f, h * 0.86f)
                close()
            },
            c,
            style = st,
        )
        VmIcon.HOME -> drawCircle(c, w * 0.36f, center, style = st)
        VmIcon.RECENTS -> drawRoundRect(
            c,
            Offset(w * 0.16f, w * 0.16f),
            Size(w * 0.68f, w * 0.68f),
            CornerRadius(w * 0.15f),
            style = st,
        )
    }
}
