package com.oneemu.app

import android.content.Context
import android.os.Build
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipFile

/** Запускает qemu-system-aarch64 (машина "virt") — то есть мобильную ARM64-версию Android, а не ПК-версию. */
object QemuRunner {
    private var proc: Process? = null
    const val VNC_PORT = 5901
    private const val FW = "edk2-aarch64-code.fd"
    private const val X86_BIOS = "bios-256k.bin"

    fun alive() = proc?.isAlive == true

    fun log(ctx: Context): String =
        runCatching { File(ctx.filesDir, "qemu.log").readText().takeLast(600) }.getOrDefault("")

    /** Последняя строка консоли гостя (если система пишет в serial). */
    fun serialLast(ctx: Context): String = runCatching {
        val f = File(ctx.filesDir, "serial.log")
        RandomAccessFile(f, "r").use { r ->
            val n = minOf(400L, r.length()).toInt()
            r.seek(r.length() - n)
            val b = ByteArray(n); r.readFully(b)
            String(b, Charsets.UTF_8).lines().map { it.trim() }.lastOrNull { it.isNotEmpty() }?.takeLast(90) ?: ""
        }
    }.getOrDefault("")

    private fun diag(ctx: Context): String {
        val d = File(ctx.applicationInfo.nativeLibraryDir)
        val inApk = runCatching {
            ZipFile(ctx.applicationInfo.sourceDir).use { z ->
                z.entries().asSequence().map { it.name }.filter { it.startsWith("lib/") }.joinToString("\n").ifEmpty { "нет" }
            }
        }.getOrDefault("?")
        return "\n\n[Диагностика]\nABI телефона: ${Build.SUPPORTED_ABIS.joinToString()}\n" +
            "Размер APK: ${File(ctx.applicationInfo.sourceDir).length() / 1048576} МБ\n" +
            "Библиотеки внутри APK:\n$inApk\n" +
            "Распаковано в ${d.path}: ${d.list()?.joinToString().orEmpty().ifEmpty { "ничего" }}"
    }

    /** Рекурсивно копирует папку из assets. */
    private fun copyAssets(ctx: Context, path: String, dst: File) {
        val list = ctx.assets.list(path) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAssets(ctx, "$path/$it", File(dst, it)) }
        }
    }

    private fun ensureShare(ctx: Context): File {
        val dst = File(ctx.filesDir, "qemu-share")
        if (!File(dst, ".ok5").exists()) {
            dst.deleteRecursively()
            dst.mkdirs()
            copyAssets(ctx, "qemu-share", dst)
            File(dst, "README.txt").delete()
            if (File(dst, FW).exists() && File(dst, "keymaps/en-us").exists()) File(dst, ".ok5").writeText("1")
        }
        return dst
    }

    /** Возвращает текст ошибки или null, если QEMU запущен. */
    fun start(ctx: Context, e: OsEntry): String? {
        // OneEmu запускает только мобильные ARM64 VM. PC/Android-x86 образы не поддерживаются.
        if (e.architecture.startsWith("x86")) return "Образы Android-x86 для ПК больше не поддерживаются. Выберите мобильный ARM64-образ, предназначенный для QEMU virt."
        val x86 = false
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")
        if (!bin.exists()) return "В APK отсутствует ARM64-движок QEMU (libqemu.so). Пересоберите APK через GitHub Actions → Build APK with QEMU." + diag(ctx)
        val img = e.image?.let { File(it) }
        if (img == null || !img.exists()) return "Образ системы не выбран."
        stop()
        // Не показываем хвост предыдущего запуска: иначе диагностика может ввести в заблуждение.
        runCatching { File(ctx.filesDir, "qemu.log").delete() }
        runCatching { File(ctx.filesDir, "serial.log").delete() }
        val share = ensureShare(ctx)
        if (x86 && !File(share, X86_BIOS).exists()) return "Нет BIOS для QEMU x86 (assets/qemu-share/$X86_BIOS). Пересоберите APK через GitHub Actions."
        if (!x86 && !File(share, FW).exists()) return "Нет UEFI-прошивки для ARM64 (assets/qemu-share). Соберите APK через GitHub Actions — он добавит её автоматически."

        val cmd = mutableListOf(bin.absolutePath, "-L", share.absolutePath)
        if (x86) {
            // Android-x86 загружается как обычная PC-система с BIOS, VGA и IDE CD-ROM.
            cmd += listOf(
                "-machine", "pc", "-cpu", "qemu64", "-accel", "tcg,thread=multi",
                "-m", e.ramMb.toString(), "-smp", e.cores.toString(),
                "-bios", File(share, X86_BIOS).absolutePath,
                "-vga", "std", "-usb", "-device", "usb-tablet", "-device", "usb-kbd",
                "-serial", "file:${File(ctx.filesDir, "serial.log").absolutePath}",
                "-vnc", "127.0.0.1:1",
            )
        } else {
            // Телефонные ARM64 VM используют virt + UEFI + virtio GPU.
            val vars = File(ctx.filesDir, "disks/${e.id}-vars.fd")
            vars.parentFile?.mkdirs()
            if (!vars.exists()) RandomAccessFile(vars, "rw").use { it.setLength(64L * 1024 * 1024) }
            cmd += listOf(
                "-machine", "virt,gic-version=3", "-cpu", "max", "-accel", "tcg,thread=multi",
                "-m", e.ramMb.toString(), "-smp", e.cores.toString(),
                "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=${File(share, FW).absolutePath}",
                "-drive", "if=pflash,format=raw,unit=1,file=${vars.absolutePath}",
                "-device", "virtio-gpu-pci,xres=${e.vmWidth},yres=${e.vmHeight}",
                "-device", "qemu-xhci", "-device", "usb-tablet", "-device", "usb-kbd", "-device", "virtio-rng-pci",
                "-serial", "file:${File(ctx.filesDir, "serial.log").absolutePath}",
                "-vnc", "127.0.0.1:1",
            )
        }
        if (e.networkEnabled) cmd += listOf("-netdev", "user,id=n0", "-device", if (x86) "e1000,netdev=n0" else "virtio-net-pci,netdev=n0")

        val ext = img.extension.lowercase()
        // система-надстройка (GSI): основа берётся из другой карточки, GSI подключается третьим диском
        val base = e.baseId?.let { bid -> Repo.load(ctx).firstOrNull { it.id == bid }?.image?.let { File(it) }?.takeIf { it.exists() } }
        if (e.baseId != null && base == null) {
            stop(); return "Сначала скачайте «LineageOS (телефон)» — он нужен как основа для этой системы."
        }
        if (ext == "iso" && base == null) {
            val data = File(ctx.filesDir, "disks/${e.id}.raw")
            if (!data.exists()) RandomAccessFile(data, "rw").use { it.setLength(e.diskGb * 1024L * 1024L * 1024L) }
            if (x86) {
                cmd += listOf(
                    "-drive", "if=none,id=hd0,format=raw,file=${data.absolutePath}", "-device", "ide-hd,drive=hd0",
                    "-drive", "if=none,id=cd0,format=raw,media=cdrom,readonly=on,file=${img.absolutePath}",
                    "-device", "ide-cd,drive=cd0,bootindex=1", "-boot", "order=d",
                )
            } else {
                cmd += listOf(
                    "-drive", "if=none,id=hd0,format=raw,file=${data.absolutePath}", "-device", "virtio-blk-pci,drive=hd0",
                    "-drive", "if=none,id=cd0,format=raw,media=cdrom,readonly=on,file=${img.absolutePath}",
                    "-device", "usb-storage,drive=cd0,bootindex=0",
                )
            }
        } else {
            // бандл: vda, vdb … — подключаем все диски по порядку как virtio-blk
            val disks = if (base != null) ImageInstaller.disksNear(base) + img else ImageInstaller.disksNear(img).ifEmpty { listOf(img) }
            disks.forEachIndexed { i, f ->
                val fmt = if (f.extension.lowercase() == "qcow2") "qcow2" else "raw"
                cmd += listOf(
                    "-drive", "if=none,id=vd$i,format=$fmt,discard=unmap,detect-zeroes=unmap,file=${f.absolutePath}",
                    "-device", "virtio-blk-pci,drive=vd$i" + if (i == 0) ",bootindex=0" else "",
                )
            }
        }

        return try {
            val pb = ProcessBuilder(cmd)
            pb.directory(ctx.filesDir)
            pb.environment()["HOME"] = ctx.filesDir.absolutePath
            pb.redirectErrorStream(true)
            pb.redirectOutput(File(ctx.filesDir, "qemu.log"))
            proc = pb.start()
            null
        } catch (ex: Exception) {
            "Не удалось запустить QEMU: ${ex.message}"
        }
    }

    fun stop() {
        val old = proc
        proc = null
        if (old != null) runCatching {
            old.destroy()
            if (!old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) {
                old.destroyForcibly()
                old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
            }
        }
    }
}
