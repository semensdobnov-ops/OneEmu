package com.oneemu.app

import android.content.Context
import android.os.Build
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipFile

/** Запускает qemu-system-aarch64 (машина "virt") — мобильную ARM64-версию Android. */
object QemuRunner {
    private var proc: Process? = null
    const val VNC_PORT = 5901
    private const val FW = "edk2-aarch64-code.fd"

    fun alive() = proc?.isAlive == true

    fun log(ctx: Context): String =
        runCatching { File(ctx.filesDir, "qemu.log").readText().takeLast(600) }.getOrDefault("")

    /** Последняя строка консоли гостя без ANSI-кодов терминала. */
    fun serialLast(ctx: Context): String = runCatching {
        val f = File(ctx.filesDir, "serial.log")
        if (!f.exists() || f.length() == 0L) return@runCatching ""
        RandomAccessFile(f, "r").use { r ->
            val n = minOf(1024L, r.length()).toInt()
            r.seek(r.length() - n)
            val b = ByteArray(n); r.readFully(b)
            val cleaned = String(b, Charsets.UTF_8)
                .replace(Regex("\u001B\[[0-9;?]*[ -/]*[@-~]"), "")
                .replace(Regex("[\u0000-\u0008\u000B-\u001F]"), " ")
            cleaned.lines()
                .map { it.trim() }
                .lastOrNull { it.length >= 3 && !it.startsWith("[") }
                ?.takeLast(70) ?: ""
        }
    }.getOrDefault("")

    private fun diag(ctx: Context): String {
        val d = File(ctx.applicationInfo.nativeLibraryDir)
        val inApk = runCatching {
            ZipFile(ctx.applicationInfo.sourceDir).use { z ->
                z.entries().asSequence().map { it.name }.filter { it.startsWith("lib/") }.joinToString("\n").ifEmpty { "нет" }
            }
        }.getOrDefault("?")
        return "\n\n[Диагностика]\nABI телефона: ${Build.SUPPORTED_ABIS.joinToString()}\n" +
            "Размер APK: ${File(ctx.applicationInfo.sourceDir).length() / 1048576} МБ\n" +
            "Библиотеки внутри APK:\n$inApk\n" +
            "Распаковано в ${d.path}: ${d.list()?.joinToString().orEmpty().ifEmpty { "ничего" }}"
    }

    private fun copyAssets(ctx: Context, path: String, dst: File) {
        val list = ctx.assets.list(path) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAssets(ctx, "$path/$it", File(dst, it)) }
        }
    }

    private fun ensureShare(ctx: Context): File {
        val dst = File(ctx.filesDir, "qemu-share")
        if (!File(dst, ".ok5").exists()) {
            dst.deleteRecursively()
            dst.mkdirs()
            copyAssets(ctx, "qemu-share", dst)
            File(dst, "README.txt").delete()
            if (File(dst, FW).exists() && File(dst, "keymaps/en-us").exists()) File(dst, ".ok5").writeText("1")
        }
        return dst
    }

    private fun resolveQemuBinary(ctx: Context): File? {
        val nativeBin = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")
        return nativeBin.takeIf { it.isFile && it.canRead() && it.canExecute() && it.length() > 1024 * 1024 }
    }

    /** Возвращает текст ошибки или null, если QEMU запущен. */
    fun start(ctx: Context, e: OsEntry): String? {
        if (e.architecture.startsWith("x86")) return "Образы Android-x86 для ПК не поддерживаются. Выберите мобильный ARM64-образ для QEMU virt."
        val bin = resolveQemuBinary(ctx)
            ?: return "Не найден исполняемый ARM64 QEMU в nativeLibraryDir. APK должен содержать arm64-v8a/libqemu.so." + diag(ctx)
        val img = e.image?.let { File(it) }
        if (img == null || !img.exists()) return "Образ системы не выбран."
        stop()
        runCatching { File(ctx.filesDir, "qemu.log").delete() }
        runCatching { File(ctx.filesDir, "serial.log").delete() }
        val share = ensureShare(ctx)
        if (!File(share, FW).exists()) return "Нет UEFI-прошивки для ARM64 (assets/qemu-share). Соберите APK через GitHub Actions."

        val cmd = mutableListOf(bin.absolutePath, "-L", share.absolutePath)
        val vars = File(ctx.filesDir, "disks/${e.id}-vars.fd")
        vars.parentFile?.mkdirs()
        if (!vars.exists()) RandomAccessFile(vars, "rw").use { it.setLength(64L * 1024 * 1024) }

        // Видеоадаптер virtio-gpu-gl/virtio-gpu-pci + ramfb fallback:
        // устраняет чёрный экран "Display output is not active" после выхода из GRUB при старте ядра Android/LineageOS.
        cmd += listOf(
            "-machine", "virt,gic-version=3,highmem=on",
            "-cpu", "max",
            "-accel", "tcg,thread=multi",
            "-m", e.ramMb.toString(),
            "-smp", e.cores.toString(),
            "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=${File(share, FW).absolutePath}",
            "-drive", "if=pflash,format=raw,unit=1,file=${vars.absolutePath}",
            "-device", "ramfb",
            "-device", "virtio-gpu-pci,xres=${e.vmWidth},yres=${e.vmHeight}",
            "-device", "qemu-xhci",
            "-device", "usb-tablet",
            "-device", "usb-kbd",
            "-device", "virtio-rng-pci",
            "-serial", "file:${File(ctx.filesDir, "serial.log").absolutePath}",
            "-display", "vnc=127.0.0.1:1",
        )
        if (e.networkEnabled) cmd += listOf("-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0")

        val ext = img.extension.lowercase()
        val base = e.baseId?.let { bid -> Repo.load(ctx).firstOrNull { it.id == bid }?.image?.let { File(it) }?.takeIf { it.exists() } }
        if (e.baseId != null && base == null) {
            stop(); return "Сначала скачайте «LineageOS (телефон)» — он нужен как основа для этой системы."
        }
        if (ext == "iso" && base == null) {
            val data = File(ctx.filesDir, "disks/${e.id}.raw")
            if (!data.exists()) RandomAccessFile(data, "rw").use { it.setLength(e.diskGb * 1024L * 1024L * 1024L) }
            cmd += listOf(
                "-drive", "if=none,id=hd0,format=raw,file=${data.absolutePath}", "-device", "virtio-blk-pci,drive=hd0",
                "-drive", "if=none,id=cd0,format=raw,media=cdrom,readonly=on,file=${img.absolutePath}",
                "-device", "usb-storage,drive=cd0,bootindex=0",
            )
        } else {
            val disks = if (base != null) ImageInstaller.disksNear(base) + img else ImageInstaller.disksNear(img).ifEmpty { listOf(img) }
            disks.forEachIndexed { i, f ->
                val fmt = if (f.extension.lowercase() == "qcow2") "qcow2" else "raw"
                cmd += listOf(
                    "-drive", "if=none,id=vd$i,format=$fmt,discard=unmap,detect-zeroes=unmap,file=${f.absolutePath}",
                    "-device", "virtio-blk-pci,drive=vd$i" + if (i == 0) ",bootindex=0" else "",
                )
            }
        }

        return try {
            val pb = ProcessBuilder(cmd)
            pb.directory(ctx.filesDir)
            pb.environment()["HOME"] = ctx.filesDir.absolutePath
            pb.redirectErrorStream(true)
            pb.redirectOutput(File(ctx.filesDir, "qemu.log"))
            proc = pb.start()
            null
        } catch (ex: Exception) {
            if (ex is java.io.IOException && ex.message.orEmpty().contains("Permission denied", true)) {
                "Android запретил запуск libqemu.so из каталога приложения."
            } else {
                "Не удалось запустить QEMU: ${ex.message}"
            }
        }
    }

    fun stop() {
        val old = proc
        proc = null
        if (old != null) runCatching {
            old.destroy()
            if (!old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) {
                old.destroyForcibly()
                old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
            }
        }
    }
}
