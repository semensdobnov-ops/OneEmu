package com.oneemu.app

import android.content.Context
import android.os.Build
import java.io.File
import java.util.zip.ZipFile
import java.io.RandomAccessFile

object QemuRunner {
    private var proc: Process? = null
    const val VNC_PORT = 5901

    fun alive() = proc?.isAlive == true

    fun log(ctx: Context): String =
        runCatching { File(ctx.filesDir, "qemu.log").readText().takeLast(600) }.getOrDefault("")

    private fun diag(ctx: Context): String {
        val d = File(ctx.applicationInfo.nativeLibraryDir)
        val inApk = runCatching {
            ZipFile(ctx.applicationInfo.sourceDir).use { z ->
                z.entries().asSequence().map { it.name }.filter { it.startsWith("lib/") }.joinToString("\n").ifEmpty { "нет" }
            }
        }.getOrDefault("?")
        return "\n\n[Диагностика]\nABI телефона: ${Build.SUPPORTED_ABIS.joinToString()}\n" +
            "Размер APK: ${File(ctx.applicationInfo.sourceDir).length() / 1048576} МБ\n" +
            "Библиотеки внутри APK:\n$inApk\n" +
            "Распаковано в ${d.path}: ${d.list()?.joinToString().orEmpty().ifEmpty { "ничего" }}"
    }

    /** Рекурсивно копирует папку из assets (раньше подпапки, в т.ч. keymaps, терялись). */
    private fun copyAssets(ctx: Context, path: String, dst: File) {
        val list = ctx.assets.list(path) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAssets(ctx, "$path/$it", File(dst, it)) }
        }
    }

    private fun ensureShare(ctx: Context): File {
        val dst = File(ctx.filesDir, "qemu-share")
        if (!File(dst, ".ok2").exists()) {
            dst.mkdirs()
            copyAssets(ctx, "qemu-share", dst)
            File(dst, "README.txt").delete()
            if (File(dst, "bios-256k.bin").exists() && File(dst, "keymaps/en-us").exists()) File(dst, ".ok2").writeText("1")
        }
        return dst
    }

    /** Возвращает текст ошибки или null, если QEMU запущен. */
    fun start(ctx: Context, e: OsEntry): String? {
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")
        if (!bin.exists()) return "Не найден libqemu.so." + diag(ctx)
        val img = e.image?.let { File(it) }
        if (img == null || !img.exists()) return "Образ системы не выбран."
        stop()
        val share = ensureShare(ctx)
        if (!File(share, "bios-256k.bin").exists()) return "Нет BIOS-файлов QEMU (assets/qemu-share). Соберите APK через GitHub Actions — он добавит их автоматически."

        val cmd = mutableListOf(
            bin.absolutePath, "-L", share.absolutePath,
            "-machine", "pc", "-cpu", "max", "-accel", "tcg,thread=multi",
            "-m", e.ramMb.toString(), "-smp", e.cores.toString(),
            "-vga", "std",
            "-device", "qemu-xhci", "-device", "usb-tablet", "-device", "usb-kbd",
            "-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0",
            "-vnc", "127.0.0.1:1",
            "-display", "none",
        )
        val ext = img.extension.lowercase()
        if (ext == "iso") {
            val data = File(ctx.filesDir, "disks/${e.id}.raw")
            data.parentFile?.mkdirs()
            if (!data.exists()) RandomAccessFile(data, "rw").use { it.setLength(e.diskGb * 1024L * 1024L * 1024L) }
            cmd += listOf(
                "-drive", "file=${data.absolutePath},format=raw,index=0,media=disk",
                "-drive", "file=${img.absolutePath},format=raw,index=2,media=cdrom,readonly=on",
                "-boot", "d",
            )
        } else {
            val fmt = if (ext == "qcow2") "qcow2" else "raw"
            cmd += listOf("-drive", "file=${img.absolutePath},format=$fmt")
        }

        return try {
            val pb = ProcessBuilder(cmd)
            pb.directory(ctx.filesDir)
            pb.environment()["HOME"] = ctx.filesDir.absolutePath
            pb.redirectErrorStream(true)
            pb.redirectOutput(File(ctx.filesDir, "qemu.log"))
            proc = pb.start()
            null
        } catch (ex: Exception) {
            "Не удалось запустить QEMU: ${ex.message}"
        }
    }

    fun stop() {
        proc?.destroy(); proc = null
    }
}
