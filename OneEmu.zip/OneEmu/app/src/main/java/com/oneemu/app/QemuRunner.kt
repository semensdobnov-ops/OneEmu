package com.oneemu.app

import android.content.Context
import android.os.Build
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipFile

enum class VmBootStage(val title: String, val progress: Float) {
    PREPARING("Подготовка виртуального окружения…", 0.15f),
    FIRMWARE("Инициализация системного загрузчика…", 0.35f),
    KERNEL("Запуск ядра Android…", 0.60f),
    SURFACE("Подключение графического дисплея…", 0.85f),
    READY("Система готова", 1.0f),
}

object QemuRunner {
    private var proc: Process? = null
    const val VNC_PORT = 5901
    private const val FW = "edk2-aarch64-code.fd"

    fun alive(): Boolean = proc?.isAlive == true

    fun log(ctx: Context): String =
        runCatching { File(ctx.filesDir, "qemu.log").readText().takeLast(1200) }.getOrDefault("")

    fun detectStage(ctx: Context, elapsedSec: Int, hasFrame: Boolean): VmBootStage {
        if (hasFrame) return VmBootStage.READY
        val serial = runCatching {
            val f = File(ctx.filesDir, "serial.log")
            if (!f.exists() || f.length() == 0L) "" else f.readText().takeLast(2048)
        }.getOrDefault("")

        return when {
            serial.contains("init", ignoreCase = true) || serial.contains("android", ignoreCase = true) || elapsedSec >= 14 ->
                VmBootStage.SURFACE
            serial.contains("Linux version", ignoreCase = true) || elapsedSec >= 7 ->
                VmBootStage.KERNEL
            elapsedSec >= 2 ->
                VmBootStage.FIRMWARE
            else ->
                VmBootStage.PREPARING
        }
    }

    private fun diag(ctx: Context): String {
        val d = File(ctx.applicationInfo.nativeLibraryDir)
        val inApk = runCatching {
            ZipFile(ctx.applicationInfo.sourceDir).use { z ->
                z.entries().asSequence().map { it.name }.filter { it.startsWith("lib/") }
                    .joinToString("\n").ifEmpty { "нет" }
            }
        }.getOrDefault("?")
        return "\n\n[Диагностика]\nABI: ${Build.SUPPORTED_ABIS.joinToString()}\n" +
            "Библиотеки в APK:\n$inApk\n" +
            "nativeLibraryDir (${d.path}): ${d.list()?.joinToString().orEmpty().ifEmpty { "пусто" }}"
    }

    private fun copyAssets(ctx: Context, path: String, dst: File) {
        val list = ctx.assets.list(path) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAssets(ctx, "$path/$it", File(dst, it)) }
        }
    }

    private fun ensureShare(ctx: Context): File {
        val dst = File(ctx.filesDir, "qemu-share")
        if (!File(dst, ".ok6").exists()) {
            dst.deleteRecursively()
            dst.mkdirs()
            copyAssets(ctx, "qemu-share", dst)
            File(dst, "README.txt").delete()
            if (File(dst, FW).exists()) File(dst, ".ok6").writeText("1")
        }
        return dst
    }

    private fun resolveQemuBinary(ctx: Context): File? {
        val nativeBin = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")
        return nativeBin.takeIf { it.isFile && it.canRead() && it.canExecute() && it.length() > 1024 * 1024 }
    }

    fun start(ctx: Context, e: OsEntry): String? {
        if (e.architecture.startsWith("x86")) {
            return "Образы x86 не поддерживаются. Используйте мобильный ARM64-образ."
        }
        val bin = resolveQemuBinary(ctx)
            ?: return "Не найден исполняемый модуль libqemu.so." + diag(ctx)
        val img = e.image?.let { File(it) }
        if (img == null || !img.exists()) return "Образ виртуальной системы не установлен."

        stop()
        runCatching { File(ctx.filesDir, "qemu.log").delete() }
        runCatching { File(ctx.filesDir, "serial.log").delete() }

        val share = ensureShare(ctx)
        val fwFile = File(share, FW)
        if (!fwFile.exists()) return "Отсутствует прошивка загрузчика ARM64 ($FW)."

        val vars = File(ctx.filesDir, "disks/${e.id}-vars.fd")
        vars.parentFile?.mkdirs()
        if (!vars.exists()) RandomAccessFile(vars, "rw").use { it.setLength(64L * 1024 * 1024) }

        val sharedDir = File(ctx.filesDir, "shared/${e.id}").apply { mkdirs() }

        val cmd = mutableListOf(
            bin.absolutePath,
            "-L", share.absolutePath,
            // Параметры как в официальной команде jqssun/android-lineage-qemu для TCG.
            // pauth-impdef=on критичен: без него Pointer Authentication считается медленным
            // алгоритмом QARMA, и Android 14+ грузится в разы дольше (часы вместо минут).
            "-machine", "virt",
            "-cpu", "max,pauth-impdef=on",
            "-accel", "tcg,tb-size=1024,thread=multi",
            "-m", e.ramMb.toString(),
            "-smp", e.cores.toString(),
            "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=${fwFile.absolutePath}",
            "-drive", "if=pflash,format=raw,unit=1,file=${vars.absolutePath}",
            "-device", "virtio-gpu-pci,xres=${e.vmWidth},yres=${e.vmHeight}",
            "-device", "qemu-xhci",
            "-device", "usb-tablet",
            "-device", "usb-kbd",
            "-device", "virtio-serial",
            "-device", "virtio-rng-pci",
            "-serial", "file:${File(ctx.filesDir, "serial.log").absolutePath}",
            "-display", "vnc=127.0.0.1:1",
            "-monitor", "none",
        )

        if (e.networkEnabled) {
            cmd += listOf("-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0")
        }

        val ext = img.extension.lowercase()
        val base = e.baseId?.let { bid ->
            Repo.load(ctx).firstOrNull { it.id == bid }?.image?.let { File(it) }?.takeIf { it.exists() }
        }
        if (e.baseId != null && base == null) {
            stop()
            return "Для запуска этой системы сначала установите базовый образ (LineageOS ARM64)."
        }

        if (ext == "iso" && base == null) {
            val data = File(ctx.filesDir, "disks/${e.id}.raw")
            if (!data.exists()) RandomAccessFile(data, "rw").use { it.setLength(e.diskGb * 1024L * 1024L * 1024L) }
            cmd += listOf(
                "-drive", "if=none,id=hd0,format=raw,file=${data.absolutePath}",
                "-device", "virtio-blk-pci,drive=hd0",
                "-drive", "if=none,id=cd0,format=raw,media=cdrom,readonly=on,file=${img.absolutePath}",
                "-device", "usb-storage,drive=cd0,bootindex=0",
            )
        } else {
            val disks = if (base != null) {
                ImageInstaller.disksNear(base) + img
            } else {
                ImageInstaller.disksNear(img).ifEmpty { listOf(img) }
            }
            disks.forEachIndexed { i, f ->
                val fmt = if (f.extension.lowercase() == "qcow2") "qcow2" else "raw"
                cmd += listOf(
                    "-drive", "if=none,id=vd$i,format=$fmt,discard=unmap,detect-zeroes=unmap,file=${f.absolutePath}",
                    "-device", "virtio-blk-pci,drive=vd$i" + if (i == 0) ",bootindex=0" else "",
                )
            }
        }

        return try {
            val pb = ProcessBuilder(cmd)
            pb.directory(ctx.filesDir)
            pb.environment()["HOME"] = ctx.filesDir.absolutePath
            pb.environment()["ONEEMU_SHARED"] = sharedDir.absolutePath
            pb.redirectErrorStream(true)
            pb.redirectOutput(File(ctx.filesDir, "qemu.log"))
            proc = pb.start()
            null
        } catch (ex: Exception) {
            if (ex is java.io.IOException && ex.message.orEmpty().contains("Permission denied", true)) {
                "Android заблокировал запуск libqemu.so."
            } else {
                "Ошибка запуска виртуальной системы: ${ex.message}"
            }
        }
    }

    fun stop() {
        val old = proc
        proc = null
        if (old != null) {
            runCatching {
                old.destroy()
                if (!old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) {
                    old.destroyForcibly()
                    old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
                }
            }
        }
    }
}
