package com.oneemu.app

import android.content.Context
import android.os.Build
import java.io.File
import java.io.RandomAccessFile
import java.util.zip.ZipFile

/** Запускает qemu-system-aarch64 (машина "virt") — то есть мобильную ARM64-версию Android, а не ПК-версию. */
object QemuRunner {
    private var proc: Process? = null
    /** Порты выбираются свободные при каждом запуске — старый процесс или другое приложение не мешают. */
    @Volatile var vncPort = 5901
        private set
    @Volatile private var qmpPort = 4444
    /** true, если систему выключил сам пользователь (а не QEMU упал). */
    @Volatile var userStopped = false
        private set
    private const val FW = "edk2-aarch64-code.fd"

    private fun freePort(from: Int): Int {
        val lo = java.net.InetAddress.getByName("127.0.0.1")
        for (p in from until from + 90) {
            try { java.net.ServerSocket(p, 1, lo).close(); return p } catch (_: Exception) { }
        }
        return from
    }

    /** Не даём системе Android убить телефон по памяти: берём не больше ~60% ОЗУ устройства. */
    private fun safeRamMb(ctx: Context, wanted: Int): Int {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val cap = ((mi.totalMem / 1048576L) * 6 / 10).toInt() / 256 * 256
        return minOf(wanted, cap.coerceAtLeast(1024))
    }

    /** Команда управления через QMP (например system_powerdown — как нажатие кнопки питания). */
    private fun qmp(command: String): Boolean = runCatching {
        java.net.Socket().use { s ->
            s.connect(java.net.InetSocketAddress("127.0.0.1", qmpPort), 1000)
            s.soTimeout = 1500
            val r = s.getInputStream().bufferedReader()
            val w = s.getOutputStream()
            r.readLine()
            w.write("{\"execute\":\"qmp_capabilities\"}\n".toByteArray()); w.flush(); r.readLine()
            w.write("{\"execute\":\"$command\"}\n".toByteArray()); w.flush(); r.readLine()
            true
        }
    }.getOrDefault(false)

    /** x86 — это Android-x86 (4.4–9.0): они идут под qemu-system-x86_64. Остальное — ARM64. */
    fun isX86(e: OsEntry): Boolean =
        e.arch == "x86" || (e.custom && e.image?.substringAfterLast('/')?.lowercase()?.let {
            it.endsWith(".iso") && (it.contains("x86") || it.contains("amd64") || it.contains("i386"))
        } == true)

    fun alive() = proc?.isAlive == true

    fun log(ctx: Context): String =
        runCatching { File(ctx.filesDir, "qemu.log").readText().takeLast(600) }.getOrDefault("")

    /** Последняя строка консоли гостя (если система пишет в serial). */
    fun serialLast(ctx: Context): String = runCatching {
        val f = File(ctx.filesDir, "serial.log")
        RandomAccessFile(f, "r").use { r ->
            val n = minOf(400L, r.length()).toInt()
            r.seek(r.length() - n)
            val b = ByteArray(n); r.readFully(b)
            String(b, Charsets.UTF_8).lines().map { it.trim() }.lastOrNull { it.isNotEmpty() }?.takeLast(90) ?: ""
        }
    }.getOrDefault("")

    private fun diag(ctx: Context): String {
        val d = File(ctx.applicationInfo.nativeLibraryDir)
        val inApk = runCatching {
            ZipFile(ctx.applicationInfo.sourceDir).use { z ->
                z.entries().asSequence().map { it.name }.filter { it.startsWith("lib/") }.joinToString("\n").ifEmpty { "нет" }
            }
        }.getOrDefault("?")
        return "\n\n[Диагностика]\nABI телефона: ${Build.SUPPORTED_ABIS.joinToString()}\n" +
            "Размер APK: ${File(ctx.applicationInfo.sourceDir).length() / 1048576} МБ\n" +
            "Библиотеки внутри APK:\n$inApk\n" +
            "Распаковано в ${d.path}: ${d.list()?.joinToString().orEmpty().ifEmpty { "ничего" }}"
    }

    /** Рекурсивно копирует папку из assets. */
    private fun copyAssets(ctx: Context, path: String, dst: File) {
        val list = ctx.assets.list(path) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAssets(ctx, "$path/$it", File(dst, it)) }
        }
    }

    private fun ensureShare(ctx: Context): File {
        val dst = File(ctx.filesDir, "qemu-share")
        if (!File(dst, ".ok5").exists()) {
            dst.deleteRecursively()
            dst.mkdirs()
            copyAssets(ctx, "qemu-share", dst)
            File(dst, "README.txt").delete()
            if (File(dst, FW).exists() && File(dst, "keymaps/en-us").exists()) File(dst, ".ok5").writeText("1")
        }
        return dst
    }

    /** Возвращает текст ошибки или null, если QEMU запущен. */
    fun start(ctx: Context, e: OsEntry): String? {
        val x86 = isX86(e)
        val binName = if (x86) "libqemu_x86.so" else "libqemu.so"
        val bin = File(ctx.applicationInfo.nativeLibraryDir, binName)
        if (!bin.exists()) return "Не найден $binName." + diag(ctx)
        val img = e.image?.let { File(it) }
        if (img == null || !img.exists()) return "Образ системы не выбран."
        stop()
        userStopped = false
        vncPort = freePort(5901)
        qmpPort = freePort(4444)
        // Не показываем хвост предыдущего запуска: иначе диагностика может ввести в заблуждение.
        runCatching { File(ctx.filesDir, "qemu.log").delete() }
        runCatching { File(ctx.filesDir, "serial.log").delete() }
        val share = ensureShare(ctx)
        if (x86) return startX86(ctx, e, img, bin, share)
        if (!File(share, FW).exists()) return "Нет UEFI-прошивки для ARM64 (assets/qemu-share). Соберите APK через GitHub Actions — он добавит её автоматически."

        // переменные UEFI (нужны для загрузки), создаются один раз на систему
        val vars = File(ctx.filesDir, "disks/${e.id}-vars.fd")
        vars.parentFile?.mkdirs()
        if (!vars.exists()) RandomAccessFile(vars, "rw").use { it.setLength(64L * 1024 * 1024) }

        val cmd = mutableListOf(
            bin.absolutePath, "-L", share.absolutePath,
            "-machine", "virt,gic-version=3",
            // pauth-impdef=on сильно ускоряет TCG; tb-size — большой кэш трансляции, система грузится заметно быстрее
            "-cpu", "max,pauth-impdef=on", "-accel", "tcg,thread=multi,tb-size=256",
            "-m", safeRamMb(ctx, e.ramMb).toString(),
            "-smp", e.cores.coerceIn(1, Runtime.getRuntime().availableProcessors().coerceAtLeast(1)).toString(),
            "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=${File(share, FW).absolutePath}",
            "-drive", "if=pflash,format=raw,unit=1,file=${vars.absolutePath}",
            // вертикальный мобильный экран (соотношение сторон смартфона 9:20, 720x1600)
            "-device", "virtio-gpu-pci,xres=${e.vmWidth},yres=${e.vmHeight}",
            "-device", "qemu-xhci", "-device", "usb-tablet", "-device", "usb-kbd",
            "-device", "virtio-rng-pci",
            "-serial", "file:${File(ctx.filesDir, "serial.log").absolutePath}",
            // -vnc — документированный shorthand для активного backend -display vnc=...
            // Не заменять на -display none: это полностью отключает передачу изображения.
            "-vnc", "127.0.0.1:${vncPort - 5900}",
            // управление «кнопкой питания» — для чистого выключения гостя
            "-qmp", "tcp:127.0.0.1:$qmpPort,server=on,wait=off",
            "-name", "OneEmu-${e.id}",
        )

        if (e.networkEnabled) cmd += listOf("-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0")

        val ext = img.extension.lowercase()
        // система-надстройка (GSI): основа берётся из другой карточки, GSI подключается третьим диском
        val base = e.baseId?.let { bid -> Repo.load(ctx).firstOrNull { it.id == bid }?.image?.let { File(it) }?.takeIf { it.exists() } }
        if (e.baseId != null && base == null) {
            stop(); return "Сначала скачайте «LineageOS (телефон)» — он нужен как основа для этой системы."
        }
        if (ext == "iso" && base == null) {
            val data = File(ctx.filesDir, "disks/${e.id}.raw")
            if (!data.exists()) RandomAccessFile(data, "rw").use { it.setLength(e.diskGb * 1024L * 1024L * 1024L) }
            cmd += listOf(
                "-drive", "if=none,id=hd0,format=raw,file=${data.absolutePath}", "-device", "virtio-blk-pci,drive=hd0",
                "-drive", "if=none,id=cd0,format=raw,media=cdrom,readonly=on,file=${img.absolutePath}",
                "-device", "usb-storage,drive=cd0,bootindex=0",
            )
        } else {
            // бандл: vda, vdb … — подключаем все диски по порядку как virtio-blk
            val disks = if (base != null) ImageInstaller.disksNear(base) + img else ImageInstaller.disksNear(img).ifEmpty { listOf(img) }
            disks.forEachIndexed { i, f ->
                val fmt = if (f.extension.lowercase() == "qcow2") "qcow2" else "raw"
                cmd += listOf(
                    "-drive", "if=none,id=vd$i,format=$fmt,discard=unmap,detect-zeroes=unmap,file=${f.absolutePath}",
                    "-device", "virtio-blk-pci,drive=vd$i" + if (i == 0) ",bootindex=0" else "",
                )
            }
        }

        return launch(ctx, cmd)
    }

    private fun launch(ctx: Context, cmd: List<String>): String? = try {
        val pb = ProcessBuilder(cmd)
        pb.directory(ctx.filesDir)
        pb.environment()["HOME"] = ctx.filesDir.absolutePath
        pb.redirectErrorStream(true)
        pb.redirectOutput(File(ctx.filesDir, "qemu.log"))
        proc = pb.start()
        null
    } catch (ex: Exception) {
        "Не удалось запустить QEMU: ${ex.message}"
    }

    /**
     * Android-x86 (4.4 … 9.0), ПК-машина "pc" + SeaBIOS.
     * Ядро и initrd достаются из ISO и грузятся напрямую с параметрами, при которых картинка идёт
     * программно (без видеоускорения, которого на телефоне нет). Если из ISO их достать не вышло —
     * грузимся с «диска» как обычный компьютер.
     */
    private fun startX86(ctx: Context, e: OsEntry, img: File, bin: File, share: File): String? {
        if (!File(share, "bios-256k.bin").exists()) return "Нет BIOS для x86 (assets/qemu-share). Соберите APK через GitHub Actions — он добавит его автоматически."
        val data = File(ctx.filesDir, "disks/${e.id}.raw")
        data.parentFile?.mkdirs()
        if (!data.exists()) RandomAccessFile(data, "rw").use { it.setLength(e.diskGb * 1024L * 1024L * 1024L) }

        val boot = File(ctx.filesDir, "disks/${e.id}-boot")
        val kernel = File(boot, "kernel"); val initrd = File(boot, "initrd.img"); val stamp = File(boot, ".stamp")
        val sig = "${img.length()}-${img.lastModified()}"
        val direct = (stamp.takeIf { it.exists() }?.readText() == sig && kernel.exists() && initrd.exists()) ||
            IsoReader.extractRoot(img, mapOf("kernel" to kernel, "initrd.img" to initrd)).also { ok ->
                if (ok) stamp.writeText(sig) else boot.deleteRecursively()
            }

        val cmd = mutableListOf(
            bin.absolutePath, "-L", share.absolutePath,
            "-machine", "pc",
            // x86 на ARM-телефоне: многопоточный TCG тут небезопасен, поэтому одно ядро и single-thread
            "-cpu", "max", "-accel", "tcg,thread=single,tb-size=256",
            "-m", safeRamMb(ctx, e.ramMb).toString(), "-smp", "1",
            "-vga", "std",
            "-usb", "-device", "usb-tablet", "-device", "usb-kbd",
            "-drive", "if=ide,index=0,media=disk,format=raw,file=${data.absolutePath}",
            "-drive", "if=ide,index=2,media=cdrom,readonly=on,format=raw,file=${img.absolutePath}",
            "-serial", "file:${File(ctx.filesDir, "serial.log").absolutePath}",
            "-vnc", "127.0.0.1:${vncPort - 5900}",
            "-qmp", "tcp:127.0.0.1:$qmpPort,server=on,wait=off",
            "-name", "OneEmu-${e.id}",
        )
        if (e.networkEnabled) cmd += listOf("-netdev", "user,id=n0", "-device", "e1000,netdev=n0,romfile=")
        if (direct) {
            cmd += listOf(
                "-kernel", kernel.absolutePath, "-initrd", initrd.absolutePath,
                "-append", "root=/dev/ram0 androidboot.selinux=permissive vga=791 nomodeset HWACCEL=0 quiet",
            )
        } else {
            cmd += listOf("-boot", "order=d")
        }
        return launch(ctx, cmd)
    }

    /** Как кнопка питания: просим гостя выключиться сам (ACPI), ждём немного, затем останавливаем. */
    fun shutdown(graceful: Boolean) {
        val p = proc
        userStopped = true
        if (graceful && p != null && p.isAlive && qmp("system_powerdown")) {
            runCatching { p.waitFor(5, java.util.concurrent.TimeUnit.SECONDS) }
        }
        stop()
    }

    fun stop() {
        val old = proc
        proc = null
        if (old != null) runCatching {
            old.destroy()
            if (!old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) {
                old.destroyForcibly()
                old.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
            }
        }
    }
}
