package com.oneemu.app

import android.content.Context
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

data class OsEntry(
    val id: String,
    val name: String,
    val subtitle: String,
    val c1: Long,
    val c2: Long,
    val image: String? = null,
    val ramMb: Int = 2048,
    val cores: Int = 2,
    val diskGb: Int = 16,
    val custom: Boolean = false,
    val downloadUrl: String? = null,
    val sizeMb: Int = 0,
    val siteUrl: String? = null,
    val howTo: String = "",
)

object Repo {
    private val defaults = listOf(
        OsEntry(
            "x86", "Android-x86 9.0", "Лёгкая и совместимая (Android 9)", 0xFF3B5BDB, 0xFF141B4D,
            downloadUrl = "https://sourceforge.net/projects/android-x86/files/Release%209.0/android-x86_64-9.0-r2.iso/download",
            sizeMb = 921,
            siteUrl = "https://www.android-x86.org/download",
            howTo = "Откройте сайт, нажмите Download и выберите Android-x86 9.0-r2 → «64-bit ISO» (файл android-x86_64-9.0-r2.iso, около 921 МБ). Версию 32-bit не берите.\n\nКогда файл скачается, вернитесь в OneEmu, нажмите «Свой файл» и выберите его в папке «Загрузки».",
        ),
        OsEntry(
            "bliss", "Bliss OS 16", "Android 13 с рабочим столом", 0xFF7B3FE4, 0xFF2A1458,
            downloadUrl = "https://sourceforge.net/projects/blissos-x86/files/Official/BlissOS16/Gapps/Generic/Bliss-v16.9.7-x86_64-OFFICIAL-gapps-20241011.iso/download",
            sizeMb = 1800,
            siteUrl = "https://sourceforge.net/projects/blissos-x86/files/Official/BlissOS16/Gapps/Generic/",
            howTo = "Откройте папку и скачайте файл Bliss-v16.9.7-x86_64-OFFICIAL-gapps-….iso (около 1,8 ГБ). Нужен именно x86_64 и расширение .iso; файлы .vdi и .vmdk не подходят.\n\nКогда файл скачается, вернитесь в OneEmu, нажмите «Свой файл» и выберите его в папке «Загрузки».",
        ),
        OsEntry(
            "zenith", "Bliss OS Zenith", "Android 13, оптимизирован для игр", 0xFF0F9D8A, 0xFF053B35,
            downloadUrl = "https://sourceforge.net/projects/blissos-x86/files/Official/BlissOSZenith/Gapps/Generic/Bliss-Zenith-v16.9.6-x86_64-OFFICIAL-gapps-20240715.iso/download",
            sizeMb = 1900,
            siteUrl = "https://sourceforge.net/projects/blissos-x86/files/Official/BlissOSZenith/Gapps/Generic/",
            howTo = "Откройте папку и скачайте Bliss-Zenith-v16.9.6-x86_64-OFFICIAL-gapps-….iso (около 1,9 ГБ). Нужен x86_64 и расширение .iso.\n\nКогда файл скачается, вернитесь в OneEmu, нажмите «Свой файл» и выберите его в папке «Загрузки».",
        ),
        OsEntry(
            "aosp", "Android (AOSP)", "Чистый Android x86_64", 0xFF1B8F5A, 0xFF0B3D2E,
            siteUrl = "https://ci.android.com",
            howTo = "У Google нет готового установочного образа AOSP для обычной x86-виртуалки, поэтому прямой кнопки нет. Если хотите именно AOSP: на сайте выберите ветку aosp-main, сборку с x86_64 в названии и тип userdebug, откройте Artifacts и скачайте архив с образами (.zip). Приложение само достанет из него образ. Загрузится ли он в эмуляторе, не гарантирую. Самый надёжный вариант — Android-x86 в первой карточке.\n\nКогда файл скачается, вернитесь в OneEmu, нажмите «Свой файл» и выберите его в папке «Загрузки».",
        ),
        OsEntry(
            "lineage", "LineageOS", "Открытая сборка с кастомизацией", 0xFF167C80, 0xFF0A2F3A,
            siteUrl = "https://www.google.com/search?q=LineageOS+x86_64+iso+android-generic",
            howTo = "Официальный LineageOS собирается только для телефонов (ARM) и в эмуляторе x86 не запустится, поэтому прямой кнопки нет. Нужна неофициальная сборка для ПК: в поиске найдите «LineageOS x86_64 iso» (например, проект Android-Generic). Берите файл .iso, 64-bit, версия 18.1 или новее.\n\nКогда файл скачается, вернитесь в OneEmu, нажмите «Свой файл» и выберите его в папке «Загрузки».",
        ),
    )

    private fun goodImage(p: String?, e: OsEntry): String? {
        if (p == null) return null
        val f = File(p)
        if (!f.exists()) return null
        // битая загрузка (вместо образа скачалась веб-страница) — сбрасываем
        if (e.downloadUrl != null && f.length() < 50L * 1048576) { f.delete(); return null }
        return p
    }

    fun load(ctx: Context): List<OsEntry> {
        val sp = ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE)
        val raw = sp.getString("items", null) ?: return defaults
        val arr = JSONArray(raw)
        val saved = (0 until arr.length()).map { arr.getJSONObject(it) }
        val byId = saved.associateBy { it.getString("id") }
        val base = defaults.map { d ->
            val o = byId[d.id] ?: return@map d
            d.copy(
                image = goodImage(if (o.isNull("image")) null else o.getString("image"), d),
                ramMb = o.getInt("ram"), cores = o.getInt("cores"), diskGb = o.getInt("disk"),
            )
        }
        val custom = saved.filter { it.getBoolean("custom") }.map { o ->
            OsEntry(
                o.getString("id"), o.getString("name"), o.getString("subtitle"),
                o.getLong("c1"), o.getLong("c2"),
                if (o.isNull("image")) null else o.getString("image"),
                o.getInt("ram"), o.getInt("cores"), o.getInt("disk"), true,
            )
        }
        return base + custom
    }

    /** Прописывает путь к скачанному образу (вызывается из сервиса, когда UI может быть закрыт). */
    @Synchronized
    fun setImage(ctx: Context, id: String, path: String) {
        save(ctx, load(ctx).map { if (it.id == id) it.copy(image = path) else it })
    }

    @Synchronized
    fun save(ctx: Context, list: List<OsEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("subtitle", it.subtitle)
                put("c1", it.c1); put("c2", it.c2); put("image", it.image ?: JSONObject.NULL)
                put("ram", it.ramMb); put("cores", it.cores); put("disk", it.diskGb); put("custom", it.custom)
            })
        }
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }
}
