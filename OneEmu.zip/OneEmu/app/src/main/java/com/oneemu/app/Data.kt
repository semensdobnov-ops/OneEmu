package com.oneemu.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class OsEntry(
    val id: String,
    val name: String,
    val subtitle: String,
    val c1: Long,
    val c2: Long,
    val image: String? = null,
    val ramMb: Int = 2048,
    val cores: Int = 2,
    val diskGb: Int = 16,
    val custom: Boolean = false,
)

object Repo {
    private val defaults = listOf(
        OsEntry("aosp", "Android (AOSP)", "Чистый Android x86_64", 0xFF1B8F5A, 0xFF0B3D2E),
        OsEntry("lineage", "LineageOS", "Открытая сборка с кастомизацией", 0xFF167C80, 0xFF0A2F3A),
        OsEntry("x86", "Android-x86", "Классика для ПК и виртуальных машин", 0xFF3B5BDB, 0xFF141B4D),
        OsEntry("bliss", "Bliss OS", "Android с рабочим столом", 0xFF7B3FE4, 0xFF2A1458),
        OsEntry("prime", "PrimeOS", "Android для игр", 0xFFE8590C, 0xFF4A1D07),
    )

    fun load(ctx: Context): List<OsEntry> {
        val sp = ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE)
        val raw = sp.getString("items", null) ?: return defaults
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            OsEntry(
                o.getString("id"), o.getString("name"), o.getString("subtitle"),
                o.getLong("c1"), o.getLong("c2"),
                if (o.isNull("image")) null else o.getString("image"),
                o.getInt("ram"), o.getInt("cores"), o.getInt("disk"), o.getBoolean("custom"),
            )
        }
    }

    fun save(ctx: Context, list: List<OsEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("subtitle", it.subtitle)
                put("c1", it.c1); put("c2", it.c2); put("image", it.image ?: JSONObject.NULL)
                put("ram", it.ramMb); put("cores", it.cores); put("disk", it.diskGb); put("custom", it.custom)
            })
        }
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }
}
