package com.oneemu.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class OsEntry(
    val id: String,
    val name: String,
    val subtitle: String,
    val c1: Long,
    val c2: Long,
    val image: String? = null,
    val ramMb: Int = 2048,
    val cores: Int = 2,
    val diskGb: Int = 16,
    val custom: Boolean = false,
    val downloadUrl: String? = null,
    val sizeMb: Int = 0,
)

object Repo {
    private val defaults = listOf(
        OsEntry("aosp", "Android (AOSP)", "Чистый Android x86_64", 0xFF1B8F5A, 0xFF0B3D2E),
        OsEntry("lineage", "LineageOS", "Открытая сборка с кастомизацией", 0xFF167C80, 0xFF0A2F3A),
        OsEntry(
            "x86", "Android-x86 9.0", "Лёгкая и совместимая (Android 9)", 0xFF3B5BDB, 0xFF141B4D,
            downloadUrl = "https://downloads.sourceforge.net/project/android-x86/Release%209.0/android-x86_64-9.0-r2.iso",
            sizeMb = 921,
        ),
        OsEntry(
            "bliss", "Bliss OS 16", "Android 13 с рабочим столом", 0xFF7B3FE4, 0xFF2A1458,
            downloadUrl = "https://downloads.sourceforge.net/project/blissos-x86/Official/BlissOS16/Gapps/Generic/Bliss-v16.9.7-x86_64-OFFICIAL-gapps-20241011.iso",
            sizeMb = 1800,
        ),
    )

    fun load(ctx: Context): List<OsEntry> {
        val sp = ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE)
        val raw = sp.getString("items", null) ?: return defaults
        val arr = JSONArray(raw)
        val def = defaults.associateBy { it.id }
        return (0 until arr.length()).map { arr.getJSONObject(it) }.filter { it.getString("id") != "prime" }.map { o ->
            OsEntry(
                o.getString("id"), o.getString("name"), o.getString("subtitle"),
                o.getLong("c1"), o.getLong("c2"),
                if (o.isNull("image")) null else o.getString("image"),
                o.getInt("ram"), o.getInt("cores"), o.getInt("disk"), o.getBoolean("custom"),
                def[o.getString("id")]?.downloadUrl, def[o.getString("id")]?.sizeMb ?: 0,
            )
        }
    }

    fun save(ctx: Context, list: List<OsEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("subtitle", it.subtitle)
                put("c1", it.c1); put("c2", it.c2); put("image", it.image ?: JSONObject.NULL)
                put("ram", it.ramMb); put("cores", it.cores); put("disk", it.diskGb); put("custom", it.custom)
            })
        }
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }
}
