package com.oneemu.app

import android.content.Context
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

data class OsEntry(
    val id: String,
    val name: String,
    val subtitle: String,
    val c1: Long,
    val c2: Long,
    val image: String? = null,
    val ramMb: Int = 2048,
    val cores: Int = 2,
    val diskGb: Int = 16,
    val custom: Boolean = false,
    val downloadUrl: String? = null,
    val sizeMb: Int = 0,
    val siteUrl: String? = null,
    val howTo: String = "",
    val bundle: Boolean = false,
    /** Если задано — это система-надстройка (GSI): запускается поверх диска другой системы. */
    val baseId: String? = null,
    val vmWidth: Int = 720,
    val vmHeight: Int = 1600,
    val networkEnabled: Boolean = true,
    /** Архитектура гостевой ОС: arm64 (телефонные VM) или x86 (Android-x86 ISO; QEMU x86_64 запускает и 32-, и 64-битные гости). */
    val architecture: String = "arm64",
)

object Repo {
    private val defaults = listOf(
        // Каталог OneEmu содержит только ARM64-системы для мобильной виртуальной машины.
        // Android-x86 ISO для ПК намеренно исключены: это не мобильные ARM-образы.
        OsEntry(
            "lineage", "LineageOS (телефон)", "Мобильный Android, ARM64 — как на смартфоне", 0xFF167C80, 0xFF0A2F3A,
            ramMb = 3072, cores = 4, diskGb = 16,
            // "github:" — приложение само найдёт свежий релиз и нужный файл (UTM-VM-lineage-…-virtio_arm64only.zip)
            downloadUrl = "github:jqssun/android-lineage-qemu,jqssun/android-ci",
            sizeMb = 0, bundle = true,
            siteUrl = "https://github.com/jqssun/android-lineage-qemu/releases",
            howTo = "Откройте страницу релизов и скачайте файл UTM-VM-lineage-…-virtio_arm64only.zip (это мобильная ARM64-версия для виртуальной машины QEMU).\n\nКогда файл скачается, вернитесь в OneEmu, нажмите «Свой файл» и выберите этот zip — приложение само его распакует.",
        ),
        OsEntry(
            "gsi_aosp", "Android (чистый AOSP)", "ARM64 GSI от Google — как на Pixel", 0xFF1B8F5A, 0xFF0B3D2E,
            ramMb = 3072, cores = 4, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте в OneEmu «LineageOS (телефон)» — он нужен как основа.\n2) Откройте сайт, выберите нужную версию Android (16, 17…) и скачайте образ «ARM64» (не x86_64). Google просит принять условия лицензии — это делаете вы сами.\n3) Вернитесь в OneEmu, нажмите «Свой файл» и выберите скачанный zip.\n\nGSI должна быть той же версии Android, что и основа, или новее.",
        ),
        OsEntry(
            "gsi_treble", "Android GSI (TrebleDroid)", "Свежие сборки Android для телефонов, ARM64", 0xFF0F9D8A, 0xFF053B35,
            ramMb = 3072, cores = 4, baseId = "lineage",
            siteUrl = "https://github.com/TrebleDroid/treble_experimentations/releases",
            howTo = "1) Сначала скачайте в OneEmu «LineageOS (телефон)» — он нужен как основа.\n2) Откройте страницу релизов, выберите нужную версию Android и скачайте образ для ARM64 (в названии arm64 и bgN/bvN; файл .img, .img.xz или .zip).\n3) Вернитесь в OneEmu, нажмите «Свой файл» и выберите скачанный файл — .xz и sparse-образы приложение распакует само.",
        ),
        OsEntry(
            "android_gsi_9", "Android 9.0 Pie", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFFB66D75, 0xFF48232A,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 9, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_10", "Android 10.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFF4D8E9B, 0xFF173A48,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 10, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_11", "Android 11.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFF4E9C83, 0xFF173D32,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 11, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_12", "Android 12.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFF6B82B5, 0xFF263454,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 12, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_13", "Android 13.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFF9278B7, 0xFF38294F,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 13, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_14", "Android 14.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFFB17C9B, 0xFF482B3D,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 14, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_15", "Android 15.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFF6D9EAB, 0xFF1F414A,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 15, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_16", "Android 16.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFF8B9C69, 0xFF344020,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 16, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
        OsEntry(
            "android_gsi_17", "Android 17.0", "Мобильный Android · ARM64 GSI · требуется база LineageOS", 0xFFB28A58, 0xFF4B321B,
            ramMb = 4096, cores = 4, diskGb = 20, baseId = "lineage",
            siteUrl = "https://developer.android.com/topic/generic-system-image/releases",
            howTo = "1) Сначала скачайте и установите «LineageOS (телефон)» в OneEmu.\n2) Откройте официальный каталог GSI и выберите Android 17, ARM64 (не x86).\n3) Скачайте ZIP-архив GSI, вернитесь в OneEmu и нажмите «Свой файл».\n\nВажно: GSI официально предназначены для устройств с Treble; запуск в этой QEMU-сборке зависит от совместимости конкретного образа с базовой виртуальной системой. Google публикует GSI начиная с Android 9.",
        ),
    )

    private fun goodImage(p: String?, e: OsEntry): String? {
        if (p == null) return null
        val f = File(p)
        if (!f.exists()) return null
        // битая загрузка (вместо образа скачалась веб-страница) — сбрасываем
        if (e.downloadUrl != null && f.extension.lowercase() == "iso" && f.length() < 50L * 1048576) { f.delete(); return null }
        return p
    }

    fun load(ctx: Context): List<OsEntry> {
        val sp = ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE)
        val raw = sp.getString("items", null) ?: return defaults
        val arr = JSONArray(raw)
        val saved = (0 until arr.length()).map { arr.getJSONObject(it) }
        val byId = saved.associateBy { it.getString("id") }
        val base = defaults.map { d ->
            val o = byId[d.id] ?: return@map d
            d.copy(
                image = goodImage(if (o.isNull("image")) null else o.getString("image"), d),
                ramMb = o.getInt("ram"), cores = o.getInt("cores"), diskGb = o.getInt("disk"),
                vmWidth = o.optInt("width", d.vmWidth), vmHeight = o.optInt("height", d.vmHeight),
                networkEnabled = o.optBoolean("network", d.networkEnabled),
            )
        }
        val custom = saved.filter { it.getBoolean("custom") }.map { o ->
            OsEntry(
                o.getString("id"), o.getString("name"), o.getString("subtitle"),
                o.getLong("c1"), o.getLong("c2"),
                if (o.isNull("image")) null else o.getString("image"),
                o.getInt("ram"), o.getInt("cores"), o.getInt("disk"), true,
                vmWidth = o.optInt("width", 720), vmHeight = o.optInt("height", 1600),
                networkEnabled = o.optBoolean("network", true),
            )
        }
        return base + custom
    }

    /** Прописывает путь к скачанному образу (вызывается из сервиса, когда UI может быть закрыт). */
    @Synchronized
    fun setImage(ctx: Context, id: String, path: String) {
        save(ctx, load(ctx).map { if (it.id == id) it.copy(image = path) else it })
    }

    @Synchronized
    fun save(ctx: Context, list: List<OsEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("name", it.name); put("subtitle", it.subtitle)
                put("c1", it.c1); put("c2", it.c2); put("image", it.image ?: JSONObject.NULL)
                put("ram", it.ramMb); put("cores", it.cores); put("disk", it.diskGb); put("custom", it.custom)
                put("width", it.vmWidth); put("height", it.vmHeight); put("network", it.networkEnabled)
            })
        }
        ctx.getSharedPreferences("oneemu", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
    }
}
