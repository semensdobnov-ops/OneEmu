package com.oneemu.app

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Скачивает образ прямо в приложении, без браузера. */
object Downloader {
    @Volatile var cancelled = false

    /** Возвращает путь к файлу. onProgress(скачано МБ, всего МБ или 0). */
    fun download(ctx: Context, id: String, url: String, onProgress: (Int, Int) -> Unit): File {
        cancelled = false
        val dir = File(ctx.filesDir, "images").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }
        val part = File(dir, "$id.part")
        var cur = url
        var conn: HttpURLConnection
        var hops = 0
        while (true) {
            conn = (URL(cur).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 20000; readTimeout = 30000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) OneEmu")
            }
            val code = conn.responseCode
            if (code in 301..308 && hops++ < 8) {
                cur = URL(URL(cur), conn.getHeaderField("Location")).toString(); conn.disconnect(); continue
            }
            if (code != 200) { conn.disconnect(); error("Сервер ответил $code") }
            break
        }
        val total = (conn.contentLengthLong / 1048576).toInt()
        var done = 0L
        var lastMb = -1
        conn.inputStream.use { i ->
            part.outputStream().use { o ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    if (cancelled) { part.delete(); error("Загрузка отменена") }
                    val n = i.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val mb = (done / 1048576).toInt()
                    if (mb != lastMb) { lastMb = mb; onProgress(mb, total) }
                }
            }
        }
        val f = File(dir, "$id.iso")
        part.renameTo(f)
        return f
    }
}
