package com.oneemu.app

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Скачивает образ прямо в приложении, без браузера. */
object Downloader {
    @Volatile var cancelled = false

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = false
            connectTimeout = 20000; readTimeout = 30000
            // SourceForge отдаёт прямой редирект на зеркало только не-браузерам
            setRequestProperty("User-Agent", "Wget/1.21.4")
            setRequestProperty("Accept", "*/*")
        }

    /** onProgress(скачано МБ, всего МБ или 0). expectedMb — ожидаемый размер для проверки. */
    fun download(ctx: Context, id: String, url: String, expectedMb: Int, onProgress: (Int, Int) -> Unit): File {
        cancelled = false
        val dir = File(ctx.filesDir, "images").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }
        val part = File(dir, "$id.part")

        var cur = url
        var conn: HttpURLConnection
        var hops = 0
        while (true) {
            conn = open(cur)
            val code = conn.responseCode
            if (code in 301..308) {
                val loc = conn.getHeaderField("Location") ?: error("Редирект без адреса")
                cur = URL(URL(cur), loc).toString(); conn.disconnect()
                if (++hops > 10) error("Слишком много перенаправлений")
                continue
            }
            if (code != 200) { conn.disconnect(); error("Сервер ответил $code") }
            val type = (conn.contentType ?: "").lowercase()
            if (type.startsWith("text/html")) {
                // страница-прослойка: ищем ссылку на файл внутри
                val body = conn.inputStream.use { it.readBytes().take(200_000).toByteArray().toString(Charsets.UTF_8) }
                conn.disconnect()
                val m = Regex("""(?i)url=([^"'>\s]+)""").find(body)
                    ?: Regex("""https?://[^"'\s<>]+\.iso[^"'\s<>]*""").find(body)
                val next = m?.groupValues?.last()?.replace("&amp;", "&") ?: error("Сервер вернул веб-страницу вместо файла")
                cur = URL(URL(cur), next).toString()
                if (++hops > 10) error("Не удалось получить прямую ссылку")
                continue
            }
            break
        }
        val total = (conn.contentLengthLong / 1048576).toInt()
        var done = 0L
        var lastMb = -1
        conn.inputStream.use { i ->
            part.outputStream().use { o ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    if (cancelled) { part.delete(); error("Загрузка отменена") }
                    val n = i.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val mb = (done / 1048576).toInt()
                    if (mb != lastMb) { lastMb = mb; onProgress(mb, if (total > 0) total else expectedMb) }
                }
            }
        }
        val mb = (done / 1048576).toInt()
        if (mb < maxOf(20, expectedMb / 2)) {
            part.delete()
            error("Скачалось всего $mb МБ — это не образ системы")
        }
        val f = File(dir, "$id.iso")
        part.renameTo(f)
        return f
    }
}
