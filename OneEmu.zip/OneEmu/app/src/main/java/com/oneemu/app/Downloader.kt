package com.oneemu.app

import android.content.Context
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/**
 * Скачивает образ прямо в приложении. Если сервер умеет Range, файл качается
 * в несколько параллельных потоков кусками по 4 МБ (быстрее, когда скорость
 * режется на одно соединение). Оборвавшийся кусок докачивается, при повторных
 * ошибках берётся другое зеркало. Если Range не поддерживается — один поток.
 */
object Downloader {
    private const val THREADS = 8
    private const val CHUNK = 4L * 1048576

    private fun open(url: String, range: String? = null): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = false
            connectTimeout = 20000; readTimeout = 30000
            // SourceForge отдаёт прямой редирект на зеркало только не-браузерам
            setRequestProperty("User-Agent", "Wget/1.21.4")
            setRequestProperty("Accept", "*/*")
            if (range != null) setRequestProperty("Range", range)
        }

    private class Probe(val url: String, val total: Long, val ranges: Boolean, val conn: HttpURLConnection?)

    /** Идёт по редиректам и страницам-прослойкам до реального файла. */
    private fun resolve(url: String, cancel: AtomicBoolean): Probe {
        var cur = url
        var hops = 0
        while (true) {
            if (cancel.get()) error("Загрузка отменена")
            val conn = open(cur, "bytes=0-0")
            val code = conn.responseCode
            if (code in 301..308) {
                val loc = conn.getHeaderField("Location") ?: error("Редирект без адреса")
                cur = URL(URL(cur), loc).toString(); conn.disconnect()
                if (++hops > 10) error("Слишком много перенаправлений")
                continue
            }
            if (code != 200 && code != 206) { conn.disconnect(); error("Сервер ответил $code") }
            val type = (conn.contentType ?: "").lowercase()
            if (type.startsWith("text/html")) {
                // страница-прослойка: ищем ссылку на файл внутри
                val body = conn.inputStream.use { it.readBytes().take(200_000).toByteArray().toString(Charsets.UTF_8) }
                conn.disconnect()
                val m = Regex("""(?i)url=([^"'>\s]+)""").find(body)
                    ?: Regex("""https?://[^"'\s<>]+\.iso[^"'\s<>]*""").find(body)
                val next = m?.groupValues?.last()?.replace("&amp;", "&") ?: error("Сервер вернул веб-страницу вместо файла")
                cur = URL(URL(cur), next).toString()
                if (++hops > 10) error("Не удалось получить прямую ссылку")
                continue
            }
            if (code == 206) {
                val total = conn.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull() ?: -1L
                conn.disconnect()
                return Probe(cur, total, total > 0, null)
            }
            // 200: сервер проигнорировал Range — качаем этим же соединением одним потоком
            return Probe(cur, conn.contentLengthLong, false, conn)
        }
    }

    /** onProgress(скачано байт, всего байт). Вызывается примерно 3–4 раза в секунду. */
    fun download(
        ctx: Context, id: String, url: String, expectedMb: Int,
        cancel: AtomicBoolean, onProgress: (Long, Long) -> Unit,
    ): File {
        val dir = File(ctx.filesDir, "images").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }
        val part = File(dir, "$id.part")
        try {
            onProgress(0, expectedMb * 1048576L)
            val probe = resolve(url, cancel)
            val done: Long
            if (probe.ranges) {
                parallel(url, probe, part, cancel, onProgress)
                done = probe.total
            } else {
                done = single(probe, expectedMb, part, cancel, onProgress)
            }
            val mb = (done / 1048576).toInt()
            if (mb < maxOf(20, expectedMb / 2)) error("Скачалось всего $mb МБ — это не образ системы")
            onProgress(done, done)
            val f = File(dir, "$id.iso")
            part.renameTo(f)
            return f
        } catch (e: Exception) {
            part.delete()
            throw e
        }
    }

    private fun parallel(
        url: String, probe: Probe, part: File, cancel: AtomicBoolean, onProgress: (Long, Long) -> Unit,
    ) {
        val total = probe.total
        RandomAccessFile(part, "rw").use { it.setLength(total) }
        val chunks = ((total + CHUNK - 1) / CHUNK).toInt()
        val next = AtomicInteger(0)
        val got = AtomicLong(0)
        val failure = AtomicReference<Exception?>(null)

        val workers = (0 until minOf(THREADS, chunks)).map {
            thread(isDaemon = true) {
                try {
                    RandomAccessFile(part, "rw").use { raf ->
                        var target = probe.url
                        while (failure.get() == null && !cancel.get()) {
                            val idx = next.getAndIncrement()
                            if (idx >= chunks) break
                            val start = idx * CHUNK
                            val end = minOf(total, start + CHUNK) - 1
                            var pos = start
                            var tries = 0
                            while (pos <= end) {
                                if (cancel.get() || failure.get() != null) return@use
                                try {
                                    val c = open(target, "bytes=$pos-$end")
                                    val code = c.responseCode
                                    if (code != 206) { c.disconnect(); error("Сервер ответил $code") }
                                    c.inputStream.use { i ->
                                        raf.seek(pos)
                                        val buf = ByteArray(1 shl 16)
                                        while (pos <= end) {
                                            if (cancel.get()) return@use
                                            val r = i.read(buf, 0, minOf(buf.size.toLong(), end - pos + 1).toInt())
                                            if (r < 0) break
                                            raf.write(buf, 0, r); pos += r; got.addAndGet(r.toLong())
                                        }
                                    }
                                    c.disconnect()
                                    if (pos <= end) error("Соединение оборвалось")
                                } catch (e: Exception) {
                                    if (cancel.get()) return@use
                                    if (++tries > 6) { failure.compareAndSet(null, e); return@use }
                                    Thread.sleep(1000L * tries)
                                    // возможно, другое зеркало
                                    target = runCatching { resolve(url, cancel).url }.getOrDefault(target)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    failure.compareAndSet(null, e)
                }
            }
        }
        while (workers.any { it.isAlive }) {
            Thread.sleep(250)
            onProgress(got.get(), total)
        }
        workers.forEach { it.join() }
        if (cancel.get()) error("Загрузка отменена")
        failure.get()?.let { throw it }
        if (got.get() < total) error("Файл скачан не полностью")
    }

    /** Запасной вариант: один поток. Возвращает число скачанных байт. */
    private fun single(
        probe: Probe, expectedMb: Int, part: File, cancel: AtomicBoolean, onProgress: (Long, Long) -> Unit,
    ): Long {
        var conn = probe.conn
        if (conn == null) {
            conn = open(probe.url)
            val code = conn.responseCode
            if (code != 200) { conn.disconnect(); error("Сервер ответил $code") }
        }
        val declared = conn.contentLengthLong
        val total = if (declared > 0) declared else expectedMb * 1048576L
        var done = 0L
        var lastReport = 0L
        conn.inputStream.use { i ->
            part.outputStream().use { o ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    if (cancel.get()) error("Загрузка отменена")
                    val n = i.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val now = System.currentTimeMillis()
                    if (now - lastReport >= 300) { lastReport = now; onProgress(done, maxOf(total, done)) }
                }
            }
        }
        return done
    }
}
