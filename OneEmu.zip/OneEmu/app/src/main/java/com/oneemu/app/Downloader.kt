package com.oneemu.app

import android.content.Context
import java.io.File
import org.json.JSONArray
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/**
 * Скачивает образ прямо в приложении. Если сервер умеет Range, файл качается
 * в несколько параллельных потоков кусками по 4 МБ (быстрее, когда скорость
 * режется на одно соединение). Оборвавшийся кусок докачивается, при повторных
 * ошибках берётся другое зеркало. Если Range не поддерживается — один поток.
 */
object Downloader {
    private const val THREADS = 8
    private const val CHUNK = 4L * 1048576

    private fun open(url: String, range: String? = null): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = false
            connectTimeout = 20000; readTimeout = 30000
            // SourceForge отдаёт прямой редирект на зеркало только не-браузерам
            setRequestProperty("User-Agent", "Wget/1.21.4")
            setRequestProperty("Accept", "*/*")
            if (range != null) setRequestProperty("Range", range)
        }

    private class Probe(val url: String, val total: Long, val ranges: Boolean, val conn: HttpURLConnection?)

    /** Идёт по редиректам и страницам-прослойкам до реального файла. */
    private fun resolve(url: String, cancel: AtomicBoolean): Probe {
        var cur = url
        var hops = 0
        while (true) {
            if (cancel.get()) error("Загрузка отменена")
            val conn = open(cur, "bytes=0-0")
            val code = conn.responseCode
            if (code in 301..308) {
                val loc = conn.getHeaderField("Location") ?: error("Редирект без адреса")
                cur = URL(URL(cur), loc).toString(); conn.disconnect()
                if (++hops > 10) error("Слишком много перенаправлений")
                continue
            }
            if (code != 200 && code != 206) { conn.disconnect(); error("Сервер ответил $code") }
            val type = (conn.contentType ?: "").lowercase()
            if (type.startsWith("text/html")) {
                // страница-прослойка: ищем ссылку на файл внутри
                val body = conn.inputStream.use { it.readBytes().take(200_000).toByteArray().toString(Charsets.UTF_8) }
                conn.disconnect()
                val m = Regex("""(?i)url=([^"'>\s]+)""").find(body)
                    ?: Regex("""https?://[^"'\s<>]+\.iso[^"'\s<>]*""").find(body)
                val next = m?.groupValues?.last()?.replace("&amp;", "&") ?: error("Сервер вернул веб-страницу вместо файла")
                cur = URL(URL(cur), next).toString()
                if (++hops > 10) error("Не удалось получить прямую ссылку")
                continue
            }
            if (code == 206) {
                val total = conn.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull() ?: -1L
                conn.disconnect()
                return Probe(cur, total, total > 0, null)
            }
            // 200: сервер проигнорировал Range — качаем этим же соединением одним потоком
            return Probe(cur, conn.contentLengthLong, false, conn)
        }
    }

    data class Ver(val label: String, val url: String, val sizeMb: Int)

    private val ASSET = Regex("""(?i)UTM-VM-lineage.*arm64.*\.zip""")

    /** "github:owner/repo,owner2/repo2" → список доступных версий (свежие сверху). */
    fun listReleases(spec: String): List<Ver> {
        val out = mutableListOf<Pair<String, Ver>>()
        for (repo in spec.removePrefix("github:").split(',')) {
            try {
                val c = open("https://api.github.com/repos/${repo.trim()}/releases?per_page=20")
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.instanceFollowRedirects = true
                if (c.responseCode != 200) { c.disconnect(); continue }
                val arr = JSONArray(c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) })
                c.disconnect()
                for (i in 0 until arr.length()) {
                    val r = arr.getJSONObject(i)
                    if (r.optBoolean("draft")) continue
                    val date = r.optString("published_at").take(10)
                    val assets = r.getJSONArray("assets")
                    for (j in 0 until assets.length()) {
                        val a = assets.getJSONObject(j)
                        if (!ASSET.containsMatchIn(a.getString("name"))) continue
                        val name = r.optString("name").ifBlank { r.optString("tag_name") }
                        out += date to Ver("$name · $date", a.getString("browser_download_url"), (a.optLong("size") / 1048576).toInt())
                    }
                }
            } catch (_: Exception) { }
        }
        return out.sortedByDescending { it.first }.map { it.second }.distinctBy { it.url }.take(12)
    }

    private fun resolveGithub(spec: String): String =
        listReleases(spec).firstOrNull()?.url
            ?: error("Не нашёл мобильный образ в релизах GitHub. Нажмите «С сайта» и скачайте zip вручную.")

    /** Замеряет скорость каждого сервера (1 МБ) и ставит самый быстрый первым; неотвечающие — в конец. */
    private fun rank(cands: List<String>, cancel: AtomicBoolean): List<String> {
        if (cands.size < 2) return cands
        val speed = java.util.concurrent.ConcurrentHashMap<String, Double>()
        val ts = cands.map { u ->
            thread(isDaemon = true) {
                try {
                    val p = resolve(u, cancel)
                    val t0 = System.nanoTime()
                    val c = open(p.url, "bytes=0-1048575")
                    if (c.responseCode in 200..206) {
                        var n = 0L
                        c.inputStream.use { i ->
                            val buf = ByteArray(1 shl 16)
                            while (n < 1048576) { val r = i.read(buf); if (r < 0) break; n += r }
                        }
                        speed[u] = n / ((System.nanoTime() - t0) / 1e9).coerceAtLeast(0.001)
                    }
                    c.disconnect()
                } catch (_: Exception) { }
            }
        }
        val end = System.currentTimeMillis() + 15000
        ts.forEach { it.join(maxOf(1L, end - System.currentTimeMillis())) }
        return cands.sortedByDescending { speed[it] ?: -1.0 }
    }

    private class SlowServer : Exception("Низкая скорость сервера")

    /**
     * rawUrl — одна или несколько ссылок через перевод строки (зеркала одного файла).
     * Приложение проверяет скорость всех, берёт лучший сервер и при обрыве или низкой скорости
     * переключается на следующий.
     */
    fun download(
        ctx: Context, id: String, rawUrl: String, expectedMb: Int,
        cancel: AtomicBoolean, bundle: Boolean = false, onProgress: (Long, Long) -> Unit,
    ): File {
        val dir = File(ctx.filesDir, "images").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }
        File(dir, id).deleteRecursively()
        onProgress(0, expectedMb * 1048576L)
        val cands = rawUrl.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            .map { if (it.startsWith("github:")) resolveGithub(it) else it }
        val ranked = rank(cands, cancel)
        var last: Exception? = null
        for ((i, url) in ranked.withIndex()) {
            try {
                return downloadOne(ctx, id, url, expectedMb, cancel, bundle, i < ranked.size - 1, onProgress)
            } catch (e: Exception) {
                if (cancel.get()) throw e
                last = e
            }
        }
        throw last ?: error("Нет ссылки для скачивания")
    }

    private fun downloadOne(
        ctx: Context, id: String, url: String, expectedMb: Int, cancel: AtomicBoolean,
        bundle: Boolean, canSwitch: Boolean, onProgress: (Long, Long) -> Unit,
    ): File {
        val dir = File(ctx.filesDir, "images")
        val part = File(dir, "$id.part")
        try {
            onProgress(0, expectedMb * 1048576L)
            val probe = resolve(url, cancel)
            val done: Long
            if (probe.ranges) {
                parallel(url, probe, part, cancel, canSwitch, onProgress)
                done = probe.total
            } else {
                done = single(probe, expectedMb, part, cancel, onProgress)
            }
            val mb = (done / 1048576).toInt()
            if (mb < maxOf(20, expectedMb / 2)) error("Скачалось всего $mb МБ — это не образ системы")
            onProgress(done, done)
            if (bundle) {
                val zip = File(dir, "$id.zip")
                part.renameTo(zip)
                val main = try { ImageInstaller.unpack(ctx, id, zip) } finally { zip.delete() }
                return File(main)
            }
            val f = File(dir, "$id.iso")
            part.renameTo(f)
            return f
        } catch (e: Exception) {
            part.delete()
            throw e
        }
    }

    private fun parallel(
        url: String, probe: Probe, part: File, cancel: AtomicBoolean, canSwitch: Boolean, onProgress: (Long, Long) -> Unit,
    ) {
        val total = probe.total
        val t0 = System.nanoTime()
        RandomAccessFile(part, "rw").use { it.setLength(total) }
        val chunks = ((total + CHUNK - 1) / CHUNK).toInt()
        val next = AtomicInteger(0)
        val got = AtomicLong(0)
        val failure = AtomicReference<Exception?>(null)

        val workers = (0 until minOf(THREADS, chunks)).map {
            thread(isDaemon = true) {
                try {
                    RandomAccessFile(part, "rw").use { raf ->
                        var target = probe.url
                        while (failure.get() == null && !cancel.get()) {
                            val idx = next.getAndIncrement()
                            if (idx >= chunks) break
                            val start = idx * CHUNK
                            val end = minOf(total, start + CHUNK) - 1
                            var pos = start
                            var tries = 0
                            while (pos <= end) {
                                if (cancel.get() || failure.get() != null) return@use
                                try {
                                    val c = open(target, "bytes=$pos-$end")
                                    val code = c.responseCode
                                    if (code != 206) { c.disconnect(); error("Сервер ответил $code") }
                                    c.inputStream.use { i ->
                                        raf.seek(pos)
                                        val buf = ByteArray(1 shl 16)
                                        while (pos <= end) {
                                            if (cancel.get()) return@use
                                            val r = i.read(buf, 0, minOf(buf.size.toLong(), end - pos + 1).toInt())
                                            if (r < 0) break
                                            raf.write(buf, 0, r); pos += r; got.addAndGet(r.toLong())
                                        }
                                    }
                                    c.disconnect()
                                    if (pos <= end) error("Соединение оборвалось")
                                } catch (e: Exception) {
                                    if (cancel.get()) return@use
                                    if (++tries > 6) { failure.compareAndSet(null, e); return@use }
                                    Thread.sleep(1000L * tries)
                                    // возможно, другое зеркало
                                    target = runCatching { resolve(url, cancel).url }.getOrDefault(target)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    failure.compareAndSet(null, e)
                }
            }
        }
        while (workers.any { it.isAlive }) {
            Thread.sleep(250)
            onProgress(got.get(), total)
            // сервер слишком медленный (меньше ~150 КБ/с после 20 секунд) — уходим на другой
            val sec = (System.nanoTime() - t0) / 1e9
            if (canSwitch && sec > 20 && got.get() / sec < 150 * 1024) failure.compareAndSet(null, SlowServer())
        }
        workers.forEach { it.join() }
        if (cancel.get()) error("Загрузка отменена")
        failure.get()?.let { throw it }
        if (got.get() < total) error("Файл скачан не полностью")
    }

    /** Запасной вариант: один поток. Возвращает число скачанных байт. */
    private fun single(
        probe: Probe, expectedMb: Int, part: File, cancel: AtomicBoolean, onProgress: (Long, Long) -> Unit,
    ): Long {
        var conn = probe.conn
        if (conn == null) {
            conn = open(probe.url)
            val code = conn.responseCode
            if (code != 200) { conn.disconnect(); error("Сервер ответил $code") }
        }
        val declared = conn.contentLengthLong
        val total = if (declared > 0) declared else expectedMb * 1048576L
        var done = 0L
        var lastReport = 0L
        conn.inputStream.use { i ->
            part.outputStream().use { o ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    if (cancel.get()) error("Загрузка отменена")
                    val n = i.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    val now = System.currentTimeMillis()
                    if (now - lastReport >= 300) { lastReport = now; onProgress(done, maxOf(total, done)) }
                }
            }
        }
        return done
    }
}
