package com.oneemu.app

import android.content.Context
import java.io.File
import java.util.zip.ZipFile

/**
 * Мобильный (ARM64) образ приходит архивом-«бандлом» с несколькими дисками
 * (vda.qcow2, vdb.qcow2 …). Распаковываем их в images/<id>/ и возвращаем путь к первому диску.
 */
object ImageInstaller {
    private val DISK = Regex("""(?i)(^|/)(vd[a-z])\.(qcow2|img|raw)$""")

    fun isBundle(zip: File): Boolean = runCatching {
        ZipFile(zip).use { z -> z.entries().asSequence().any { !it.isDirectory && DISK.containsMatchIn(it.name) } }
    }.getOrDefault(false)

    /** Возвращает путь к основному диску (vda). */
    fun unpack(ctx: Context, id: String, zip: File, stage: (String) -> Unit = {}): String {
        val dir = File(ctx.filesDir, "images/$id").apply { deleteRecursively(); mkdirs() }
        var first: File? = null
        ZipFile(zip).use { z ->
            val disks = z.entries().asSequence().filter { !it.isDirectory && DISK.containsMatchIn(it.name) }
                .sortedBy { it.name.substringAfterLast('/').lowercase() }.toList()
            if (disks.isEmpty()) error("В архиве нет дисков vda/vdb (.qcow2). Это не образ для мобильной версии.")
            for (e in disks) {
                val name = e.name.substringAfterLast('/').lowercase()
                stage("Распаковка $name…")
                val f = File(dir, name)
                z.getInputStream(e).use { i -> f.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
                if (first == null) first = f
            }
        }
        return first!!.absolutePath
    }

    /** Все диски рядом с основным: vda, vdb, vdc … */
    fun disksNear(main: File): List<File> =
        (main.parentFile?.listFiles() ?: emptyArray())
            .filter { DISK.containsMatchIn("/" + it.name) }
            .sortedBy { it.name.lowercase() }
}
