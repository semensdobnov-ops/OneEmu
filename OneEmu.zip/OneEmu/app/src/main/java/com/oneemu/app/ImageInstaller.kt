package com.oneemu.app

import android.content.Context
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile

/**
 * Мобильный (ARM64) образ приходит архивом-«бандлом» с несколькими дисками
 * (vda.qcow2, vdb.qcow2 …). Распаковываем их в images/<id>/ и возвращаем путь к первому диску.
 */
/** Понятная пользователю причина, почему образ не подошёл (без подсказок про интернет). */
class InstallError(msg: String) : Exception(msg)

/** Копирует поток блоками по 1 МБ, сообщает сколько байт уже скопировано и проверяет отмену. */
internal fun copyCounting(i: java.io.InputStream, o: java.io.OutputStream, cancel: AtomicBoolean?, onBytes: (Long) -> Unit): Long {
    val buf = ByteArray(1 shl 20)
    var n = 0L
    while (true) {
        if (cancel?.get() == true) throw InstallError("Установка отменена")
        val r = i.read(buf); if (r < 0) break
        o.write(buf, 0, r); n += r
        onBytes(n)
    }
    return n
}

object ImageInstaller {
    private val DISK = Regex("""(?i)(^|/)(vd[a-z])\.(qcow2|img|raw)$""")

    fun isBundle(zip: File): Boolean = runCatching {
        ZipFile(zip).use { z -> z.entries().asSequence().any { !it.isDirectory && DISK.containsMatchIn(it.name) } }
    }.getOrDefault(false)

    /**
     * Возвращает путь к основному диску (vda).
     * progress(этап, готово, всего) — байты по всем дискам вместе, чтобы считать проценты и оставшееся время.
     */
    fun unpack(
        ctx: Context, id: String, zip: File, cancel: AtomicBoolean? = null,
        progress: (String, Long, Long) -> Unit = { _, _, _ -> },
    ): String {
        val dir = File(ctx.filesDir, "images/$id").apply { deleteRecursively(); mkdirs() }
        var first: File? = null
        try {
            ZipFile(zip).use { z ->
                val disks = z.entries().asSequence().filter { !it.isDirectory && DISK.containsMatchIn(it.name) }
                    .sortedBy { it.name.substringAfterLast('/').lowercase() }.toList()
                if (disks.isEmpty()) throw InstallError("В архиве нет дисков vda/vdb (.qcow2). Это не образ для мобильной версии.")
                val total = disks.sumOf { maxOf(it.size, 0L) }.coerceAtLeast(1L)
                var base = 0L
                for (e in disks) {
                    val name = e.name.substringAfterLast('/').lowercase()
                    val stage = "Распаковка $name…"
                    progress(stage, base, total)
                    val f = File(dir, name)
                    val start = base
                    z.getInputStream(e).use { i ->
                        f.outputStream().use { o -> copyCounting(i, o, cancel) { n -> progress(stage, start + n, total) } }
                    }
                    base += maxOf(e.size, 0L)
                    if (first == null) first = f
                }
            }
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
        return first!!.absolutePath
    }

    /** Все диски рядом с основным: vda, vdb, vdc … */
    fun disksNear(main: File): List<File> =
        (main.parentFile?.listFiles() ?: emptyArray())
            .filter { DISK.containsMatchIn("/" + it.name) }
            .sortedBy { it.name.lowercase() }
}
